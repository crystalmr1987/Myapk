package com.example.core.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        ScanSessionEntity::class,
        ObservedDeviceEntity::class,
        DeviceAppearanceEntity::class,
        DeviceIntelEntryEntity::class,
        InvestigationCaseEntity::class,
        EvidenceRecordEntity::class,
        MagnetometerLogEntity::class
    ],
    version = 2,
    exportSchema = true
)
abstract class SentinelDatabase : RoomDatabase() {
    abstract fun sentinelDao(): SentinelDao

    companion object {
        @Volatile
        private var INSTANCE: SentinelDatabase? = null

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_observed_devices_lastSeenAt` ON `observed_devices` (`lastSeenAt`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_device_appearances_fingerprintId` ON `device_appearances` (`fingerprintId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_device_appearances_sessionId` ON `device_appearances` (`sessionId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_device_appearances_timestamp` ON `device_appearances` (`timestamp`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_device_appearances_fingerprintId_sessionId` ON `device_appearances` (`fingerprintId`, `sessionId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_evidence_records_caseId` ON `evidence_records` (`caseId`)")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_magnetometer_logs_timestamp` ON `magnetometer_logs` (`timestamp`)")
            }
        }

        /** Register explicit schema migrations (e.g., Migration(1, 2)) here as version increments. */
        val MIGRATIONS: Array<Migration> = arrayOf(MIGRATION_1_2)

        fun getInstance(context: Context): SentinelDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: buildDatabase(context.applicationContext).also { INSTANCE = it }
            }
        }

        private fun buildDatabase(appContext: Context): SentinelDatabase {
            return Room.databaseBuilder(
                appContext,
                SentinelDatabase::class.java,
                "sentinel_security.db"
            )
                .addMigrations(*MIGRATIONS)
                .addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        CoroutineScope(Dispatchers.IO).launch {
                            getInstance(appContext).sentinelDao()
                                .insertIntelEntries(LocalIntelSeed.initialEntries())
                        }
                    }
                })
                .build()
        }
    }
}
