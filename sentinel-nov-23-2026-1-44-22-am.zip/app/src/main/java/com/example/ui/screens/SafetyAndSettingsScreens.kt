package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.core.data.InvestigationContentCatalog
import com.example.core.database.ObservedDeviceEntity
import com.example.core.model.BleScanProfile
import com.example.core.model.RiskLevel
import com.example.core.model.ThemePreference
import com.example.core.model.UserDeviceStatus
import com.example.core.preferences.SentinelSettings
import com.example.core.security.KeystoreCryptoManager
import com.example.ui.components.LimitationBanner
import com.example.ui.components.RiskBadge
import com.example.ui.components.SectionHeader
import com.example.ui.components.TacticalCard
import com.example.ui.theme.LocalSentinelPalette

@Composable
fun SafetyAndSettingsScreen(
    settings: SentinelSettings,
    onSetTheme: (ThemePreference) -> Unit,
    onSetTextScale: (Float) -> Unit,
    onSetOptInLocation: (Boolean) -> Unit,
    onSetBleProfile: (BleScanProfile) -> Unit,
    onSetTrackerAlerts: (Boolean) -> Unit,
    onOpenAntiStalking: () -> Unit,
    onOpenEducation: () -> Unit,
    onOpenDiagnostics: () -> Unit,
    onReopenOnboarding: () -> Unit,
    onWipeAllData: () -> Unit,
    modifier: Modifier = Modifier
) {
    var confirmWipe by remember { mutableStateOf(false) }
    val palette = LocalSentinelPalette.current

    val locationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        onSetOptInLocation(results[Manifest.permission.ACCESS_FINE_LOCATION] == true)
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionHeader(
                title = "Safety, Education & Diagnostics",
                subtitle = "Offline guides, anti-stalking tools & device compatibility"
            )
            Spacer(modifier = Modifier.height(6.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                TacticalCard(onClick = onOpenAntiStalking, accentColor = palette.high, modifier = Modifier.testTag("open_antistalking_card")) {
                    Row(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Security, contentDescription = null, tint = palette.high)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Anti-Stalking Protection Center", style = MaterialTheme.typography.titleMedium)
                            Text("Persistent alerts, non-confrontation safety & OS tracker tools", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                TacticalCard(onClick = onOpenEducation, modifier = Modifier.testTag("open_education_card")) {
                    Row(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.AutoMirrored.Filled.MenuBook, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Safety & User Education Center", style = MaterialTheme.typography.titleMedium)
                            Text("9 offline guides covering BLE, GPS, cameras, vehicles & evidence", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                TacticalCard(onClick = onOpenDiagnostics, modifier = Modifier.testTag("open_diagnostics_card")) {
                    Row(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Build, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Hardware & API Diagnostics", style = MaterialTheme.typography.titleMedium)
                            Text("Full compatibility matrix & runtime permission audit", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                OutlinedButton(
                    onClick = onReopenOnboarding,
                    modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize()
                ) {
                    Icon(Icons.Filled.School, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Replay Interactive Onboarding Tutorial")
                }
            }
        }

        // Appearance & Accessibility
        item {
            SectionHeader(title = "Appearance & Accessibility")
            Spacer(modifier = Modifier.height(6.dp))
            TacticalCard {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Theme Mode", style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ThemePreference.entries.forEach { pref ->
                            OutlinedButton(
                                onClick = { onSetTheme(pref) },
                                modifier = Modifier.weight(1f).minimumInteractiveComponentSize(),
                                colors = if (settings.themePreference == pref) {
                                    ButtonDefaults.outlinedButtonColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                                } else {
                                    ButtonDefaults.outlinedButtonColors()
                                }
                            ) {
                                Text(pref.name, maxLines = 1)
                            }
                        }
                    }
                    var localTextScale by remember(settings.textScaleMultiplier) {
                        mutableFloatStateOf(settings.textScaleMultiplier)
                    }
                    Text("Adjustable Text Scale: ${"%.2f".format(localTextScale)}x", style = MaterialTheme.typography.titleMedium)
                    Slider(
                        value = localTextScale,
                        onValueChange = { localTextScale = it },
                        onValueChangeFinished = { onSetTextScale(localTextScale) },
                        valueRange = 0.85f..1.30f
                    )
                }
            }
        }

        // Battery & Scan Intervals
        item {
            SectionHeader(title = "Battery & Scan Optimization")
            Spacer(modifier = Modifier.height(6.dp))
            TacticalCard {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("BLE Scan Profile (${settings.bleScanProfile.label})", style = MaterialTheme.typography.titleMedium)
                    Text(settings.bleScanProfile.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        BleScanProfile.entries.forEach { p ->
                            OutlinedButton(
                                onClick = { onSetBleProfile(p) },
                                modifier = Modifier.weight(1f).minimumInteractiveComponentSize(),
                                colors = if (settings.bleScanProfile == p) {
                                    ButtonDefaults.outlinedButtonColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                                } else {
                                    ButtonDefaults.outlinedButtonColors()
                                }
                            ) {
                                Text(p.name, maxLines = 1)
                            }
                        }
                    }
                    Text(
                        text = "Android background restriction note: Android limits background BLE/Wi-Fi scanning to conserve battery. Use Foreground Extended Observation or manual sweeps for reliable results.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Privacy & Local Security
        item {
            SectionHeader(title = "Privacy & Local Security Architecture")
            Spacer(modifier = Modifier.height(6.dp))
            TacticalCard {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Opt-In Location Correlation", style = MaterialTheme.typography.titleMedium)
                            Text("Foreground-only GPS tagging during scans (OFF by default)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = settings.optInLocationCorrelation,
                            onCheckedChange = { enable ->
                                if (enable) {
                                    locationLauncher.launch(
                                        arrayOf(
                                            Manifest.permission.ACCESS_FINE_LOCATION,
                                            Manifest.permission.ACCESS_COARSE_LOCATION
                                        )
                                    )
                                } else {
                                    onSetOptInLocation(false)
                                }
                            },
                            modifier = Modifier.testTag("settings_location_switch")
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Persistent Device Alerts", style = MaterialTheme.typography.titleMedium)
                            Text("Flag devices appearing across multiple scans/locations", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = settings.persistentTrackerAlertsEnabled,
                            onCheckedChange = onSetTrackerAlerts
                        )
                    }
                    Text(
                        text = "Android Keystore AES-256-GCM: ${if (KeystoreCryptoManager.isHardwareKeystoreAvailable()) "Hardware-backed Keystore Active" else "Local AES Fallback"} • No cloud accounts • No ads • No telemetry.",
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.low
                    )
                    Button(
                        onClick = { confirmWipe = true },
                        colors = ButtonDefaults.buttonColors(containerColor = palette.critical),
                        modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag("settings_wipe_data_button")
                    ) {
                        Icon(Icons.Filled.DeleteForever, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Delete All Stored Scans, Cases & Photos")
                    }
                }
            }
        }
    }

    if (confirmWipe) {
        AlertDialog(
            onDismissRequest = { confirmWipe = false },
            title = { Text("Confirm Complete Data Erasure") },
            text = { Text("This permanently deletes all local scan sessions, device observations, magnetometer logs, encrypted cases, evidence photographs, and exported reports.") },
            confirmButton = {
                Button(
                    onClick = {
                        onWipeAllData()
                        confirmWipe = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = palette.critical)
                ) { Text("Erase Everything") }
            },
            dismissButton = {
                TextButton(onClick = { confirmWipe = false }) { Text("Cancel") }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AntiStalkingScreen(
    devices: List<ObservedDeviceEntity>,
    onOpenDeviceDetail: (String) -> Unit,
    onOpenAndroidTrackerAlerts: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val palette = LocalSentinelPalette.current
    val checklistState = remember { mutableStateMapOf<String, Boolean>() }

    val persistentOrElevated = remember(devices) {
        devices.filter {
            it.userStatus != UserDeviceStatus.TRUSTED.name &&
                it.userStatus != UserDeviceStatus.DISMISSED.name &&
                (it.observationCount >= 2 || it.riskLevel == RiskLevel.HIGH.name || it.riskLevel == RiskLevel.CRITICAL.name)
        }.sortedByDescending { it.observationCount }
    }

    val safetySteps = listOf(
        "safe_1" to "Move to a well-lit public location or trusted friend's home before inspecting belongings or your vehicle.",
        "safe_2" to "Do NOT confront anyone if you discover a suspected tracker.",
        "safe_3" to "Photograph the device in place before moving or disabling it so serial numbers and mounting context are preserved.",
        "safe_4" to "Check Android Settings > Safety & emergency > Unknown tracker alerts for OS-level separation alerts."
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Anti-Stalking Protection") },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                LimitationBanner(
                    title = "Critical Safety & Evidence Warning",
                    message = "SENTINEL will never automatically tamper with or disable hardware. Removing or destroying a suspected tracker immediately may eliminate evidence or alert another person. Prioritize your physical safety and avoid confrontation.",
                    tint = palette.critical
                )
            }

            item {
                TacticalCard(accentColor = MaterialTheme.colorScheme.primary) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Built-In Safety & Emergency Shortcuts", style = MaterialTheme.typography.titleMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = onOpenAndroidTrackerAlerts,
                                modifier = Modifier.weight(1f).minimumInteractiveComponentSize()
                            ) {
                                Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("OS Tracker Alerts")
                            }
                            OutlinedButton(
                                onClick = {
                                    // Zero-permission ACTION_DIAL opens system dialer for manual user confirmation
                                    val dial = Intent(Intent.ACTION_DIAL, Uri.parse("tel:911"))
                                    runCatching { context.startActivity(dial) }
                                },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Icon(Icons.Filled.Phone, contentDescription = null)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Dialer")
                            }
                        }
                    }
                }
            }

            item { SectionHeader(title = "Personal Safety Checklist") }
            items(safetySteps, key = { it.first }) { (id, text) ->
                val done = checklistState[id] == true
                TacticalCard(onClick = { checklistState[id] = !done }) {
                    Row(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = done, onCheckedChange = { checklistState[id] = it })
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            item {
                SectionHeader(
                    title = "Persistent & Elevated Devices (${persistentOrElevated.size})",
                    subtitle = "Repeated appearances warrant verification across locations, not immediate assumptions"
                )
            }
            if (persistentOrElevated.isEmpty()) {
                item {
                    TacticalCard {
                        Text(
                            text = "No persistent or elevated unknown devices recorded yet.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(14.dp)
                        )
                    }
                }
            } else {
                items(persistentOrElevated, key = { it.fingerprintId }) { dev ->
                    TacticalCard(onClick = { onOpenDeviceDetail(dev.fingerprintId) }) {
                        Row(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(dev.displayName, style = MaterialTheme.typography.titleMedium)
                                Text("Seen ${dev.observationCount}x • ${dev.manufacturerName}", style = MaterialTheme.typography.bodySmall)
                            }
                            RiskBadge(riskLevel = dev.riskLevel)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EducationCenterScreen(onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val guides = remember { InvestigationContentCatalog.educationalGuides }
    var expandedId by remember { mutableStateOf<String?>(guides.firstOrNull()?.id) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Security Education Center") },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(guides, key = { it.id }) { guide ->
                val isOpen = expandedId == guide.id
                TacticalCard(
                    onClick = { expandedId = if (isOpen) null else guide.id },
                    accentColor = if (isOpen) MaterialTheme.colorScheme.primary else null
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(guide.category.uppercase(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        Text(guide.title, style = MaterialTheme.typography.titleMedium)
                        Text(guide.summary, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (isOpen) {
                            Spacer(modifier = Modifier.height(4.dp))
                            guide.sections.forEach { (heading, body) ->
                                Text(heading, style = MaterialTheme.typography.labelLarge)
                                Text(body, style = MaterialTheme.typography.bodySmall)
                            }
                            LimitationBanner(title = "Technical Limitation", message = guide.keyLimitation)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun OnboardingScreen(
    onFinish: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalSentinelPalette.current
    Column(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(12.dp))
                Icon(
                    imageVector = Icons.Filled.Shield,
                    contentDescription = "SENTINEL",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.height(52.dp).width(52.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text("Welcome to SENTINEL", style = MaterialTheme.typography.displaySmall)
                Text(
                    text = "Evidence-Driven Personal Security & Electronic Surveillance Investigation",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            item {
                TacticalCard {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("1. Real Hardware Detection Only", style = MaterialTheme.typography.titleMedium)
                        Text("SENTINEL scans Bluetooth LE, Wi-Fi, authorized LAN/mDNS services, 3-axis Magnetometer, CameraX optics, NFC, UWB, and USB OTG external RF equipment. It never simulates or fabricates results.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item {
                TacticalCard {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("2. Strict Local-First Privacy", style = MaterialTheme.typography.titleMedium)
                        Text("Zero cloud accounts, zero ads, zero hidden uploads. Sensitive case notes are encrypted locally with Android Keystore AES-256-GCM, and location correlation is strictly opt-in.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item {
                TacticalCard(accentColor = palette.moderate) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("3. Honest Technical Limits & Safety", style = MaterialTheme.typography.titleMedium)
                        Text("No smartphone can universally detect passive GPS receivers, cellular uplinks, or offline cameras without external RF hardware. Always prioritize physical safety and avoid confrontation.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        Button(
            onClick = onFinish,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 14.dp)
                .minimumInteractiveComponentSize()
                .testTag("onboarding_continue_button")
        ) {
            Text("Enter SENTINEL Command")
        }
    }
}
