package com.example.sensors

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.example.core.intelligence.RawDeviceObservation
import com.example.core.model.DetectionSource
import com.example.core.model.DeviceCategory
import com.example.core.security.ManufacturerLookup
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Collections

data class WifiApObservation(
    val ssid: String,
    val bssid: String,
    val manufacturerName: String,
    val rssi: Int,
    val frequencyMhz: Int,
    val channel: Int,
    val securityLabel: String,
    val isDuplicateSsidAnomaly: Boolean,
    val suspicionNote: String?,
    val timestamp: Long
) {
    fun toRawObservation(location: LocationSnapshot?): RawDeviceObservation {
        val extra = buildList {
            add("Channel $channel ($frequencyMhz MHz)")
            add("Security: $securityLabel")
            suspicionNote?.let { add(it) }
        }
        return RawDeviceObservation(
            source = DetectionSource.WIFI_AP,
            displayName = ssid.ifBlank { "<Hidden SSID>" },
            rawAddress = bssid,
            addressType = if (ManufacturerLookup.isRandomizedMac(bssid)) "RANDOM_RPA" else "PUBLIC",
            manufacturerName = manufacturerName,
            companyIdOrOui = bssid.take(8),
            serviceUuids = emptyList(),
            manufacturerDataHex = "",
            rssi = rssi,
            timestamp = timestamp,
            frequencyMhz = frequencyMhz,
            categoryHint = ManufacturerLookup.lookupOui(bssid)?.categoryHint ?: DeviceCategory.NETWORK_EQUIPMENT,
            extraIndicators = extra,
            isDuplicateSsidConflict = isDuplicateSsidAnomaly,
            latitude = location?.latitude,
            longitude = location?.longitude,
            locationLabel = location?.label
        )
    }
}

data class LanHostObservation(
    val ipAddress: String,
    val hostname: String,
    val macAddress: String?,
    val manufacturerName: String,
    val openServices: List<String>,
    val hasCameraIndicator: Boolean,
    val confirmationStatus: String, // CONFIRMED_SERVICE or HEURISTIC_SUSPICION
    val timestamp: Long
) {
    fun toRawObservation(location: LocationSnapshot?): RawDeviceObservation {
        return RawDeviceObservation(
            source = DetectionSource.LAN_HOST,
            displayName = if (hostname.isNotBlank() && hostname != ipAddress) "$hostname ($ipAddress)" else ipAddress,
            rawAddress = macAddress ?: ipAddress,
            addressType = "PUBLIC",
            manufacturerName = manufacturerName,
            companyIdOrOui = macAddress?.take(8) ?: ipAddress,
            serviceUuids = openServices,
            manufacturerDataHex = "",
            rssi = -50, // Local LAN host
            timestamp = timestamp,
            categoryHint = if (hasCameraIndicator) DeviceCategory.SUSPECTED_CAMERA else DeviceCategory.NETWORK_EQUIPMENT,
            extraIndicators = buildList {
                add("Status: $confirmationStatus")
                if (openServices.isNotEmpty()) add("Services: ${openServices.joinToString(", ")}")
            },
            hasCameraServicePort = hasCameraIndicator,
            latitude = location?.latitude,
            longitude = location?.longitude,
            locationLabel = location?.label
        )
    }
}

data class WifiScanReport(
    val accessPoints: List<WifiApObservation>,
    val warning: String? = null,
    val connectedSsid: String? = null,
    val connectedSubnet: String? = null
)

class WifiNetworkInspector(
    private val context: Context,
    private val diagnosticsManager: DiagnosticsManager
) {
    @SuppressLint("MissingPermission")
    suspend fun scanNearbyAccessPoints(): WifiScanReport = withContext(Dispatchers.IO) {
        diagnosticsManager.verifyWifiScanPreconditions()?.let { failureReason ->
            return@withContext WifiScanReport(emptyList(), failureReason)
        }
        val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            ?: return@withContext WifiScanReport(emptyList(), "Wi-Fi service unavailable on this device.")

        val scanCompleted = CompletableDeferred<Boolean>()
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                val updated = intent?.getBooleanExtra(WifiManager.EXTRA_RESULTS_UPDATED, false) ?: false
                scanCompleted.complete(updated)
            }
        }
        val registered = runCatching {
            ContextCompat.registerReceiver(
                context,
                receiver,
                IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION),
                ContextCompat.RECEIVER_EXPORTED
            )
        }.isSuccess

        @Suppress("DEPRECATION")
        val triggerAccepted = try {
            val started = runCatching { wifiManager.startScan() }.getOrDefault(false)
            if (started && registered) {
                withTimeoutOrNull(3_200L) { scanCompleted.await() }
            } else if (started) {
                delay(1_500L)
            }
            started
        } finally {
            if (registered) {
                runCatching { context.unregisterReceiver(receiver) }
            }
        }

        val results = runCatching { wifiManager.scanResults }.getOrElse { emptyList() }
        val now = System.currentTimeMillis()

        // Group by SSID to detect duplicate SSIDs with differing security protocols (potential impersonation)
        val bySsid = results.filter { getSsid(it).isNotBlank() }.groupBy { getSsid(it) }
        val observations = results.map { sr ->
            val ssid = getSsid(sr)
            val bssid = sr.BSSID ?: "00:00:00:00:00:00"
            val security = parseSecurity(sr.capabilities ?: "")
            val sameSsidList = bySsid[ssid].orEmpty()
            val distinctSecurity = sameSsidList.map { parseSecurity(it.capabilities ?: "") }.distinct()
            val duplicateConflict = sameSsidList.size > 1 && distinctSecurity.size > 1
            val vendor = ManufacturerLookup.lookupOui(bssid)
            val isCamName = ssid.lowercase().let {
                it.contains("cam") || it.contains("ipc") || it.contains("esp32") || it.contains("hik") || it.contains("v380")
            }
            val suspicionNote = when {
                duplicateConflict -> "SSID '$ssid' appears with mismatched security modes (${distinctSecurity.joinToString("/")}); verify legitimate mesh vs. impersonation."
                isCamName -> "SSID pattern resembles embedded Wi-Fi camera or IoT module; requires verification."
                security == "OPEN" -> "Unencrypted open access point."
                else -> null
            }

            WifiApObservation(
                ssid = ssid,
                bssid = bssid,
                manufacturerName = vendor?.manufacturer ?: "Unknown Vendor",
                rssi = sr.level,
                frequencyMhz = sr.frequency,
                channel = frequencyToChannel(sr.frequency),
                securityLabel = security,
                isDuplicateSsidAnomaly = duplicateConflict || isCamName,
                suspicionNote = suspicionNote,
                timestamp = now
            )
        }.sortedByDescending { it.rssi }

        val connInfo = getCurrentWifiSummary()
        val warning = if (!triggerAccepted && observations.isEmpty()) {
            "No cached Wi-Fi access points returned (passive read-only mode without CHANGE_WIFI_STATE; open Android Wi-Fi settings to refresh scan cache)."
        } else if (!triggerAccepted) {
            "Showing cached Android Wi-Fi scan results (passive read-only mode without CHANGE_WIFI_STATE)."
        } else {
            null
        }

        WifiScanReport(
            accessPoints = observations,
            warning = warning,
            connectedSsid = connInfo.first,
            connectedSubnet = connInfo.second
        )
    }

    private fun getCurrentWifiSummary(): Pair<String?, String?> {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return null to null
        val activeNetwork = cm.activeNetwork ?: return null to null
        val caps = cm.getNetworkCapabilities(activeNetwork) ?: return null to null
        if (!caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return null to null
        val lp = cm.getLinkProperties(activeNetwork)
        val ipv4 = lp?.linkAddresses?.firstOrNull { it.address is Inet4Address }?.address?.hostAddress
        val subnet = ipv4?.substringBeforeLast(".")?.plus(".0/24")
        val wifiMgr = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        @Suppress("DEPRECATION")
        val ssid = if (diagnosticsManager.hasFineLocationPermission()) {
            runCatching { wifiMgr?.connectionInfo?.ssid?.removeSurrounding("\"") }.getOrNull()
        } else {
            null
        }
        return ssid to subnet
    }

    /**
     * Performs respectful, read-only local network discovery ONLY on the currently connected Wi-Fi subnet
     * that the user authorizes. Discovers mDNS services via NsdManager and checks standard camera/web ports.
     */
    suspend fun discoverAuthorizedLanDevices(): Pair<List<LanHostObservation>, String?> = withContext(Dispatchers.IO) {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return@withContext emptyList<LanHostObservation>() to "ConnectivityManager unavailable."
        val network = cm.activeNetwork
            ?: return@withContext emptyList<LanHostObservation>() to "Not connected to an active Wi-Fi network."
        val caps = cm.getNetworkCapabilities(network)
        if (caps == null || !caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
            return@withContext emptyList<LanHostObservation>() to "Connect to an authorized Wi-Fi network to run LAN host discovery."
        }

        val lp = cm.getLinkProperties(network)
        val localIp = lp?.linkAddresses?.firstOrNull { it.address is Inet4Address }?.address as? Inet4Address
            ?: return@withContext emptyList<LanHostObservation>() to "No local IPv4 address assigned on this Wi-Fi connection."

        val prefix = localIp.hostAddress?.substringBeforeLast(".") ?: return@withContext emptyList<LanHostObservation>() to "Unable to resolve local subnet."
        val now = System.currentTimeMillis()
        val mdnsFound = runCatching { discoverMdnsCameraAndMediaServices() }.getOrElse { emptyMap() }
        val hasInternetPerm = ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.INTERNET
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED

        // Read /proc/net/arp if readable on older Android (API < 29 restricts this; handled safely)
        val arpMacs = readArpCacheSafe()

        val discovered = Collections.synchronizedList(mutableListOf<LanHostObservation>())
        if (hasInternetPerm) {
            // Bounded polite probe of gateway + first 40 common host IPs + any mDNS IPs
            val candidateIps = linkedSetOf<String>()
            candidateIps.add("$prefix.1")
            candidateIps.add("$prefix.254")
            for (i in 2..40) candidateIps.add("$prefix.$i")
            mdnsFound.keys.forEach { candidateIps.add(it) }

            val cameraPorts = listOf(
                554 to "RTSP (554)",
                8000 to "Camera SDK/Web (8000)",
                8080 to "HTTP Alt (8080)",
                80 to "HTTP (80)",
                443 to "HTTPS (443)"
            )
            val probeSemaphore = Semaphore(10)

            coroutineScope {
                candidateIps.filter { it != localIp.hostAddress }.map { ip ->
                    async(Dispatchers.IO) {
                        probeSemaphore.withPermit {
                            val mdnsServices = mdnsFound[ip].orEmpty()
                            val reachable = mdnsServices.isNotEmpty() || runCatching {
                                InetAddress.getByName(ip).isReachable(120)
                            }.getOrDefault(false)

                            val openPorts = mutableListOf<String>()
                            if (reachable || ip == "$prefix.1") {
                                for ((port, label) in cameraPorts) {
                                    if (isPortOpen(ip, port, 120)) {
                                        openPorts.add(label)
                                    }
                                }
                            }

                            if (reachable || openPorts.isNotEmpty() || mdnsServices.isNotEmpty()) {
                                val hostname = withTimeoutOrNull(200L) {
                                    runCatching {
                                        val h = InetAddress.getByName(ip).canonicalHostName
                                        if (h == ip) "" else h
                                    }.getOrDefault("")
                                }.orEmpty()
                                val mac = arpMacs[ip]
                                val vendor = ManufacturerLookup.lookupOui(mac)?.manufacturer
                                    ?: "Unresolved on Android (ARP restricted on Android 10+)"
                                val allServices = (mdnsServices + openPorts).distinct()
                                val hasCam = allServices.any {
                                    it.contains("RTSP", true) || it.contains("onvif", true) ||
                                        it.contains("axis", true) || it.contains("8000")
                                } || ManufacturerLookup.lookupOui(mac)?.categoryHint == DeviceCategory.SUSPECTED_CAMERA

                                val status = if (allServices.any {
                                        it.contains("RTSP", true) || it.contains("onvif", true) || it.contains("axis", true)
                                    }
                                ) {
                                    "CONFIRMED_CAMERA_SERVICE"
                                } else if (hasCam) {
                                    "HEURISTIC_SUSPICION"
                                } else {
                                    "ACTIVE_LAN_HOST"
                                }

                                discovered.add(
                                    LanHostObservation(
                                        ipAddress = ip,
                                        hostname = hostname,
                                        macAddress = mac,
                                        manufacturerName = vendor,
                                        openServices = allServices,
                                        hasCameraIndicator = hasCam,
                                        confirmationStatus = status,
                                        timestamp = now
                                    )
                                )
                            }
                        }
                    }
                }.awaitAll()
            }
        } else {
            mdnsFound.forEach { (ip, services) ->
                val mac = arpMacs[ip]
                val vendor = ManufacturerLookup.lookupOui(mac)?.manufacturer
                    ?: "Unresolved on Android (ARP restricted on Android 10+)"
                val hasCam = services.any {
                    it.contains("RTSP", true) || it.contains("onvif", true) || it.contains("axis", true)
                } || ManufacturerLookup.lookupOui(mac)?.categoryHint == DeviceCategory.SUSPECTED_CAMERA
                val status = if (services.any {
                        it.contains("RTSP", true) || it.contains("onvif", true) || it.contains("axis", true)
                    }
                ) {
                    "CONFIRMED_CAMERA_SERVICE"
                } else if (hasCam) {
                    "HEURISTIC_SUSPICION"
                } else {
                    "ACTIVE_LAN_HOST"
                }
                discovered.add(
                    LanHostObservation(
                        ipAddress = ip,
                        hostname = "",
                        macAddress = mac,
                        manufacturerName = vendor,
                        openServices = services,
                        hasCameraIndicator = hasCam,
                        confirmationStatus = status,
                        timestamp = now
                    )
                )
            }
        }

        val sortedDiscovered = discovered.sortedBy { it.ipAddress }
        val note = when {
            !hasInternetPerm && sortedDiscovered.isEmpty() ->
                "Connected subnet $prefix.0/24 • Zero-cloud passive mDNS check found no advertised camera/HTTP services (direct TCP/ICMP probing is disabled because INTERNET permission is omitted)."
            !hasInternetPerm ->
                "Discovered ${sortedDiscovered.size} mDNS LAN service(s) on $prefix.0/24 without INTERNET permission."
            sortedDiscovered.isEmpty() ->
                "No responding LAN hosts found in initial subnet range. Note: Android and routers often block ICMP (isReachable) or enable client isolation, so 'no response' does not guarantee no device is present."
            else ->
                "Scanned $prefix.1–40 + mDNS services. Note: Android 10+ restricts raw MAC/ARP lookup for privacy."
        }
        sortedDiscovered to note
    }

    private suspend fun discoverMdnsCameraAndMediaServices(): Map<String, List<String>> = withContext(Dispatchers.IO) {
        val map = mutableMapOf<String, MutableList<String>>()
        val nsdManager = context.getSystemService(Context.NSD_SERVICE) as? NsdManager ?: return@withContext emptyMap()
        val serviceTypes = listOf("_rtsp._tcp.", "_onvif._tcp.", "_axis-video._tcp.", "_http._tcp.")
        val discoveredQueue = Collections.synchronizedList(mutableListOf<NsdServiceInfo>())
        val activeListeners = Collections.synchronizedList(mutableListOf<NsdManager.DiscoveryListener>())

        for (type in serviceTypes) {
            val listener = object : NsdManager.DiscoveryListener {
                override fun onDiscoveryStarted(regType: String?) {}
                override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                    discoveredQueue.add(serviceInfo)
                }
                override fun onServiceLost(serviceInfo: NsdServiceInfo?) {}
                override fun onDiscoveryStopped(serviceType: String?) {}
                override fun onStartDiscoveryFailed(serviceType: String?, errorCode: Int) {
                    activeListeners.remove(this)
                }
                override fun onStopDiscoveryFailed(serviceType: String?, errorCode: Int) {}
            }
            if (runCatching { nsdManager.discoverServices(type, NsdManager.PROTOCOL_DNS_SD, listener) }.isSuccess) {
                activeListeners.add(listener)
            }
        }

        delay(1_100L)
        activeListeners.toList().forEach { listener ->
            runCatching { nsdManager.stopServiceDiscovery(listener) }
        }

        // Resolve discovered mDNS entries sequentially so Android NsdManager never rejects concurrent calls
        val resolveMutex = Mutex()
        discoveredQueue.toList().take(20).forEach { info ->
            resolveMutex.withLock {
                val resolved = withTimeoutOrNull(450L) {
                    val done = CompletableDeferred<NsdServiceInfo?>()
                    @Suppress("DEPRECATION")
                    val submitted = runCatching {
                        nsdManager.resolveService(info, object : NsdManager.ResolveListener {
                            override fun onResolveFailed(failedInfo: NsdServiceInfo?, errorCode: Int) {
                                done.complete(null)
                            }
                            override fun onServiceResolved(resolvedInfo: NsdServiceInfo) {
                                done.complete(resolvedInfo)
                            }
                        })
                    }.isSuccess
                    if (submitted) done.await() else null
                }
                @Suppress("DEPRECATION")
                val host = resolved?.host?.hostAddress
                if (host != null) {
                    val list = map.getOrPut(host) { mutableListOf() }
                    list.add("mDNS ${resolved.serviceType.trimEnd('.')} (${resolved.serviceName})")
                }
            }
        }
        map.mapValues { it.value.toList() }
    }

    private fun isPortOpen(ip: String, port: Int, timeoutMs: Int): Boolean {
        return runCatching {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(ip, port), timeoutMs)
                true
            }
        }.getOrDefault(false)
    }

    private fun readArpCacheSafe(): Map<String, String> {
        val result = mutableMapOf<String, String>()
        runCatching {
            java.io.File("/proc/net/arp").takeIf { it.canRead() }?.readLines()?.drop(1)?.forEach { line ->
                val parts = line.trim().split(Regex("\\s+"))
                if (parts.size >= 4 && parts[3].matches(Regex("([0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}")) &&
                    parts[3] != "00:00:00:00:00:00"
                ) {
                    result[parts[0]] = parts[3].uppercase()
                }
            }
        }
        return result
    }

    @Suppress("DEPRECATION")
    private fun getSsid(sr: ScanResult): String {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            sr.wifiSsid?.toString()?.removeSurrounding("\"") ?: ""
        } else {
            sr.SSID ?: ""
        }
    }

    private fun parseSecurity(caps: String): String = when {
        caps.contains("SAE") || caps.contains("WPA3") -> "WPA3"
        caps.contains("WPA2") -> "WPA2"
        caps.contains("WPA") -> "WPA"
        caps.contains("WEP") -> "WEP (Weak)"
        else -> "OPEN"
    }

    private fun frequencyToChannel(freqMhz: Int): Int = when {
        freqMhz == 2484 -> 14
        freqMhz in 2412..2472 -> (freqMhz - 2407) / 5
        freqMhz in 5180..5825 -> (freqMhz - 5000) / 5
        freqMhz in 5955..7115 -> (freqMhz - 5950) / 5
        else -> 0
    }
}
