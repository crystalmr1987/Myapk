package com.example.core.security

import com.example.core.model.DeviceCategory

data class VendorMatch(
    val manufacturer: String,
    val categoryHint: DeviceCategory?,
    val notes: String = ""
)

/**
 * Offline vendor and signature lookup database using Bluetooth SIG Company IDs,
 * standardized GATT/Advertising Service UUIDs, and IEEE OUI MAC prefixes.
 */
object ManufacturerLookup {

    private val bleCompanyIds: Map<Int, VendorMatch> = mapOf(
        0x004C to VendorMatch("Apple, Inc.", null, "Apple Continuity / Find My ecosystem"),
        0x0075 to VendorMatch("Samsung Electronics", null, "Samsung Galaxy / SmartTag ecosystem"),
        0x00E0 to VendorMatch("Google LLC", null, "Google Fast Pair / Find My Device Network"),
        0x0006 to VendorMatch("Microsoft", DeviceCategory.PERSONAL_ACCESSORY),
        0x0059 to VendorMatch("Nordic Semiconductor", DeviceCategory.UNKNOWN_TRANSMITTER, "Common BLE SoC in trackers & sensors"),
        0x000D to VendorMatch("Texas Instruments", DeviceCategory.UNKNOWN_TRANSMITTER, "CC25xx/CC26xx BLE SoC"),
        0x00D2 to VendorMatch("Dialog Semiconductor", DeviceCategory.UNKNOWN_TRANSMITTER),
        0x0157 to VendorMatch("Anhui Huami / Amazfit", DeviceCategory.PERSONAL_ACCESSORY),
        0x038F to VendorMatch("Xiaomi Inc.", DeviceCategory.IOT_SMART_DEVICE),
        0x0171 to VendorMatch("Amazon.com Services", DeviceCategory.IOT_SMART_DEVICE),
        0x02FF to VendorMatch("Silicon Labs", DeviceCategory.UNKNOWN_TRANSMITTER),
        0x0087 to VendorMatch("Garmin International", DeviceCategory.PERSONAL_ACCESSORY),
        0x009E to VendorMatch("Bose Corporation", DeviceCategory.PERSONAL_ACCESSORY),
        0x012D to VendorMatch("Sony Corporation", DeviceCategory.PERSONAL_ACCESSORY),
        0x0642 to VendorMatch("Tile, Inc. (Life360)", DeviceCategory.COMMERCIAL_TRACKER),
        0x089A to VendorMatch("Teltonika Telematics", DeviceCategory.VEHICLE_OBD, "Commercial GPS/BLE vehicle telematics")
    )

    // 16-bit Service UUIDs (uppercased 4-char short UUIDs)
    val knownTrackerServiceUuids: Map<String, Pair<String, String>> = mapOf(
        "FD6F" to ("Apple / Google DULT" to "Offline Finding / Unwanted Tracker Alert compatible beacon"),
        "FD44" to ("Apple Find My" to "Find My network accessory service UUID"),
        "FEED" to ("Tile, Inc." to "Tile Bluetooth tracker service"),
        "FEEC" to ("Tile, Inc." to "Tile Bluetooth tracker secondary service"),
        "FD5A" to ("Samsung SmartTag" to "Samsung SmartThings Find / SmartTag service"),
        "FD59" to ("Samsung SmartTag" to "Samsung SmartTag provisioning/beacon service"),
        "FE2C" to ("Google Fast Pair / FMDN" to "Google Fast Pair / Find My Device Network"),
        "FE65" to ("Chipolo" to "Chipolo Bluetooth item finder service"),
        "FE33" to ("Chipolo / Tracker" to "Item finder beacon service"),
        "FDEE" to ("Pebblebee" to "Pebblebee tracker service"),
        "FFF0" to ("Generic BLE / OBD-II" to "Commonly used by generic OBD-II adapters & low-cost beacons")
    )

    // IEEE OUI 24-bit prefixes (uppercase XX:XX:XX)
    private val ouiPrefixes: Map<String, VendorMatch> = mapOf(
        // Camera & Video Surveillance Vendors
        "B4:A3:82" to VendorMatch("Hikvision Digital Technology", DeviceCategory.SUSPECTED_CAMERA, "IP camera / NVR manufacturer"),
        "C0:56:E3" to VendorMatch("Hikvision Digital Technology", DeviceCategory.SUSPECTED_CAMERA, "IP camera / NVR manufacturer"),
        "44:19:B6" to VendorMatch("Hikvision Digital Technology", DeviceCategory.SUSPECTED_CAMERA, "IP camera / NVR manufacturer"),
        "3C:EF:8C" to VendorMatch("Dahua Technology", DeviceCategory.SUSPECTED_CAMERA, "IP camera / DVR manufacturer"),
        "A0:BD:1D" to VendorMatch("Dahua Technology", DeviceCategory.SUSPECTED_CAMERA, "IP camera / DVR manufacturer"),
        "00:40:8C" to VendorMatch("Axis Communications", DeviceCategory.SUSPECTED_CAMERA, "Network camera manufacturer"),
        "AC:CC:8E" to VendorMatch("Axis Communications", DeviceCategory.SUSPECTED_CAMERA, "Network camera manufacturer"),
        "EC:71:DB" to VendorMatch("Reolink Innovation", DeviceCategory.SUSPECTED_CAMERA, "Wi-Fi / PoE security camera"),
        "2C:AA:8E" to VendorMatch("Wyze Labs", DeviceCategory.SUSPECTED_CAMERA, "Smart Wi-Fi camera"),
        "7C:78:B2" to VendorMatch("Wyze Labs", DeviceCategory.SUSPECTED_CAMERA, "Smart Wi-Fi camera"),
        "54:E0:19" to VendorMatch("Ring / Amazon", DeviceCategory.SUSPECTED_CAMERA, "Doorbell / smart camera"),
        "00:62:6E" to VendorMatch("Amcrest / Foscam", DeviceCategory.SUSPECTED_CAMERA, "Wireless IP camera"),
        "00:12:12" to VendorMatch("Ubiquiti / UniFi", DeviceCategory.NETWORK_EQUIPMENT),
        "78:45:58" to VendorMatch("Ubiquiti Inc.", DeviceCategory.NETWORK_EQUIPMENT),
        "24:5A:4C" to VendorMatch("Ubiquiti Inc.", DeviceCategory.NETWORK_EQUIPMENT),
        // Embedded / DIY Wi-Fi Camera & IoT SoCs
        "24:0A:C4" to VendorMatch("Espressif Inc. (ESP32)", DeviceCategory.IOT_SMART_DEVICE, "Embedded Wi-Fi module often used in IoT & DIY pinhole cameras"),
        "30:AE:A4" to VendorMatch("Espressif Inc. (ESP32)", DeviceCategory.IOT_SMART_DEVICE, "Embedded Wi-Fi module"),
        "A4:CF:12" to VendorMatch("Espressif Inc. (ESP8266/32)", DeviceCategory.IOT_SMART_DEVICE),
        "DC:4F:22" to VendorMatch("Espressif Inc.", DeviceCategory.IOT_SMART_DEVICE),
        "B8:27:EB" to VendorMatch("Raspberry Pi Foundation", DeviceCategory.IOT_SMART_DEVICE, "Single-board computer"),
        "DC:A6:32" to VendorMatch("Raspberry Pi Trading", DeviceCategory.IOT_SMART_DEVICE, "Single-board computer"),
        "E4:5F:01" to VendorMatch("Raspberry Pi Trading", DeviceCategory.IOT_SMART_DEVICE, "Single-board computer"),
        // Networking / Routers
        "50:C7:BF" to VendorMatch("TP-Link Corporation", DeviceCategory.NETWORK_EQUIPMENT),
        "98:DA:C4" to VendorMatch("TP-Link Corporation", DeviceCategory.NETWORK_EQUIPMENT),
        "C0:25:E9" to VendorMatch("TP-Link Corporation", DeviceCategory.NETWORK_EQUIPMENT),
        "20:E5:2A" to VendorMatch("NETGEAR", DeviceCategory.NETWORK_EQUIPMENT),
        "A0:04:60" to VendorMatch("NETGEAR", DeviceCategory.NETWORK_EQUIPMENT),
        "00:1A:79" to VendorMatch("Cisco / Linksys", DeviceCategory.NETWORK_EQUIPMENT),
        "C8:3A:35" to VendorMatch("Tenda Technology", DeviceCategory.NETWORK_EQUIPMENT),
        "34:CE:00" to VendorMatch("Xiaomi Communications", DeviceCategory.IOT_SMART_DEVICE),
        // Consumer Mobile / Apple / Samsung / Google
        "00:1C:B3" to VendorMatch("Apple, Inc.", DeviceCategory.PERSONAL_ACCESSORY),
        "3C:15:C2" to VendorMatch("Apple, Inc.", DeviceCategory.PERSONAL_ACCESSORY),
        "F0:18:98" to VendorMatch("Apple, Inc.", DeviceCategory.PERSONAL_ACCESSORY),
        "00:16:32" to VendorMatch("Samsung Electronics", DeviceCategory.PERSONAL_ACCESSORY),
        "8C:77:12" to VendorMatch("Samsung Electronics", DeviceCategory.PERSONAL_ACCESSORY),
        "54:60:09" to VendorMatch("Google LLC", DeviceCategory.IOT_SMART_DEVICE),
        "F4:F5:D8" to VendorMatch("Google LLC", DeviceCategory.IOT_SMART_DEVICE),
        // Telematics / OBD-II
        "00:1E:42" to VendorMatch("Teltonika", DeviceCategory.VEHICLE_OBD),
        "00:04:3E" to VendorMatch("ELM Electronics / OBD-II", DeviceCategory.VEHICLE_OBD)
    )

    fun lookupBleCompany(companyId: Int): VendorMatch? = bleCompanyIds[companyId]

    fun lookupOui(macOrBssid: String?): VendorMatch? {
        if (macOrBssid.isNullOrBlank()) return null
        val cleaned = macOrBssid.uppercase().replace("-", ":")
        if (cleaned.length < 8) return null
        val prefix = cleaned.take(8)
        ouiPrefixes[prefix]?.let { return it }
        // Check locally administered / randomized MAC bit (second hex char in 2,6,A,E)
        val secondChar = cleaned.getOrNull(1)
        if (secondChar in listOf('2', '6', 'A', 'E')) {
            return VendorMatch("Randomized / Locally Administered MAC", null, "MAC address bit indicates privacy randomization")
        }
        return null
    }

    fun isRandomizedMac(mac: String?): Boolean {
        val hex = mac?.trim()?.uppercase()?.replace(":", "")?.replace("-", "") ?: return false
        if (hex.length < 2) return false
        return hex[1] in setOf('2', '6', 'A', 'E')
    }

    fun lookupNfcManufacturerByUid(uidBytes: ByteArray): String {
        if (uidBytes.isEmpty()) return "Unknown NFC Silicon"
        return when (uidBytes[0].toInt() and 0xFF) {
            0x04 -> "NXP Semiconductors (NTAG / MIFARE)"
            0x02 -> "STMicroelectronics"
            0x05 -> "Infineon Technologies"
            0x07 -> "Texas Instruments"
            0x01 -> "Motorola"
            0x16 -> "EM Microelectronic"
            0x03 -> "Freescale / NXP"
            0x08 -> "Broadcom / Random UID"
            else -> "ISO 14443 / NFC Manufacturer (0x%02X)".format(uidBytes[0].toInt() and 0xFF)
        }
    }
}
