package com.example.ui.screens

import android.Manifest
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.FlashlightOff
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.core.data.InvestigationContentCatalog
import com.example.core.database.InvestigationCaseEntity
import com.example.core.model.CapabilityStatus
import com.example.core.model.InvestigationMode
import com.example.ui.components.LimitationBanner
import com.example.ui.components.PermissionPromptCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.TacticalCard
import java.io.File
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HiddenCameraScreen(
    hasCameraPermission: Boolean,
    cameraStatus: CapabilityStatus,
    irStatus: CapabilityStatus,
    cases: List<InvestigationCaseEntity>,
    suspectedNetworkCameraCount: Int,
    persistedChecklist: Map<String, Boolean>,
    onChecklistChange: (Map<String, Boolean>) -> Unit,
    onRefreshPermissions: () -> Unit,
    onCaptureSavedToEvidence: (caseId: String, photoUri: String, notes: String) -> Unit,
    onCreateQuickCameraCaseAndSave: (photoUri: String, notes: String) -> Unit,
    onOpenNetworkAudit: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var torchEnabled by remember { mutableStateOf(false) }
    var useFrontCamera by remember { mutableStateOf(false) }
    var lastCapturedMessage by remember { mutableStateOf<String?>(null) }
    var boundCamera by remember { mutableStateOf<Camera?>(null) }
    val imageCapture = remember { ImageCapture.Builder().build() }
    var checkedTargets by remember(persistedChecklist) { mutableStateOf(persistedChecklist) }

    fun toggleTarget(targetId: String, checked: Boolean) {
        val updated = checkedTargets.toMutableMap().apply { put(targetId, checked) }
        checkedTargets = updated
        onChecklistChange(updated)
    }

    val permLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) {
        onRefreshPermissions()
    }

    DisposableEffect(Unit) {
        onDispose {
            runCatching { boundCamera?.cameraControl?.enableTorch(false) }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Hidden Camera Investigation") },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                LimitationBanner(
                    title = "Evidence & Verification Standard",
                    message = "A pinpoint lens reflection, IR glow, or unfamiliar LAN device never proves a hidden camera by itself. Always verify physically before taking action."
                )
            }

            if (!hasCameraPermission) {
                item {
                    PermissionPromptCard(
                        title = "Camera Permission Needed for Optical Sweep",
                        rationale = "SENTINEL uses CameraX + Flashlight for optical lens-reflection inspection and unmodified forensic photo documentation.",
                        buttonText = "Grant Camera Permission",
                        testTag = "camera_grant_permission_button",
                        onGrantClick = { permLauncher.launch(Manifest.permission.CAMERA) }
                    )
                }
            } else if (cameraStatus.supported) {
                item {
                    TacticalCard(accentColor = MaterialTheme.colorScheme.primary) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("Optical Lens Reflection & IR Inspector", style = MaterialTheme.typography.titleMedium)
                            Spacer(modifier = Modifier.height(6.dp))
                            var boundCameraIsFront by remember { mutableStateOf<Boolean?>(null) }
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(250.dp)
                            ) {
                                AndroidView(
                                    factory = { ctx ->
                                        PreviewView(ctx).apply {
                                            scaleType = PreviewView.ScaleType.FILL_CENTER
                                        }
                                    },
                                    update = { previewView ->
                                        if (boundCamera != null && boundCameraIsFront == useFrontCamera) {
                                            runCatching {
                                                boundCamera?.cameraControl?.enableTorch(!useFrontCamera && torchEnabled)
                                            }
                                            return@AndroidView
                                        }
                                        val targetFront = useFrontCamera
                                        val providerFuture = ProcessCameraProvider.getInstance(context)
                                        providerFuture.addListener({
                                            runCatching {
                                                val provider = providerFuture.get()
                                                val preview = Preview.Builder().build().also {
                                                    it.surfaceProvider = previewView.surfaceProvider
                                                }
                                                val selector = if (targetFront) {
                                                    CameraSelector.DEFAULT_FRONT_CAMERA
                                                } else {
                                                    CameraSelector.DEFAULT_BACK_CAMERA
                                                }
                                                provider.unbindAll()
                                                val cam = provider.bindToLifecycle(
                                                    lifecycleOwner,
                                                    selector,
                                                    preview,
                                                    imageCapture
                                                )
                                                boundCamera = cam
                                                boundCameraIsFront = targetFront
                                                cam.cameraControl.enableTorch(!targetFront && torchEnabled)
                                            }
                                        }, ContextCompat.getMainExecutor(context))
                                    },
                                    modifier = Modifier.fillMaxSize()
                                )
                                // Optical reticle overlay
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    val cx = size.width / 2f
                                    val cy = size.height / 2f
                                    drawCircle(
                                        color = Color(0xFF00E5FF).copy(alpha = 0.75f),
                                        radius = 44f,
                                        center = Offset(cx, cy),
                                        style = Stroke(width = 2.5f)
                                    )
                                    drawLine(Color(0xFF00E5FF), Offset(cx - 60f, cy), Offset(cx - 20f, cy), 2f)
                                    drawLine(Color(0xFF00E5FF), Offset(cx + 20f, cy), Offset(cx + 60f, cy), 2f)
                                    drawLine(Color(0xFF00E5FF), Offset(cx, cy - 60f), Offset(cx, cy - 20f), 2f)
                                    drawLine(Color(0xFF00E5FF), Offset(cx, cy + 20f), Offset(cx, cy + 60f), 2f)
                                }
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        torchEnabled = !torchEnabled
                                        runCatching { boundCamera?.cameraControl?.enableTorch(!useFrontCamera && torchEnabled) }
                                    },
                                    enabled = !useFrontCamera,
                                    modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("camera_torch_button")
                                ) {
                                    Icon(if (torchEnabled) Icons.Filled.FlashlightOn else Icons.Filled.FlashlightOff, contentDescription = null)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(if (torchEnabled) "Torch ON" else "Torch OFF")
                                }
                                OutlinedButton(
                                    onClick = {
                                        useFrontCamera = !useFrontCamera
                                        if (useFrontCamera) torchEnabled = false
                                    },
                                    modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("camera_switch_button")
                                ) {
                                    Icon(Icons.Filled.Cameraswitch, contentDescription = null)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(if (useFrontCamera) "Front (IR Test)" else "Rear Lens")
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = {
                                    val dir = File(context.filesDir, "evidence_photos").apply { mkdirs() }
                                    val photoFile = File(dir, "CAM_${UUID.randomUUID().toString().take(8)}.jpg")
                                    val output = ImageCapture.OutputFileOptions.Builder(photoFile).build()
                                    imageCapture.takePicture(
                                        output,
                                        ContextCompat.getMainExecutor(context),
                                        object : ImageCapture.OnImageSavedCallback {
                                            override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                                                val uri: Uri = FileProvider.getUriForFile(
                                                    context,
                                                    "${context.packageName}.fileprovider",
                                                    photoFile
                                                )
                                                val activeCase = cases.firstOrNull { it.status == "ACTIVE" }
                                                val note = "Optical inspection photo (${if (useFrontCamera) "Front" else "Rear"}, torch=$torchEnabled)"
                                                if (activeCase != null) {
                                                    onCaptureSavedToEvidence(activeCase.id, uri.toString(), note)
                                                    lastCapturedMessage = "Original photo preserved & hashed into Case ${activeCase.id}"
                                                } else {
                                                    onCreateQuickCameraCaseAndSave(uri.toString(), note)
                                                    lastCapturedMessage = "Created new Camera Investigation Case with SHA-256 photo evidence"
                                                }
                                            }

                                            override fun onError(exception: ImageCaptureException) {
                                                lastCapturedMessage = "Photo capture error: ${exception.localizedMessage}"
                                            }
                                        }
                                    )
                                },
                                modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag("camera_capture_evidence_button")
                            ) {
                                Icon(Icons.Filled.CameraAlt, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Capture Unmodified Evidence Photo")
                            }
                            lastCapturedMessage?.let {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                            }
                        }
                    }
                }
            }

            // Sensor IR & Network Camera Assessment
            item {
                TacticalCard {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("Camera Sensor & Network Camera Summary", style = MaterialTheme.typography.titleMedium)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Optical: ${cameraStatus.detail}", style = MaterialTheme.typography.bodySmall)
                        Text("IR / Monochrome: ${irStatus.detail}", style = MaterialTheme.typography.bodySmall)
                        Text(
                            text = "Network-connected camera suspects in local DB: $suspectedNetworkCameraCount",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = onOpenNetworkAudit,
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Text("Open Wi-Fi / LAN Camera Audit")
                        }
                    }
                }
            }

            item {
                val done = InvestigationContentCatalog.hiddenCameraPhysicalTargets.count { checkedTargets[it.id] == true }
                SectionHeader(
                    title = "Physical Concealment Inspection Guide",
                    subtitle = "$done / ${InvestigationContentCatalog.hiddenCameraPhysicalTargets.size} inspected"
                )
            }

            items(InvestigationContentCatalog.hiddenCameraPhysicalTargets, key = { it.id }) { target ->
                val checked = checkedTargets[target.id] == true
                TacticalCard(onClick = { toggleTarget(target.id, !checked) }) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Checkbox(checked = checked, onCheckedChange = { toggleTarget(target.id, it) })
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(target.title, style = MaterialTheme.typography.titleMedium)
                            Text(target.guidance, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}
