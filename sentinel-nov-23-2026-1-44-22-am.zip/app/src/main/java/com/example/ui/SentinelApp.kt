package com.example.ui

import android.content.Intent
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.FolderSpecial
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.outlined.Analytics
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.FolderSpecial
import androidx.compose.material.icons.outlined.Radar
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.SentinelApplication
import com.example.core.model.DetectionSource
import com.example.core.model.InvestigationMode
import com.example.core.model.RiskLevel
import com.example.core.model.UserDeviceStatus
import com.example.core.preferences.ChecklistJsonCodec
import com.example.services.ExtendedScanService
import com.example.ui.components.FirstScanPermissionsDialog
import com.example.ui.screens.AntiStalkingScreen
import com.example.ui.screens.BleScannerScreen
import com.example.ui.screens.CaseDetailScreen
import com.example.ui.screens.CasesListScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DeviceDetailScreen
import com.example.ui.screens.EducationCenterScreen
import com.example.ui.screens.ExternalRfScreen
import com.example.ui.screens.FullScanScreen
import com.example.ui.screens.GpsTrackerScreen
import com.example.ui.screens.HardwareDiagnosticsScreen
import com.example.ui.screens.HiddenCameraScreen
import com.example.ui.screens.IntelligenceHubScreen
import com.example.ui.screens.MagnetometerScreen
import com.example.ui.screens.ModeInvestigationScreen
import com.example.ui.screens.NfcRfidScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.SafetyAndSettingsScreen
import com.example.ui.screens.ScanToolsHubScreen
import com.example.ui.screens.UwbScreen
import com.example.ui.screens.WifiInvestigationScreen
import com.example.ui.theme.SentinelTheme

object SentinelRoutes {
    const val DASHBOARD = "dashboard"
    const val TOOLS = "tools"
    const val INTEL = "intel"
    const val CASES = "cases"
    const val SAFETY = "safety"
    const val FULL_SCAN = "full_scan"
    const val BLE = "ble_scanner"
    const val WIFI = "wifi_audit"
    const val HIDDEN_CAMERA = "hidden_camera"
    const val MAGNETOMETER = "magnetometer"
    const val GPS = "gps_tracker"
    const val NFC = "nfc_rfid"
    const val UWB = "uwb"
    const val EXTERNAL_RF = "external_rf"
    const val DIAGNOSTICS = "diagnostics"
    const val ANTI_STALKING = "anti_stalking"
    const val EDUCATION = "education"
    const val MODE_TEMPLATE = "mode/{modeId}"
    const val DEVICE_TEMPLATE = "device/{fingerprintId}"
    const val CASE_TEMPLATE = "case/{caseId}"

    fun mode(mode: InvestigationMode) = "mode/${mode.id}"
    fun device(fp: String) = "device/$fp"
    fun caseDetail(caseId: String) = "case/$caseId"
}

private data class TopNavTab(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SentinelApp(
    mainViewModel: SentinelViewModel,
    toolsViewModel: SensorToolsViewModel,
    onNfcScreenVisibilityChanged: (Boolean) -> Unit
) {
    val settings by mainViewModel.settings.collectAsStateWithLifecycle()
    val settingsLoaded by mainViewModel.settingsLoaded.collectAsStateWithLifecycle()
    val summary by mainViewModel.dashboardSummary.collectAsStateWithLifecycle()
    val devices by mainViewModel.observedDevices.collectAsStateWithLifecycle()
    val appearances by mainViewModel.allAppearances.collectAsStateWithLifecycle()
    val sessions by mainViewModel.scanSessions.collectAsStateWithLifecycle()
    val relationships by mainViewModel.relationships.collectAsStateWithLifecycle()
    val intelEntries by mainViewModel.intelEntries.collectAsStateWithLifecycle()
    val cases by mainViewModel.investigationCases.collectAsStateWithLifecycle()
    val fullScanState by mainViewModel.fullScanState.collectAsStateWithLifecycle()
    val lastArtifact by mainViewModel.lastExportedArtifact.collectAsStateWithLifecycle()
    val statusBanner by mainViewModel.statusBanner.collectAsStateWithLifecycle()

    val diagnostics by toolsViewModel.diagnostics.collectAsStateWithLifecycle()
    val permissionDescriptors by toolsViewModel.permissionDescriptors.collectAsStateWithLifecycle()
    val hasCoarseLocationOnly by toolsViewModel.hasCoarseLocationOnly.collectAsStateWithLifecycle()
    val bleScanning by toolsViewModel.bleScanning.collectAsStateWithLifecycle()
    val bleError by toolsViewModel.bleError.collectAsStateWithLifecycle()
    val bleDevices by toolsViewModel.bleDevices.collectAsStateWithLifecycle()
    val wifiScanning by toolsViewModel.wifiScanning.collectAsStateWithLifecycle()
    val wifiAps by toolsViewModel.wifiAps.collectAsStateWithLifecycle()
    val wifiBanner by toolsViewModel.wifiBanner.collectAsStateWithLifecycle()
    val connectedWifi by toolsViewModel.connectedWifiLabel.collectAsStateWithLifecycle()
    val lanScanning by toolsViewModel.lanScanning.collectAsStateWithLifecycle()
    val lanHosts by toolsViewModel.lanHosts.collectAsStateWithLifecycle()
    val lanBanner by toolsViewModel.lanBanner.collectAsStateWithLifecycle()
    val magRunning by toolsViewModel.magRunning.collectAsStateWithLifecycle()
    val magCurrent by toolsViewModel.magCurrent.collectAsStateWithLifecycle()
    val magBaseline by toolsViewModel.magBaselineUt.collectAsStateWithLifecycle()
    val magHistory by toolsViewModel.magHistory.collectAsStateWithLifecycle()
    val magAnomalyCount by toolsViewModel.magAnomalyCount.collectAsStateWithLifecycle()
    val nfcLastTag by toolsViewModel.nfcLastTag.collectAsStateWithLifecycle()
    val nfcTagHistory by toolsViewModel.nfcTagHistory.collectAsStateWithLifecycle()
    val uwbState by toolsViewModel.uwbState.collectAsStateWithLifecycle()
    val usbDevices by toolsViewModel.usbDevices.collectAsStateWithLifecycle()

    val extendedRunning by ExtendedScanService.isServiceRunning.collectAsStateWithLifecycle()
    val extendedSummary by ExtendedScanService.lastCycleSummary.collectAsStateWithLifecycle()

    val context = LocalContext.current
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: SentinelRoutes.DASHBOARD
    val snackbarHostState = remember { SnackbarHostState() }

    var pendingFirstScanAction by remember { mutableStateOf<(() -> Unit)?>(null) }
    var pendingPermissionGate by remember { mutableStateOf<(() -> String?)?>(null) }
    val firstScanPermLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        toolsViewModel.refreshDiagnostics()
        mainViewModel.markFirstScanPermissionsRequested()
        val action = pendingFirstScanAction
        val gateError = pendingPermissionGate?.invoke()
        pendingFirstScanAction = null
        pendingPermissionGate = null
        if (gateError != null) {
            mainViewModel.showStatusBanner(gateError)
        } else {
            action?.invoke()
        }
    }

    fun runWithFirstScanPermissionCheck(
        permissionGateError: (() -> String?)? = null,
        action: () -> Unit
    ) {
        toolsViewModel.refreshPermissionStateOnly()
        toolsViewModel.refreshDiagnosticsAsync()
        val missing = toolsViewModel.missingScanPermissions()
        if (!settings.firstScanPermissionsRequested && missing.isNotEmpty()) {
            pendingPermissionGate = permissionGateError
            pendingFirstScanAction = action
        } else {
            val gateError = permissionGateError?.invoke()
            if (gateError != null) {
                mainViewModel.showStatusBanner(gateError)
            } else {
                action()
            }
        }
    }

    LaunchedEffect(currentRoute) {
        onNfcScreenVisibilityChanged(currentRoute == SentinelRoutes.NFC)
    }

    LaunchedEffect(statusBanner) {
        statusBanner?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            mainViewModel.clearStatusBanner()
        }
    }

    val topTabs = remember {
        listOf(
            TopNavTab(SentinelRoutes.DASHBOARD, "Dashboard", Icons.Filled.Dashboard, Icons.Outlined.Dashboard),
            TopNavTab(SentinelRoutes.TOOLS, "Scan Tools", Icons.Filled.Radar, Icons.Outlined.Radar),
            TopNavTab(SentinelRoutes.INTEL, "Intel", Icons.Filled.Analytics, Icons.Outlined.Analytics),
            TopNavTab(SentinelRoutes.CASES, "Cases", Icons.Filled.FolderSpecial, Icons.Outlined.FolderSpecial),
            TopNavTab(SentinelRoutes.SAFETY, "Safety", Icons.Filled.Security, Icons.Outlined.Security)
        )
    }
    val isTopLevel = topTabs.any { it.route == currentRoute }

    SentinelTheme(
        themePreference = settings.themePreference,
        textScaleMultiplier = settings.textScaleMultiplier
    ) {
        if (!settingsLoaded) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colorScheme.background
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Shield,
                            contentDescription = "SENTINEL",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(48.dp)
                        )
                        Text(
                            text = "SENTINEL",
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        CircularProgressIndicator(
                            modifier = Modifier
                                .size(28.dp)
                                .testTag("sentinel_loading_indicator")
                        )
                        Text(
                            text = "Initializing local security database…",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            return@SentinelTheme
        }

        if (!settings.onboardingCompleted) {
            Scaffold(
                snackbarHost = { SnackbarHost(snackbarHostState) }
            ) { inner ->
                OnboardingScreen(
                    onFinish = { mainViewModel.completeOnboarding() },
                    modifier = Modifier.padding(inner)
                )
            }
            return@SentinelTheme
        }

        fun shareExportedArtifact(artifact: com.example.services.ExportedArtifact) {
            val container = (context.applicationContext as SentinelApplication).container
            val shareIntent = container.reportExporter.buildShareIntent(artifact)
            context.startActivity(Intent.createChooser(shareIntent, "Share SENTINEL Report"))
        }

        pendingFirstScanAction?.let { pendingAction ->
            FirstScanPermissionsDialog(
                descriptors = permissionDescriptors,
                onGrantAllAndScan = {
                    val missing = toolsViewModel.missingScanPermissions()
                    if (missing.isNotEmpty()) {
                        firstScanPermLauncher.launch(missing)
                    } else {
                        mainViewModel.markFirstScanPermissionsRequested()
                        pendingFirstScanAction = null
                        pendingAction()
                    }
                },
                onContinuePartialScan = {
                    mainViewModel.markFirstScanPermissionsRequested()
                    val gateError = pendingPermissionGate?.invoke()
                    pendingFirstScanAction = null
                    pendingPermissionGate = null
                    if (gateError != null) {
                        mainViewModel.showStatusBanner(gateError)
                    } else {
                        pendingAction()
                    }
                },
                onDismiss = {
                    pendingFirstScanAction = null
                    pendingPermissionGate = null
                }
            )
        }

        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useNavigationRail = maxWidth >= 600.dp

            Scaffold(
                snackbarHost = { SnackbarHost(snackbarHostState) },
                topBar = {
                    if (isTopLevel) {
                        CenterAlignedTopAppBar(
                            title = {
                                Text(
                                    text = "SENTINEL",
                                    style = MaterialTheme.typography.titleLarge
                                )
                            }
                        )
                    }
                },
                bottomBar = {
                    if (isTopLevel && !useNavigationRail) {
                        NavigationBar {
                            topTabs.forEach { tab ->
                                val selected = currentRoute == tab.route
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = {
                                        if (!selected) {
                                            navController.navigate(tab.route) {
                                                popUpTo(SentinelRoutes.DASHBOARD) { saveState = true }
                                                launchSingleTop = true
                                                restoreState = true
                                            }
                                        }
                                    },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = tab.label
                                        )
                                    },
                                    label = { Text(tab.label, maxLines = 1) },
                                    modifier = Modifier.testTag("nav_tab_${tab.route}")
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (isTopLevel && useNavigationRail) {
                        NavigationRail {
                            topTabs.forEach { tab ->
                                val selected = currentRoute == tab.route
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = {
                                        if (!selected) {
                                            navController.navigate(tab.route) {
                                                popUpTo(SentinelRoutes.DASHBOARD) { saveState = true }
                                                launchSingleTop = true
                                                restoreState = true
                                            }
                                        }
                                    },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = tab.label
                                        )
                                    },
                                    label = { Text(tab.label) },
                                    modifier = Modifier.testTag("rail_tab_${tab.route}")
                                )
                            }
                        }
                    }

                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.TopCenter
                    ) {
                        NavHost(
                            navController = navController,
                            startDestination = SentinelRoutes.DASHBOARD,
                            modifier = Modifier.widthIn(max = 920.dp).fillMaxSize()
                        ) {
                            composable(SentinelRoutes.DASHBOARD) {
                                DashboardScreen(
                                    summary = summary,
                                    recentDevices = devices,
                                    recentSessions = sessions,
                                    isFullScanRunning = fullScanState.isRunning,
                                    onStartFullScan = {
                                        runWithFirstScanPermissionCheck {
                                            if (!fullScanState.isRunning) {
                                                mainViewModel.startFullScan(InvestigationMode.DEEP)
                                            }
                                            navController.navigate(SentinelRoutes.FULL_SCAN)
                                        }
                                    },
                                    onOpenQuickBle = { navController.navigate(SentinelRoutes.BLE) },
                                    onOpenWifi = { navController.navigate(SentinelRoutes.WIFI) },
                                    onOpenHiddenCamera = { navController.navigate(SentinelRoutes.HIDDEN_CAMERA) },
                                    onOpenGpsInvestigation = { navController.navigate(SentinelRoutes.GPS) },
                                    onOpenVehicleMode = { navController.navigate(SentinelRoutes.mode(InvestigationMode.VEHICLE)) },
                                    onOpenMagnetometer = { navController.navigate(SentinelRoutes.MAGNETOMETER) },
                                    onOpenNfc = { navController.navigate(SentinelRoutes.NFC) },
                                    onOpenRfHardware = { navController.navigate(SentinelRoutes.EXTERNAL_RF) },
                                    onOpenCases = { navController.navigate(SentinelRoutes.CASES) },
                                    onOpenDeviceDetail = { fp -> navController.navigate(SentinelRoutes.device(fp)) },
                                    onOpenDiagnostics = { navController.navigate(SentinelRoutes.DIAGNOSTICS) },
                                    onOpenAntiStalking = { navController.navigate(SentinelRoutes.ANTI_STALKING) }
                                )
                            }

                            composable(SentinelRoutes.TOOLS) {
                                ScanToolsHubScreen(
                                    isExtendedServiceRunning = extendedRunning,
                                    extendedCycleSummary = extendedSummary,
                                    onStartFullScan = {
                                        runWithFirstScanPermissionCheck {
                                            if (!fullScanState.isRunning) {
                                                mainViewModel.startFullScan(InvestigationMode.DEEP)
                                            }
                                            navController.navigate(SentinelRoutes.FULL_SCAN)
                                        }
                                    },
                                    onToggleExtendedService = {
                                        if (extendedRunning) {
                                            val stopIntent = Intent(context, ExtendedScanService::class.java).apply {
                                                action = ExtendedScanService.ACTION_STOP
                                            }
                                            context.startService(stopIntent)
                                        } else {
                                            runWithFirstScanPermissionCheck(
                                                permissionGateError = {
                                                    if (!toolsViewModel.diagnostics.value.ble.permissionGranted) {
                                                        "Bluetooth Scan (BLUETOOTH_SCAN) permission is required for Extended Observation."
                                                    } else null
                                                }
                                            ) {
                                                val startIntent = Intent(context, ExtendedScanService::class.java)
                                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                                    context.startForegroundService(startIntent)
                                                } else {
                                                    context.startService(startIntent)
                                                }
                                            }
                                        }
                                    },
                                    onOpenMode = { mode -> navController.navigate(SentinelRoutes.mode(mode)) },
                                    onOpenBle = { navController.navigate(SentinelRoutes.BLE) },
                                    onOpenWifi = { navController.navigate(SentinelRoutes.WIFI) },
                                    onOpenHiddenCamera = { navController.navigate(SentinelRoutes.HIDDEN_CAMERA) },
                                    onOpenMagnetometer = { navController.navigate(SentinelRoutes.MAGNETOMETER) },
                                    onOpenGps = { navController.navigate(SentinelRoutes.GPS) },
                                    onOpenNfc = { navController.navigate(SentinelRoutes.NFC) },
                                    onOpenUwb = { navController.navigate(SentinelRoutes.UWB) },
                                    onOpenExternalRf = { navController.navigate(SentinelRoutes.EXTERNAL_RF) }
                                )
                            }

                            composable(SentinelRoutes.INTEL) {
                                IntelligenceHubScreen(
                                    devices = devices,
                                    appearances = appearances,
                                    relationships = relationships,
                                    intelEntries = intelEntries,
                                    optInLocationEnabled = settings.optInLocationCorrelation,
                                    onOpenDeviceDetail = { fp -> navController.navigate(SentinelRoutes.device(fp)) }
                                )
                            }

                            composable(SentinelRoutes.CASES) {
                                CasesListScreen(
                                    cases = cases,
                                    lastExportedArtifact = lastArtifact,
                                    onCreateCase = { title, mode, loc, notes ->
                                        mainViewModel.createCase(title, mode, loc, notes)
                                    },
                                    onOpenCaseDetail = { id -> navController.navigate(SentinelRoutes.caseDetail(id)) },
                                    onExportAll = { fmt -> mainViewModel.exportReport(fmt) },
                                    onShareArtifact = ::shareExportedArtifact
                                )
                            }

                            composable(SentinelRoutes.SAFETY) {
                                SafetyAndSettingsScreen(
                                    settings = settings,
                                    onSetTheme = mainViewModel::setThemePreference,
                                    onSetTextScale = mainViewModel::setTextScale,
                                    onSetOptInLocation = mainViewModel::setOptInLocation,
                                    onSetBleProfile = mainViewModel::setBleScanProfile,
                                    onSetTrackerAlerts = mainViewModel::setTrackerAlertsEnabled,
                                    onOpenAntiStalking = { navController.navigate(SentinelRoutes.ANTI_STALKING) },
                                    onOpenEducation = { navController.navigate(SentinelRoutes.EDUCATION) },
                                    onOpenDiagnostics = { navController.navigate(SentinelRoutes.DIAGNOSTICS) },
                                    onReopenOnboarding = mainViewModel::reopenOnboarding,
                                    onWipeAllData = mainViewModel::wipeAllUserData
                                )
                            }

                            composable(SentinelRoutes.FULL_SCAN) {
                                val missingScanPerms = remember(permissionDescriptors) {
                                    toolsViewModel.missingScanPermissions()
                                }
                                FullScanScreen(
                                    state = fullScanState,
                                    missingPermissions = missingScanPerms,
                                    bluetoothSupported = diagnostics.bluetooth.supported,
                                    bluetoothEnabled = diagnostics.bluetooth.enabled,
                                    wifiEnabled = diagnostics.wifi.enabled,
                                    locationServicesEnabled = diagnostics.locationServices.enabled,
                                    onRefreshPermissions = toolsViewModel::refreshDiagnostics,
                                    onStartScan = {
                                        runWithFirstScanPermissionCheck {
                                            mainViewModel.startFullScan(InvestigationMode.DEEP)
                                        }
                                    },
                                    onCancelScan = mainViewModel::cancelFullScan,
                                    onOpenDeviceDetail = { fp -> navController.navigate(SentinelRoutes.device(fp)) },
                                    onExportPdf = { mainViewModel.exportReport("PDF") },
                                    onExportJson = { mainViewModel.exportReport("JSON") },
                                    onBack = { navController.popBackStack() }
                                )
                            }

                            composable(
                                route = SentinelRoutes.MODE_TEMPLATE,
                                arguments = listOf(navArgument("modeId") { type = NavType.StringType })
                            ) { entry ->
                                val modeId = entry.arguments?.getString("modeId")
                                val mode = InvestigationMode.entries.firstOrNull { it.id == modeId } ?: InvestigationMode.PERSONAL
                                val activeModeCase = remember(cases, mode) {
                                    cases.firstOrNull { it.investigationType == mode.name && it.status == "ACTIVE" }
                                }
                                val scopeKey = "MODE_${mode.id}"
                                val persistedChecklist = remember(activeModeCase?.checklistStateJson, settings.checklistStatesJson, scopeKey) {
                                    if (activeModeCase != null) {
                                        ChecklistJsonCodec.parseFlatMap(activeModeCase.checklistStateJson)
                                    } else {
                                        ChecklistJsonCodec.parseScopedMap(settings.checklistStatesJson, scopeKey)
                                    }
                                }
                                ModeInvestigationScreen(
                                    mode = mode,
                                    observedDevices = devices,
                                    persistedChecklist = persistedChecklist,
                                    onChecklistChange = { updated ->
                                        mainViewModel.updateChecklistState(scopeKey, activeModeCase?.id, updated)
                                    },
                                    onRunModeScan = {
                                        runWithFirstScanPermissionCheck {
                                            mainViewModel.startFullScan(mode)
                                            navController.navigate(SentinelRoutes.FULL_SCAN)
                                        }
                                    },
                                    onCreateCaseForMode = { title, m, notes, checklistJson ->
                                        mainViewModel.createCase(title, m, "", notes, checklistJson) { newId ->
                                            navController.navigate(SentinelRoutes.caseDetail(newId))
                                        }
                                    },
                                    onOpenModule = { src ->
                                        when (src) {
                                            DetectionSource.BLE -> navController.navigate(SentinelRoutes.BLE)
                                            DetectionSource.WIFI_AP, DetectionSource.LAN_HOST -> navController.navigate(SentinelRoutes.WIFI)
                                            DetectionSource.OPTICAL_CAMERA -> navController.navigate(SentinelRoutes.HIDDEN_CAMERA)
                                            DetectionSource.MAGNETOMETER -> navController.navigate(SentinelRoutes.MAGNETOMETER)
                                            DetectionSource.NFC_TAG -> navController.navigate(SentinelRoutes.NFC)
                                            DetectionSource.UWB -> navController.navigate(SentinelRoutes.UWB)
                                            DetectionSource.EXTERNAL_RF -> navController.navigate(SentinelRoutes.EXTERNAL_RF)
                                            else -> navController.navigate(SentinelRoutes.FULL_SCAN)
                                        }
                                    },
                                    onOpenDeviceDetail = { fp -> navController.navigate(SentinelRoutes.device(fp)) },
                                    onExportPdf = { mainViewModel.exportReport("PDF") },
                                    onBack = { navController.popBackStack() }
                                )
                            }

                            composable(SentinelRoutes.BLE) {
                                BleScannerScreen(
                                    isScanning = bleScanning,
                                    errorMessage = bleError,
                                    devices = bleDevices,
                                    hasPermission = diagnostics.ble.permissionGranted,
                                    bluetoothSupported = diagnostics.bluetooth.supported,
                                    bluetoothEnabled = diagnostics.bluetooth.enabled,
                                    bleScannerAvailable = diagnostics.ble.enabled,
                                    firstScanPermissionsRequested = settings.firstScanPermissionsRequested,
                                    scanProfile = settings.bleScanProfile,
                                    onStartScan = {
                                        runWithFirstScanPermissionCheck(
                                            permissionGateError = {
                                                if (!toolsViewModel.diagnostics.value.ble.permissionGranted) {
                                                    "Bluetooth scan permission is required before starting BLE scan."
                                                } else null
                                            }
                                        ) {
                                            toolsViewModel.startBleScan(settings.bleScanProfile, settings.optInLocationCorrelation)
                                        }
                                    },
                                    onStopScan = toolsViewModel::stopBleScan,
                                    onRefreshPermissions = toolsViewModel::refreshDiagnostics,
                                    onOpenDeviceDetail = { fp -> navController.navigate(SentinelRoutes.device(fp)) },
                                    onOpenAndroidTrackerAlerts = {
                                        runCatching { context.startActivity(toolsViewModel.getAndroidTrackerSafetyIntent()) }
                                    },
                                    onBack = { navController.popBackStack() }
                                )
                            }

                            composable(SentinelRoutes.WIFI) {
                                WifiInvestigationScreen(
                                    hasLocationPermission = diagnostics.wifi.permissionGranted,
                                    hasCoarseOnly = hasCoarseLocationOnly,
                                    wifiEnabled = diagnostics.wifi.enabled,
                                    locationServicesEnabled = diagnostics.locationServices.enabled,
                                    firstScanPermissionsRequested = settings.firstScanPermissionsRequested,
                                    wifiScanning = wifiScanning,
                                    lanScanning = lanScanning,
                                    connectedSummary = connectedWifi,
                                    wifiBanner = wifiBanner,
                                    lanBanner = lanBanner,
                                    accessPoints = wifiAps,
                                    lanHosts = lanHosts,
                                    onRefreshPermissions = toolsViewModel::refreshDiagnostics,
                                    onRunWifiScan = {
                                        runWithFirstScanPermissionCheck(
                                            permissionGateError = {
                                                if (!toolsViewModel.diagnostics.value.wifi.permissionGranted) {
                                                    "Precise Location (ACCESS_FINE_LOCATION) permission is required for Wi-Fi scans."
                                                } else null
                                            }
                                        ) {
                                            toolsViewModel.runWifiScan(settings.optInLocationCorrelation)
                                        }
                                    },
                                    onRunAuthorizedLanScan = { toolsViewModel.runAuthorizedLanScan(settings.optInLocationCorrelation) },
                                    onBack = { navController.popBackStack() }
                                )
                            }

                            composable(SentinelRoutes.HIDDEN_CAMERA) {
                                val activeCameraCase = remember(cases) {
                                    cases.firstOrNull {
                                        it.status == "ACTIVE" &&
                                            (it.investigationType == InvestigationMode.HOTEL.name || it.investigationType == InvestigationMode.HOME.name)
                                    }
                                }
                                val camChecklist = remember(activeCameraCase?.checklistStateJson, settings.checklistStatesJson) {
                                    if (activeCameraCase != null) {
                                        ChecklistJsonCodec.parseFlatMap(activeCameraCase.checklistStateJson)
                                    } else {
                                        ChecklistJsonCodec.parseScopedMap(settings.checklistStatesJson, "HIDDEN_CAMERA")
                                    }
                                }
                                HiddenCameraScreen(
                                    hasCameraPermission = diagnostics.cameraOptical.permissionGranted,
                                    cameraStatus = diagnostics.cameraOptical,
                                    irStatus = diagnostics.infraredCamera,
                                    cases = cases,
                                    suspectedNetworkCameraCount = summary.potentialCamerasCount,
                                    persistedChecklist = camChecklist,
                                    onChecklistChange = { updated ->
                                        mainViewModel.updateChecklistState("HIDDEN_CAMERA", activeCameraCase?.id, updated)
                                    },
                                    onRefreshPermissions = toolsViewModel::refreshDiagnostics,
                                    onCaptureSavedToEvidence = { caseId, uri, notes ->
                                        mainViewModel.addEvidenceToCase(
                                            caseId = caseId,
                                            detectionMethod = DetectionSource.OPTICAL_CAMERA.name,
                                            deviceFingerprintId = null,
                                            deviceSummary = "Optical Camera Inspection Photo",
                                            supportingObservations = "Captured via CameraX Optical Inspector",
                                            notes = notes,
                                            photoUri = uri,
                                            riskLevelSnapshot = RiskLevel.MODERATE.name
                                        )
                                    },
                                    onCreateQuickCameraCaseAndSave = { uri, notes ->
                                        mainViewModel.createCase(
                                            title = "Camera Optical Sweep",
                                            mode = InvestigationMode.HOTEL,
                                            locationNote = "",
                                            notes = "Created from Hidden Camera Inspection."
                                        ) { newCaseId ->
                                            mainViewModel.addEvidenceToCase(
                                                caseId = newCaseId,
                                                detectionMethod = DetectionSource.OPTICAL_CAMERA.name,
                                                deviceFingerprintId = null,
                                                deviceSummary = "Optical Camera Inspection Photo",
                                                supportingObservations = "Captured via CameraX Optical Inspector",
                                                notes = notes,
                                                photoUri = uri,
                                                riskLevelSnapshot = RiskLevel.MODERATE.name
                                            )
                                        }
                                    },
                                    onOpenNetworkAudit = { navController.navigate(SentinelRoutes.WIFI) },
                                    onBack = { navController.popBackStack() }
                                )
                            }

                            composable(SentinelRoutes.MAGNETOMETER) {
                                MagnetometerScreen(
                                    isAvailable = toolsViewModel.isMagnetometerAvailable(),
                                    sensorMetadata = toolsViewModel.magnetometerMetadata(),
                                    isRunning = magRunning,
                                    currentSample = magCurrent,
                                    baselineUt = magBaseline,
                                    history = magHistory,
                                    sensitivityUt = settings.magnetometerSensitivityUt,
                                    anomalyCount = magAnomalyCount,
                                    onStart = { toolsViewModel.startMagnetometer(settings.magnetometerSensitivityUt) },
                                    onStop = toolsViewModel::stopMagnetometer,
                                    onCalibrate = toolsViewModel::calibrateMagnetometerBaseline,
                                    onSensitivityChange = mainViewModel::setMagnetometerSensitivity,
                                    onBack = { navController.popBackStack() }
                                )
                            }

                            composable(SentinelRoutes.GPS) {
                                val activeVehicleCase = remember(cases) {
                                    cases.firstOrNull { it.investigationType == InvestigationMode.VEHICLE.name && it.status == "ACTIVE" }
                                }
                                val vehicleChecklist = remember(activeVehicleCase?.checklistStateJson, settings.checklistStatesJson) {
                                    if (activeVehicleCase != null) {
                                        ChecklistJsonCodec.parseFlatMap(activeVehicleCase.checklistStateJson)
                                    } else {
                                        ChecklistJsonCodec.parseScopedMap(settings.checklistStatesJson, "GPS_VEHICLE")
                                    }
                                }
                                GpsTrackerScreen(
                                    intelEntries = intelEntries,
                                    persistedChecklist = vehicleChecklist,
                                    onChecklistChange = { updated ->
                                        mainViewModel.updateChecklistState("GPS_VEHICLE", activeVehicleCase?.id, updated)
                                    },
                                    onOpenMagnetometer = { navController.navigate(SentinelRoutes.MAGNETOMETER) },
                                    onOpenBleScanner = { navController.navigate(SentinelRoutes.BLE) },
                                    onOpenExternalRf = { navController.navigate(SentinelRoutes.EXTERNAL_RF) },
                                    onBack = { navController.popBackStack() }
                                )
                            }

                            composable(SentinelRoutes.NFC) {
                                NfcRfidScreen(
                                    nfcSupported = toolsViewModel.isNfcSupported(),
                                    nfcEnabled = toolsViewModel.isNfcEnabled(),
                                    lastTag = nfcLastTag,
                                    tagHistory = nfcTagHistory,
                                    externalRfidSpecs = toolsViewModel.externalRfidSpecs(),
                                    onBack = { navController.popBackStack() }
                                )
                            }

                            composable(SentinelRoutes.UWB) {
                                UwbScreen(
                                    uwbState = uwbState,
                                    onRefreshUwb = toolsViewModel::refreshUwbDiagnostics,
                                    onBack = { navController.popBackStack() }
                                )
                            }

                            composable(SentinelRoutes.EXTERNAL_RF) {
                                ExternalRfScreen(
                                    usbHostSupported = toolsViewModel.isUsbHostSupported(),
                                    attachedDevices = usbDevices,
                                    compatibilityList = toolsViewModel.externalRfCompatibilityList(),
                                    onRefreshUsb = toolsViewModel::refreshUsbHardware,
                                    onBack = { navController.popBackStack() }
                                )
                            }

                            composable(SentinelRoutes.DIAGNOSTICS) {
                                HardwareDiagnosticsScreen(
                                    report = diagnostics,
                                    missingPermissions = toolsViewModel.missingScanPermissions(),
                                    onRefresh = toolsViewModel::refreshDiagnostics,
                                    onExportJsonReport = { mainViewModel.exportReport("JSON") },
                                    onBack = { navController.popBackStack() }
                                )
                            }

                            composable(SentinelRoutes.ANTI_STALKING) {
                                AntiStalkingScreen(
                                    devices = devices,
                                    onOpenDeviceDetail = { fp -> navController.navigate(SentinelRoutes.device(fp)) },
                                    onOpenAndroidTrackerAlerts = {
                                        runCatching { context.startActivity(toolsViewModel.getAndroidTrackerSafetyIntent()) }
                                    },
                                    onBack = { navController.popBackStack() }
                                )
                            }

                            composable(SentinelRoutes.EDUCATION) {
                                EducationCenterScreen(onBack = { navController.popBackStack() })
                            }

                            composable(
                                route = SentinelRoutes.DEVICE_TEMPLATE,
                                arguments = listOf(navArgument("fingerprintId") { type = NavType.StringType })
                            ) { entry ->
                                val fp = entry.arguments?.getString("fingerprintId") ?: ""
                                val dev by mainViewModel.observeDevice(fp).collectAsStateWithLifecycle(initialValue = null)
                                val devApps by mainViewModel.observeAppearancesForDevice(fp).collectAsStateWithLifecycle(initialValue = emptyList())
                                DeviceDetailScreen(
                                    device = dev,
                                    appearances = devApps,
                                    cases = cases,
                                    onUpdateStatus = { newStatus -> mainViewModel.updateDeviceStatus(fp, newStatus) },
                                    onSaveAsEvidence = { caseId, notes ->
                                        dev?.let { d ->
                                            mainViewModel.addEvidenceToCase(
                                                caseId = caseId,
                                                detectionMethod = d.sourceType,
                                                deviceFingerprintId = d.fingerprintId,
                                                deviceSummary = "${d.displayName} (${d.manufacturerName})",
                                                supportingObservations = d.riskReasoning,
                                                notes = notes,
                                                photoUri = null,
                                                riskLevelSnapshot = d.riskLevel
                                            )
                                        }
                                    },
                                    onCreateCaseAndSaveEvidence = { name, notes ->
                                        mainViewModel.createCase(
                                            title = "Device Investigation: $name",
                                            mode = InvestigationMode.PERSONAL,
                                            locationNote = "",
                                            notes = notes
                                        ) { newCaseId ->
                                            dev?.let { d ->
                                                mainViewModel.addEvidenceToCase(
                                                    caseId = newCaseId,
                                                    detectionMethod = d.sourceType,
                                                    deviceFingerprintId = d.fingerprintId,
                                                    deviceSummary = "${d.displayName} (${d.manufacturerName})",
                                                    supportingObservations = d.riskReasoning,
                                                    notes = notes,
                                                    photoUri = null,
                                                    riskLevelSnapshot = d.riskLevel
                                                )
                                            }
                                        }
                                    },
                                    onExportDevicePdf = { mainViewModel.exportReport("PDF", deviceId = fp) },
                                    onBack = { navController.popBackStack() }
                                )
                            }

                            composable(
                                route = SentinelRoutes.CASE_TEMPLATE,
                                arguments = listOf(navArgument("caseId") { type = NavType.StringType })
                            ) { entry ->
                                val caseId = entry.arguments?.getString("caseId") ?: ""
                                val caseEntity by mainViewModel.observeCase(caseId).collectAsStateWithLifecycle(initialValue = null)
                                val evList by mainViewModel.observeEvidenceForCase(caseId).collectAsStateWithLifecycle(initialValue = emptyList())
                                CaseDetailScreen(
                                    caseEntity = caseEntity,
                                    evidenceList = evList,
                                    decryptNotes = mainViewModel::decryptNotes,
                                    lastExportedArtifact = lastArtifact,
                                    onUpdateCase = { notes, status -> mainViewModel.updateCase(caseId, notes, status) },
                                    onDeleteCase = { mainViewModel.deleteCase(caseId) },
                                    onAddEvidence = { method, summaryTxt, obs, notes, uri ->
                                        mainViewModel.addEvidenceToCase(
                                            caseId = caseId,
                                            detectionMethod = method,
                                            deviceFingerprintId = null,
                                            deviceSummary = summaryTxt,
                                            supportingObservations = obs,
                                            notes = notes,
                                            photoUri = uri,
                                            riskLevelSnapshot = RiskLevel.MODERATE.name
                                        )
                                    },
                                    onAnnotateEvidence = { rec, ann -> mainViewModel.annotateEvidence(rec, ann) },
                                    onDeleteEvidence = { id -> mainViewModel.deleteEvidence(id) },
                                    onExportCase = { fmt -> mainViewModel.exportReport(fmt, caseId = caseId) },
                                    onShareArtifact = ::shareExportedArtifact,
                                    onBack = { navController.popBackStack() }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
