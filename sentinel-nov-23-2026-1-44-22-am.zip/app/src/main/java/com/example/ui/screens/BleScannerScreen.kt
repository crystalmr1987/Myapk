package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.BluetoothSearching
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.core.model.BleScanProfile
import com.example.ui.BleLiveDeviceEntry
import com.example.ui.components.EmptyStatePanel
import com.example.ui.components.LimitationBanner
import com.example.ui.components.PermissionPromptCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.TacticalCard
import com.example.ui.components.TelemetryLineChart
import com.example.ui.theme.LocalSentinelPalette

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BleScannerScreen(
    isScanning: Boolean,
    errorMessage: String?,
    devices: List<BleLiveDeviceEntry>,
    hasPermission: Boolean,
    bluetoothSupported: Boolean,
    bluetoothEnabled: Boolean,
    bleScannerAvailable: Boolean,
    firstScanPermissionsRequested: Boolean,
    scanProfile: BleScanProfile,
    onStartScan: () -> Unit,
    onStopScan: () -> Unit,
    onRefreshPermissions: () -> Unit,
    onOpenDeviceDetail: (String) -> Unit,
    onOpenAndroidTrackerAlerts: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val palette = LocalSentinelPalette.current
    var selectedFp by remember { mutableStateOf<String?>(null) }
    var permHint by remember { mutableStateOf<String?>(null) }

    val requiredPerms = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        }
    }

    val permLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        onRefreshPermissions()
        val scanPermGranted = when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
                results[Manifest.permission.BLUETOOTH_SCAN] == true
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q ->
                results[Manifest.permission.ACCESS_FINE_LOCATION] == true
            else ->
                results[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                    results[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        }
        if (scanPermGranted) {
            permHint = null
            if (bluetoothSupported && bluetoothEnabled && bleScannerAvailable) {
                onStartScan()
            }
        } else {
            val neededLabel = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                "Nearby devices (BLUETOOTH_SCAN)"
            } else {
                "Precise Location (ACCESS_FINE_LOCATION)"
            }
            permHint = "Android did not grant $neededLabel permission. If no system dialog appeared, tap 'App Settings' > Permissions to allow it."
        }
    }

    val selectedEntry = devices.firstOrNull { it.fingerprintId == selectedFp } ?: devices.firstOrNull()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Bluetooth LE Tracker Scanner") },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (!hasPermission) {
                item {
                    PermissionPromptCard(
                        title = "Bluetooth Scan Permission Required",
                        rationale = permHint ?: "SENTINEL needs Android Bluetooth Scan & Connect permissions strictly to inspect nearby BLE advertisements locally. No data leaves your phone.",
                        buttonText = "Grant Bluetooth Permissions",
                        testTag = "ble_grant_permission_button",
                        onGrantClick = { permLauncher.launch(requiredPerms) },
                        secondaryButtonText = "App Settings",
                        onSecondaryClick = {
                            val intent = Intent(
                                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.fromParts("package", context.packageName, null)
                            )
                            runCatching { context.startActivity(intent) }
                        }
                    )
                }
            }

            item {
                TacticalCard(accentColor = MaterialTheme.colorScheme.primary) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = if (isScanning) "Scanning (${scanProfile.label})..." else "Ready • Profile: ${scanProfile.label}",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        val radioStatusText = when {
                            !bluetoothSupported -> "Bluetooth Radio: Unavailable or HAL inactive on this device/emulator"
                            !bluetoothEnabled -> "Bluetooth Radio: OFF (Enable Bluetooth to scan)"
                            !bleScannerAvailable -> "Bluetooth Radio: ON • BLE Scanner unavailable on this device/emulator"
                            else -> "Bluetooth Radio: ON • BLE Scanner Ready"
                        }
                        val radioStatusColor = when {
                            !bluetoothSupported || !bluetoothEnabled || !bleScannerAvailable -> palette.moderate
                            else -> palette.low
                        }
                        Text(
                            text = radioStatusText,
                            style = MaterialTheme.typography.labelMedium,
                            color = radioStatusColor
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Detects AirTag/Find My, SmartTag, Tile, Chipolo, Pebblebee & unknown BLE transmitters with MAC rotation correlation.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    onRefreshPermissions()
                                    when {
                                        isScanning -> onStopScan()
                                        !hasPermission && firstScanPermissionsRequested -> permLauncher.launch(requiredPerms)
                                        else -> onStartScan()
                                    }
                                },
                                modifier = Modifier.minimumInteractiveComponentSize().testTag("ble_scan_toggle_button")
                            ) {
                                Icon(if (isScanning) Icons.Filled.Stop else Icons.Filled.PlayArrow, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (isScanning) "Stop Scan" else "Start BLE Scan")
                            }
                            if (!bluetoothEnabled) {
                                OutlinedButton(
                                    onClick = {
                                        runCatching { context.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
                                    },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Text("Bluetooth Settings")
                                }
                            } else {
                                OutlinedButton(
                                    onClick = onOpenAndroidTrackerAlerts,
                                    modifier = Modifier.minimumInteractiveComponentSize().testTag("ble_android_safety_button")
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("OS Tracker Alerts")
                                }
                            }
                        }
                    }
                }
            }

            if (errorMessage != null) {
                item {
                    LimitationBanner(
                        title = "Bluetooth Scanner Status",
                        message = errorMessage,
                        tint = palette.high
                    )
                }
            }

            // Real-time BLE Signal Graph
            item {
                TacticalCard {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = selectedEntry?.let { "Live RSSI Trend: ${it.latestFrame.name}" } ?: "Real-Time BLE Signal Graph",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        TelemetryLineChart(
                            values = selectedEntry?.rssiHistory?.map { it.toFloat() } ?: emptyList(),
                            lineColor = palette.cyanAccent,
                            unitLabel = "dBm",
                            emptyMessage = "Run a BLE scan and tap any device below to inspect its live RSSI signal curve."
                        )
                    }
                }
            }

            item {
                SectionHeader(
                    title = "Observed BLE Transmitters (${devices.size})",
                    subtitle = "Presence of an unknown BLE device alone does not prove unauthorized tracking"
                )
            }

            if (devices.isEmpty()) {
                item {
                    EmptyStatePanel(
                        icon = Icons.AutoMirrored.Filled.BluetoothSearching,
                        title = if (isScanning) "Listening for BLE Advertisements..." else "No BLE Frames Recorded in This Session",
                        tip = "Start a BLE scan with Bluetooth enabled. Note that BLE scanning is unavailable in emulators without a virtual BLE radio."
                    )
                }
            } else {
                items(devices, key = { it.fingerprintId }) { entry ->
                    val f = entry.latestFrame
                    TacticalCard(
                        accentColor = if (f.isTrackerSignature) palette.high else null,
                        onClick = { selectedFp = entry.fingerprintId },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(f.name, style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        text = "${f.manufacturerName} • ${f.address} (${f.addressType})",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    text = "${f.rssi} dBm",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = if (f.rssi >= -65) palette.high else palette.cyanAccent
                                )
                            }
                            if (f.trackerSignatureNote != null) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = f.trackerSignatureNote,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = palette.high
                                )
                            }
                            if (f.serviceUuids.isNotEmpty()) {
                                Text(
                                    text = "UUIDs: ${f.serviceUuids.joinToString(", ")} • Frames: ${entry.seenCount}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedButton(
                                onClick = { onOpenDeviceDetail(entry.fingerprintId) },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Text("Inspect Intelligence & Risk")
                            }
                        }
                    }
                }
            }
        }
    }
}
