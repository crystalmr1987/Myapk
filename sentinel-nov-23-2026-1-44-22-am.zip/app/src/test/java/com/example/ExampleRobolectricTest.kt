package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("SENTINEL", appName)
    }

    @Test
    fun `diagnostics report returns device metadata cleanly`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val diag = (context.applicationContext as SentinelApplication).container.diagnosticsManager.generateReport()
        assertNotNull(diag.manufacturer)
        assertNotNull(diag.ble)
        assertNotNull(diag.wifi)
        assertNotNull(diag.magnetometer)
    }
}
