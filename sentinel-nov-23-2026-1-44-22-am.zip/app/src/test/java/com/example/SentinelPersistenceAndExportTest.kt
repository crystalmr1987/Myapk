package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.core.intelligence.RawDeviceObservation
import com.example.core.model.DetectionSource
import com.example.core.model.InvestigationMode
import com.example.core.preferences.ChecklistJsonCodec
import com.example.core.security.DecryptionException
import com.example.core.security.KeystoreCryptoManager
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.test.runTest
import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class SentinelPersistenceAndExportTest {

    @Test
    fun `encrypts case notes, preserves original evidence, and exports PDF CSV JSON with sha256`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val container = (context.applicationContext as SentinelApplication).container
        val repo = container.repository

        repo.ensureIntelSeeded()
        val createdCase = repo.createCase(
            title = "Vehicle Check",
            investigationType = InvestigationMode.VEHICLE,
            locationNote = "Rear bumper inspection",
            plainNotes = "Sensitive serial 9912-XYZ"
        )
        assertNotEquals("Sensitive serial 9912-XYZ", createdCase.encryptedNotesCiphertext)
        assertEquals(
            "Sensitive serial 9912-XYZ",
            KeystoreCryptoManager.decrypt(createdCase.encryptedNotesCiphertext, createdCase.notesIv)
        )

        val obs = RawDeviceObservation(
            source = DetectionSource.BLE,
            displayName = "Suspicious OBD Beacon",
            rawAddress = "00:1E:42:11:22:33",
            addressType = "PUBLIC",
            manufacturerName = "Teltonika Telematics",
            companyIdOrOui = "0x089A",
            serviceUuids = listOf("FFF0"),
            manufacturerDataHex = "AABBCC",
            rssi = -58,
            timestamp = System.currentTimeMillis()
        )
        val savedDevice = repo.recordObservation("SCAN-TEST-1", obs)
        val evidence = repo.addEvidenceRecord(
            caseId = createdCase.id,
            detectionMethod = DetectionSource.BLE.name,
            deviceFingerprintId = savedDevice.fingerprintId,
            deviceSummary = savedDevice.displayName,
            supportingObservations = savedDevice.riskReasoning,
            plainNotes = "Original untouched field observation",
            photoUri = null,
            latitude = null,
            longitude = null,
            riskLevelSnapshot = savedDevice.riskLevel
        )
        repo.updateEvidenceAnnotation(evidence, "Follow-up annotation")
        val caseEvidence = repo.getEvidenceForCaseSync(createdCase.id)
        assertEquals(1, caseEvidence.size)
        assertEquals(
            "Original untouched field observation",
            KeystoreCryptoManager.decrypt(caseEvidence.first().encryptedNotesCiphertext, caseEvidence.first().notesIv)
        )
        assertEquals("Follow-up annotation", caseEvidence.first().editedAnnotationNote)

        val diag = container.diagnosticsManager.generateReport()
        val devices = repo.getAllDevicesSync()
        val pdf = container.reportExporter.exportPdfReport("TEST-PDF", "Test Report", diag, emptyList(), devices, listOf(createdCase), caseEvidence)
        val csv = container.reportExporter.exportCsvReport("TEST-CSV", devices)
        val json = container.reportExporter.exportJsonReport("TEST-JSON", "Test Report", diag, emptyList(), devices, listOf(createdCase), caseEvidence)

        assertTrue(pdf.file.exists() && pdf.file.length() > 100 && pdf.sha256.length == 64)
        assertTrue(csv.file.exists() && csv.file.readText().contains("Suspicious OBD Beacon"))
        assertTrue(json.file.exists() && json.file.readText().contains("Sensitive serial 9912-XYZ"))

        repo.wipeAllUserData()
        assertEquals(0, repo.getAllDevicesSync().size)
    }

    @Test
    fun `keystore decrypt returns null and failure Result on invalid ciphertext and supports concurrent calls`() = runTest {
        assertNull(KeystoreCryptoManager.decrypt("not-valid-base64!", "bad-iv!"))
        val failure = KeystoreCryptoManager.decryptResult("AAAA", "BBBB").exceptionOrNull()
        assertTrue(failure is DecryptionException)

        val roundTrips = (1..8).map { i ->
            async {
                val msg = "Concurrent secret note #$i"
                val enc = KeystoreCryptoManager.encrypt(msg)
                KeystoreCryptoManager.decrypt(enc.ciphertextBase64, enc.ivBase64) == msg
            }
        }.awaitAll()
        assertTrue(roundTrips.all { it })
    }

    @Test
    fun `fallback minimal pdf writes accurate byte offsets in xref and startxref`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val container = (context.applicationContext as SentinelApplication).container
        val outFile = File(context.cacheDir, "test_fallback_xref.pdf")
        outFile.delete()

        container.reportExporter.writeMinimalValidPdf(
            file = outFile,
            lines = listOf("SENTINEL REPORT", "Line 2 (escaped parens)")
        )

        val bytes = outFile.readBytes()
        val text = bytes.toString(Charsets.US_ASCII)
        assertTrue(text.startsWith("%PDF-1.4\n"))
        assertTrue(text.contains("%%EOF"))

        val startXrefMatch = Regex("startxref\\n(\\d+)\\n").find(text)
        assertTrue("Expected startxref offset", startXrefMatch != null)
        val xrefOffset = startXrefMatch!!.groupValues[1].toInt()
        assertEquals("xref\n", text.substring(xrefOffset, xrefOffset + 5))

        val entryMatches = Regex("(\\d{10}) 00000 n ").findAll(text).toList()
        assertEquals(5, entryMatches.size)
        entryMatches.forEachIndexed { idx, match ->
            val objOffset = match.groupValues[1].toInt()
            val expectedPrefix = "${idx + 1} 0 obj\n"
            assertEquals(expectedPrefix, text.substring(objOffset, objOffset + expectedPrefix.length))
        }
        outFile.delete()
    }

    @Test
    fun `checklist codec and case creation persist checklist state`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val container = (context.applicationContext as SentinelApplication).container
        val encoded = ChecklistJsonCodec.encodeFlatMap(mapOf("veh_1" to true, "veh_2" to false, "veh_3" to true))
        val created = container.repository.createCase(
            title = "Checklist Persistence",
            investigationType = InvestigationMode.VEHICLE,
            locationNote = "Driveway",
            plainNotes = "Notes",
            initialChecklistJson = encoded
        )
        val parsed = ChecklistJsonCodec.parseFlatMap(created.checklistStateJson)
        assertEquals(true, parsed["veh_1"])
        assertEquals(null, parsed["veh_2"])
        assertEquals(true, parsed["veh_3"])
        container.repository.wipeAllUserData()
    }
}
