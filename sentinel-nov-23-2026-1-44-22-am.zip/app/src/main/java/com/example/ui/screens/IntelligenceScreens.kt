package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FolderSpecial
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.core.database.DeviceAppearanceEntity
import com.example.core.database.DeviceIntelEntryEntity
import com.example.core.database.InvestigationCaseEntity
import com.example.core.database.ObservedDeviceEntity
import com.example.core.intelligence.DeviceRelationshipCluster
import com.example.core.model.InvestigationMode
import com.example.core.model.RiskLevel
import com.example.core.model.UserDeviceStatus
import com.example.ui.components.EmptyStatePanel
import com.example.ui.components.LimitationBanner
import com.example.ui.components.RelationshipGraphCanvas
import com.example.ui.components.RiskBadge
import com.example.ui.components.SectionHeader
import com.example.ui.components.TacticalCard
import com.example.ui.components.TelemetryLineChart
import com.example.ui.theme.LocalSentinelPalette
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun IntelligenceHubScreen(
    devices: List<ObservedDeviceEntity>,
    appearances: List<DeviceAppearanceEntity>,
    relationships: List<DeviceRelationshipCluster>,
    intelEntries: List<DeviceIntelEntryEntity>,
    optInLocationEnabled: Boolean,
    onOpenDeviceDetail: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var riskFilter by remember { mutableStateOf("ALL") }
    var intelQuery by remember { mutableStateOf("") }
    val timeFmt = SimpleDateFormat("MMM d, HH:mm:ss", Locale.US)

    val tabs = listOf("Inventory", "Timeline", "Relations", "Intel DB")

    Column(modifier = modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = selectedTab) {
            tabs.forEachIndexed { idx, label ->
                Tab(
                    selected = selectedTab == idx,
                    onClick = { selectedTab = idx },
                    text = { Text(label, maxLines = 1) },
                    modifier = Modifier.testTag("intel_tab_$idx")
                )
            }
        }

        when (selectedTab) {
            // TAB 0: Device Inventory
            0 -> {
                val filtered = remember(devices, riskFilter) {
                    when (riskFilter) {
                        "ELEVATED" -> devices.filter { it.riskLevel == RiskLevel.HIGH.name || it.riskLevel == RiskLevel.CRITICAL.name }
                        "MODERATE" -> devices.filter { it.riskLevel == RiskLevel.MODERATE.name }
                        "LOW" -> devices.filter { it.riskLevel == RiskLevel.LOW.name }
                        else -> devices
                    }
                }
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("ALL" to "All", "ELEVATED" to "High/Crit", "MODERATE" to "Moderate", "LOW" to "Low").forEach { (key, label) ->
                                FilterChip(
                                    selected = riskFilter == key,
                                    onClick = { riskFilter = key },
                                    label = { Text(label) }
                                )
                            }
                        }
                    }
                    if (filtered.isEmpty()) {
                        item {
                            EmptyStatePanel(
                                icon = Icons.Filled.Analytics,
                                title = "No Devices Match Filter",
                                tip = "Run a Full Scan, BLE scan, or Wi-Fi audit to populate observed device intelligence."
                            )
                        }
                    } else {
                        items(filtered, key = { it.fingerprintId }) { dev ->
                            TacticalCard(onClick = { onOpenDeviceDetail(dev.fingerprintId) }) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(dev.displayName, style = MaterialTheme.typography.titleMedium)
                                        Text(
                                            text = "${dev.sourceType} • ${dev.manufacturerName}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = "Obs: ${dev.observationCount}x • MAC Rotations: ${dev.macRotationCount} • Status: ${dev.userStatus}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    RiskBadge(riskLevel = dev.riskLevel)
                                }
                            }
                        }
                    }
                }
            }

            // TAB 1: Timeline & Location Correlation
            1 -> {
                val locTagged = appearances.filter { it.latitude != null && it.longitude != null }
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        LimitationBanner(
                            title = if (optInLocationEnabled) "Opt-In Location Correlation Active" else "Location Correlation Disabled (Privacy Default)",
                            message = if (optInLocationEnabled) {
                                "Foreground GPS/network coordinates are attached only when you scan. Note: A device appearing at multiple locations does NOT automatically prove it is following you."
                            } else {
                                "Location collection is opt-in and currently OFF. Enable Opt-In Location Correlation in Safety & Settings if you want multi-location movement timelines."
                            }
                        )
                    }
                    item {
                        SectionHeader(
                            title = "Chronological Appearance Timeline (${appearances.size})",
                            subtitle = "${locTagged.size} observation(s) include opt-in location coordinates"
                        )
                    }
                    if (appearances.isEmpty()) {
                        item {
                            EmptyStatePanel(
                                icon = Icons.Filled.LocationOn,
                                title = "No Appearance History Recorded",
                                tip = "Scan observations will appear here chronologically with signal strength and optional location tags."
                            )
                        }
                    } else {
                        items(appearances.take(50), key = { it.id }) { app ->
                            TacticalCard(onClick = { onOpenDeviceDetail(app.fingerprintId) }) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(timeFmt.format(Date(app.timestamp)), style = MaterialTheme.typography.labelMedium)
                                        Text("${app.rssi} dBm", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                                    }
                                    Text("Session ${app.sessionId} • Addr ${app.rawAddressSnapshot}", style = MaterialTheme.typography.bodySmall)
                                    app.locationLabel?.let {
                                        Text("Opt-in Location: $it", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // TAB 2: Device Relationships
            2 -> {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        LimitationBanner(
                            title = "Co-Occurrence Analysis Caution",
                            message = "Recurring shared appearances across scan sessions may occur simply because neighbors, coworkers, or household electronics share the same physical environment. Co-occurrence does not prove shared ownership or intent."
                        )
                    }
                    item {
                        TacticalCard {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text("Device Relationship Network", style = MaterialTheme.typography.titleMedium)
                                Spacer(modifier = Modifier.height(8.dp))
                                RelationshipGraphCanvas(clusters = relationships)
                            }
                        }
                    }
                    items(relationships, key = { "${it.primaryFingerprintId}_${it.relatedFingerprintId}" }) { rel ->
                        TacticalCard {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("${rel.primaryLabel}  ↔  ${rel.relatedLabel}", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    text = "Shared sessions: ${rel.sharedSessionCount} (${rel.sharedSessionIds.take(3).joinToString(", ")})",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(rel.temporalCorrelationNote, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }

            // TAB 3: Local Device Intelligence DB
            else -> {
                val filteredIntel = remember(intelEntries, intelQuery) {
                    if (intelQuery.isBlank()) intelEntries else {
                        val q = intelQuery.lowercase()
                        intelEntries.filter {
                            it.manufacturer.lowercase().contains(q) ||
                                it.productName.lowercase().contains(q) ||
                                it.category.lowercase().contains(q) ||
                                it.serviceUuidOrOuiPattern.lowercase().contains(q)
                        }
                    }
                }
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        OutlinedTextField(
                            value = intelQuery,
                            onValueChange = { intelQuery = it },
                            label = { Text("Search offline intel DB (AirTag, Hikvision, RTL-SDR...)") },
                            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth().testTag("intel_db_search_input"),
                            singleLine = true
                        )
                    }
                    items(filteredIntel, key = { it.id }) { entry ->
                        TacticalCard {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(entry.productName, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                                    Text("${entry.verificationStatus} (${entry.confidenceLevel})", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                }
                                Text("${entry.manufacturer} • ${entry.category}", style = MaterialTheme.typography.labelSmall)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Signature: ${entry.serviceUuidOrOuiPattern}", style = MaterialTheme.typography.labelMedium)
                                Text(entry.identifyingCharacteristics, style = MaterialTheme.typography.bodySmall)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Source: ${entry.sourceAttribution}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(entry.notes, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeviceDetailScreen(
    device: ObservedDeviceEntity?,
    appearances: List<DeviceAppearanceEntity>,
    cases: List<InvestigationCaseEntity>,
    onUpdateStatus: (UserDeviceStatus) -> Unit,
    onSaveAsEvidence: (caseId: String, notes: String) -> Unit,
    onCreateCaseAndSaveEvidence: (deviceName: String, notes: String) -> Unit,
    onExportDevicePdf: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val palette = LocalSentinelPalette.current
    val timeFmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Device Intelligence") },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        if (device == null) {
            Column(modifier = Modifier.fillMaxSize().padding(innerPadding).padding(16.dp)) {
                Text("Device record not found.")
            }
            return@Scaffold
        }

        val supporting = remember(device.supportingObservationsJson) { parseJsonStringList(device.supportingObservationsJson) }
        val uncertainties = remember(device.uncertaintiesJson) { parseJsonStringList(device.uncertaintiesJson) }
        val nextSteps = remember(device.recommendedNextStepsJson) { parseJsonStringList(device.recommendedNextStepsJson) }
        val rssiSeries = remember(appearances, device.rssiHistoryJson) {
            if (appearances.isNotEmpty()) appearances.map { it.rssi.toFloat() }
            else parseJsonIntList(device.rssiHistoryJson).map { it.toFloat() }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                TacticalCard(accentColor = MaterialTheme.colorScheme.primary) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(device.displayName, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
                            RiskBadge(riskLevel = device.riskLevel)
                        }
                        Text("${device.manufacturerName} • ${device.sourceType}", style = MaterialTheme.typography.bodyMedium)
                        Text("Fingerprint: ${device.fingerprintId}", style = MaterialTheme.typography.labelSmall, color = palette.cyanAccent)
                        Text("Last Address: ${device.rawAddress} (${device.addressType})", style = MaterialTheme.typography.labelSmall)
                        Text("Confidence: ${device.confidenceScore}% • Status: ${device.userStatus}", style = MaterialTheme.typography.labelMedium)
                        Text("First Seen: ${timeFmt.format(Date(device.firstSeenAt))}", style = MaterialTheme.typography.bodySmall)
                        Text("Last Seen: ${timeFmt.format(Date(device.lastSeenAt))} • Observations: ${device.observationCount}", style = MaterialTheme.typography.bodySmall)
                        Text("Signal RSSI: last ${device.lastRssi} dBm (avg ${device.avgRssi}, min ${device.minRssi}, max ${device.maxRssi}) • MAC rotations: ${device.macRotationCount}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            item {
                TacticalCard {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("Proximity / RSSI History Trend", style = MaterialTheme.typography.titleMedium)
                        Spacer(modifier = Modifier.height(6.dp))
                        TelemetryLineChart(
                            values = rssiSeries,
                            lineColor = palette.cyanAccent,
                            unitLabel = "dBm",
                            emptyMessage = "Only 1 observation recorded so far."
                        )
                    }
                }
            }

            item {
                TacticalCard {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Transparent Risk Reasoning", style = MaterialTheme.typography.titleMedium)
                        Text(device.riskReasoning, style = MaterialTheme.typography.bodyMedium)

                        Text("Supporting Observations:", style = MaterialTheme.typography.labelLarge, color = palette.cyanAccent)
                        supporting.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }

                        Text("Known Uncertainties:", style = MaterialTheme.typography.labelLarge, color = palette.moderate)
                        uncertainties.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }

                        Text("Recommended Next Steps:", style = MaterialTheme.typography.labelLarge, color = palette.low)
                        nextSteps.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                    }
                }
            }

            item {
                TacticalCard {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("False-Positive Control & Actions", style = MaterialTheme.typography.titleMedium)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { onUpdateStatus(UserDeviceStatus.TRUSTED) },
                                modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("device_mark_trusted_button")
                            ) {
                                Icon(Icons.Filled.Check, contentDescription = null)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Trusted")
                            }
                            OutlinedButton(
                                onClick = { onUpdateStatus(UserDeviceStatus.INVESTIGATING) },
                                modifier = Modifier.weight(1f).minimumInteractiveComponentSize()
                            ) {
                                Text("Investigate")
                            }
                            OutlinedButton(
                                onClick = { onUpdateStatus(UserDeviceStatus.DISMISSED) },
                                modifier = Modifier.weight(1f).minimumInteractiveComponentSize()
                            ) {
                                Icon(Icons.Filled.Close, contentDescription = null)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Dismiss")
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    val active = cases.firstOrNull { it.status == "ACTIVE" }
                                    val note = "Logged from Intelligence view. Risk=${device.riskLevel} (${device.confidenceScore}%). ${device.riskReasoning}"
                                    if (active != null) {
                                        onSaveAsEvidence(active.id, note)
                                    } else {
                                        onCreateCaseAndSaveEvidence(device.displayName, note)
                                    }
                                },
                                modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("device_save_evidence_button")
                            ) {
                                Icon(Icons.Filled.FolderSpecial, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Preserve Evidence")
                            }
                            OutlinedButton(
                                onClick = onExportDevicePdf,
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Text("Export PDF")
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun parseJsonStringList(json: String): List<String> = runCatching {
    val arr = JSONArray(json)
    (0 until arr.length()).map { arr.optString(it) }
}.getOrDefault(emptyList())

private fun parseJsonIntList(json: String): List<Int> = runCatching {
    val arr = JSONArray(json)
    (0 until arr.length()).map { arr.optInt(it) }
}.getOrDefault(emptyList())
