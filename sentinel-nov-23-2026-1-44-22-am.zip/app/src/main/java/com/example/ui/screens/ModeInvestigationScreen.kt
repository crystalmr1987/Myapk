package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.FolderSpecial
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.core.data.InvestigationContentCatalog
import com.example.core.database.ObservedDeviceEntity
import com.example.core.model.DetectionSource
import com.example.core.model.InvestigationMode
import com.example.core.preferences.ChecklistJsonCodec
import com.example.ui.components.RiskBadge
import com.example.ui.components.SectionHeader
import com.example.ui.components.TacticalCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModeInvestigationScreen(
    mode: InvestigationMode,
    observedDevices: List<ObservedDeviceEntity>,
    persistedChecklist: Map<String, Boolean>,
    onChecklistChange: (Map<String, Boolean>) -> Unit,
    onRunModeScan: () -> Unit,
    onCreateCaseForMode: (String, InvestigationMode, String, String) -> Unit,
    onOpenModule: (DetectionSource) -> Unit,
    onOpenDeviceDetail: (String) -> Unit,
    onExportPdf: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val checklist = remember(mode) { InvestigationContentCatalog.checklistForMode(mode) }
    var checkedMap by remember(mode, persistedChecklist) { mutableStateOf(persistedChecklist) }
    val relevantDevices = remember(observedDevices, mode) {
        val allowedSources = mode.recommendedModules.map { it.name }.toSet()
        observedDevices.filter { it.sourceType in allowedSources }.take(20)
    }

    fun toggleChecklistItem(itemId: String, checked: Boolean) {
        val updated = checkedMap.toMutableMap().apply { put(itemId, checked) }
        checkedMap = updated
        onChecklistChange(updated)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(mode.title) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                TacticalCard(accentColor = MaterialTheme.colorScheme.primary) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(mode.subtitle, style = MaterialTheme.typography.bodyMedium)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Recommended modules: ${mode.recommendedModules.joinToString(" • ") { it.label }}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = onRunModeScan,
                                modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("mode_scan_button")
                            ) {
                                Icon(Icons.Filled.Radar, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Run Mode Sweep")
                            }
                            OutlinedButton(
                                onClick = {
                                    val done = checklist.count { checkedMap[it.id] == true }
                                    onCreateCaseForMode(
                                        "${mode.title} Sweep",
                                        mode,
                                        "Completed $done/${checklist.size} checklist items.",
                                        ChecklistJsonCodec.encodeFlatMap(checkedMap)
                                    )
                                },
                                modifier = Modifier.minimumInteractiveComponentSize().testTag("mode_create_case_button")
                            ) {
                                Icon(Icons.Filled.FolderSpecial, contentDescription = null)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Save Case")
                            }
                        }
                    }
                }
            }

            item {
                SectionHeader(title = "Launch Mode Detection Modules")
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    mode.recommendedModules.take(3).forEach { src ->
                        OutlinedButton(
                            onClick = { onOpenModule(src) },
                            modifier = Modifier.weight(1f).minimumInteractiveComponentSize()
                        ) {
                            Text(src.label.substringBefore(" "), maxLines = 1)
                        }
                    }
                }
            }

            item {
                val doneCount = checklist.count { checkedMap[it.id] == true }
                SectionHeader(
                    title = "Physical & Technical Checklist",
                    subtitle = "$doneCount of ${checklist.size} verified"
                )
            }

            items(checklist, key = { it.id }) { item ->
                val isChecked = checkedMap[item.id] == true
                TacticalCard(
                    onClick = { toggleChecklistItem(item.id, !isChecked) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Checkbox(
                            checked = isChecked,
                            onCheckedChange = { toggleChecklistItem(item.id, it) }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(item.area, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            Text(item.title, style = MaterialTheme.typography.titleMedium)
                            Text(
                                text = item.guidance,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            item {
                SectionHeader(
                    title = "Mode Device Inventory (${relevantDevices.size})",
                    trailing = {
                        OutlinedButton(onClick = onExportPdf, modifier = Modifier.minimumInteractiveComponentSize()) {
                            Text("Export PDF")
                        }
                    }
                )
            }

            if (relevantDevices.isEmpty()) {
                item {
                    TacticalCard {
                        Text(
                            text = "No observations stored for this mode's modules yet. Tap Run Mode Sweep above.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            } else {
                items(relevantDevices, key = { it.fingerprintId }) { dev ->
                    TacticalCard(
                        onClick = { onOpenDeviceDetail(dev.fingerprintId) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(dev.displayName, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    text = "${dev.sourceType} • ${dev.manufacturerName} • ${dev.lastRssi} dBm",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            RiskBadge(riskLevel = dev.riskLevel)
                        }
                    }
                }
            }
        }
    }
}
