package com.example.sensors

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.usb.UsbManager
import android.location.LocationManager
import android.net.wifi.WifiManager
import android.nfc.NfcAdapter
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.example.core.model.CapabilityStatus
import com.example.core.model.HardwareDiagnosticsReport

data class ScanPermissionDescriptor(
    val permission: String,
    val label: String,
    val reason: String,
    val isGranted: Boolean
)

class DiagnosticsManager(private val context: Context) {

    fun hasPermission(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Checks the runtime permission strictly required to start a BLE scan on the current Android API level:
     * - Android 12+ (API 31+): BLUETOOTH_SCAN
     * - Android 10-11 (API 29-30): ACCESS_FINE_LOCATION
     * - Android 7-9 (API 24-28): ACCESS_FINE_LOCATION or ACCESS_COARSE_LOCATION
     */
    fun hasBleScanPermission(): Boolean {
        return when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
                hasPermission(Manifest.permission.BLUETOOTH_SCAN)
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q ->
                hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)
            else ->
                hasPermission(Manifest.permission.ACCESS_FINE_LOCATION) ||
                    hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
    }

    fun hasBluetoothConnectPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            hasPermission(Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            true
        }
    }

    fun hasFineLocationPermission(): Boolean =
        hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)

    fun hasCoarseLocationOnly(): Boolean =
        !hasFineLocationPermission() && hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION)

    fun hasLocationPermission(): Boolean {
        return hasFineLocationPermission() ||
            hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
    }

    fun isLocationServicesEnabled(): Boolean {
        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return false
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            locationManager.isLocationEnabled
        } else {
            runCatching {
                locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
                    locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
            }.getOrDefault(false)
        }
    }

    /**
     * Verifies both Bluetooth permissions (BLUETOOTH_SCAN on API 31+, ACCESS_FINE_LOCATION on API 29-30)
     * and Bluetooth adapter/scanner readiness before triggering BLE scanning logic.
     * Returns null if ready, or a specific, actionable error message if preconditions are not met.
     */
    fun verifyBleScanPreconditions(allowTurningOnTransition: Boolean = true): String? {
        if (!hasBleScanPermission()) {
            return when {
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
                    "Bluetooth scan permission (BLUETOOTH_SCAN) is not granted."
                hasCoarseLocationOnly() ->
                    "Precise Location permission (ACCESS_FINE_LOCATION) is required for BLE scans on Android 10–11."
                else ->
                    "Location permission (ACCESS_FINE_LOCATION) is required for BLE scans on this Android version."
            }
        }

        val btManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        @Suppress("DEPRECATION")
        val adapter = btManager?.adapter ?: BluetoothAdapter.getDefaultAdapter()
            ?: return "This device does not have a Bluetooth radio."

        val adapterState = runCatching { adapter.state }.getOrNull()
        val isTurningOn = adapterState == BluetoothAdapter.STATE_TURNING_ON || adapterState == 14
        val isAdapterOn = runCatching {
            adapter.isEnabled ||
                adapterState == BluetoothAdapter.STATE_ON ||
                adapterState == 15
        }.getOrDefault(false)
        val btSettingOn = runCatching {
            Settings.Global.getInt(context.contentResolver, Settings.Global.BLUETOOTH_ON, 0) != 0
        }.getOrDefault(false)

        if (!isAdapterOn) {
            if (allowTurningOnTransition && isTurningOn) {
                return null
            }
            return if (btSettingOn) {
                "Bluetooth is ON in system settings, but the Bluetooth adapter HAL is inactive on this device or emulator."
            } else {
                "Bluetooth is turned off. Enable Bluetooth to scan for BLE devices."
            }
        }

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S && !isLocationServicesEnabled()) {
            return "Location Services are turned off. Android <12 requires System Location ON for BLE scans."
        }

        if (!allowTurningOnTransition && runCatching { adapter.bluetoothLeScanner }.getOrNull() == null) {
            return "Bluetooth is ON, but BluetoothLeScanner is unavailable on this device or emulator."
        }
        return null
    }

    /**
     * Verifies ACCESS_FINE_LOCATION, Wi-Fi radio state, and Android 9+ Location Services
     * before triggering Wi-Fi scan logic. Returns null if ready, or a descriptive error message.
     */
    fun verifyWifiScanPreconditions(): String? {
        val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            ?: return "Wi-Fi service unavailable on this device."

        if (hasCoarseLocationOnly()) {
            return "Precise (Fine) Location access (ACCESS_FINE_LOCATION) is required by Android for Wi-Fi scans — only Approximate location is currently granted. Tap Grant Fine Location or enable 'Use precise location' in App Settings."
        }
        if (!hasFineLocationPermission()) {
            return "Fine Location permission (ACCESS_FINE_LOCATION) is required by Android to read Wi-Fi scan results."
        }
        val wifiEnabled = runCatching { wifiManager.isWifiEnabled }.getOrDefault(false)
        if (!wifiEnabled) {
            return "Wi-Fi is disabled. Enable Wi-Fi to inspect access points."
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && !isLocationServicesEnabled()) {
            return "System Location Services are turned off. Enable Location in Android Quick Settings so Android permits Wi-Fi scan results."
        }
        return null
    }

    fun allScanPermissionDescriptors(): List<ScanPermissionDescriptor> {
        val pm = context.packageManager
        val hasUwbFeature = pm.hasSystemFeature("android.hardware.uwb")
        val hasCameraFeature = pm.hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY)

        return buildList {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                add(
                    ScanPermissionDescriptor(
                        permission = Manifest.permission.BLUETOOTH_SCAN,
                        label = "Bluetooth LE Scan",
                        reason = "Scans nearby BLE trackers (AirTag, SmartTag, Tile, Pebblebee) and unknown transmitters.",
                        isGranted = hasPermission(Manifest.permission.BLUETOOTH_SCAN)
                    )
                )
                add(
                    ScanPermissionDescriptor(
                        permission = Manifest.permission.BLUETOOTH_CONNECT,
                        label = "Bluetooth Device Info",
                        reason = "Reads Bluetooth adapter status and discovered device metadata locally.",
                        isGranted = hasPermission(Manifest.permission.BLUETOOTH_CONNECT)
                    )
                )
            }
            add(
                ScanPermissionDescriptor(
                    permission = Manifest.permission.ACCESS_FINE_LOCATION,
                    label = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        "Location (Wi-Fi Scan Access)"
                    } else {
                        "Location (Wi-Fi & BLE Scan Access)"
                    },
                    reason = "Required by Android OS (with Precise enabled) to read nearby Wi-Fi APs${if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) " and BLE beacons" else ""}. Location tagging remains opt-in.",
                    isGranted = hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                )
            )
            if (hasCameraFeature) {
                add(
                    ScanPermissionDescriptor(
                        permission = Manifest.permission.CAMERA,
                        label = "Camera & Torch",
                        reason = "Enables optical lens reflection inspection and unmodified forensic photo evidence.",
                        isGranted = hasPermission(Manifest.permission.CAMERA)
                    )
                )
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && hasUwbFeature) {
                add(
                    ScanPermissionDescriptor(
                        permission = Manifest.permission.UWB_RANGING,
                        label = "Ultra-Wideband (UWB)",
                        reason = "Checks UWB chipset diagnostics and FiRa ranging readiness.",
                        isGranted = hasPermission(Manifest.permission.UWB_RANGING)
                    )
                )
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(
                    ScanPermissionDescriptor(
                        permission = Manifest.permission.POST_NOTIFICATIONS,
                        label = "Scan Notifications",
                        reason = "Displays status notifications during foreground Extended Observation sweeps.",
                        isGranted = hasPermission(Manifest.permission.POST_NOTIFICATIONS)
                    )
                )
            }
        }
    }

    fun getMissingScanPermissions(): Array<String> {
        val descriptors = allScanPermissionDescriptors()
        val missing = linkedSetOf<String>()
        descriptors.filter { !it.isGranted }.forEach { desc ->
            missing.add(desc.permission)
            if (desc.permission == Manifest.permission.ACCESS_FINE_LOCATION &&
                !hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
            ) {
                missing.add(Manifest.permission.ACCESS_COARSE_LOCATION)
            }
        }
        return missing.toTypedArray()
    }

    fun generateReport(): HardwareDiagnosticsReport {
        val pm = context.packageManager
        val btManager = runCatching { context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager }.getOrNull()
        @Suppress("DEPRECATION")
        val btAdapter = runCatching { btManager?.adapter ?: BluetoothAdapter.getDefaultAdapter() }.getOrNull()
        val hasBtFeature = pm.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH)
        val hasBleFeature = pm.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)
        val btSettingOn = runCatching {
            Settings.Global.getInt(context.contentResolver, Settings.Global.BLUETOOTH_ON, 0) != 0
        }.getOrDefault(false)
        val btState = runCatching { btAdapter?.state }.getOrNull()
        val adapterEnabled = runCatching {
            btAdapter?.isEnabled == true ||
                btState == BluetoothAdapter.STATE_ON ||
                btState == 15 // BluetoothAdapter.STATE_BLE_ON
        }.getOrDefault(false)
        val hasBleScanPerm = hasBleScanPermission()
        val hasBtConnectPerm = hasBluetoothConnectPermission()
        val btEnabled = adapterEnabled || (btSettingOn && btAdapter != null && !hasBtConnectPerm)
        val btHalInactiveWithSettingOn = btSettingOn && btAdapter != null && !adapterEnabled && hasBtConnectPerm
        val hasBleScanner = adapterEnabled && runCatching { btAdapter?.bluetoothLeScanner != null }.getOrDefault(false)

        val wifiManager = runCatching {
            context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        }.getOrNull()
        val hasWifiFeature = pm.hasSystemFeature(PackageManager.FEATURE_WIFI)
        val wifiEnabled = runCatching { wifiManager?.isWifiEnabled == true }.getOrDefault(false)

        val locationManager = runCatching {
            context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        }.getOrNull()
        val locationEnabled = isLocationServicesEnabled()

        val hasNfcFeature = pm.hasSystemFeature(PackageManager.FEATURE_NFC)
        val nfcAdapter = runCatching { NfcAdapter.getDefaultAdapter(context) }.getOrNull()
        val nfcEnabled = runCatching { nfcAdapter?.isEnabled == true }.getOrDefault(false)

        val hasUwbFeature = pm.hasSystemFeature("android.hardware.uwb")
        val uwbPermGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            hasPermission(Manifest.permission.UWB_RANGING)
        } else {
            true
        }

        val sensorManager = runCatching { context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager }.getOrNull()
        val magSensor = runCatching { sensorManager?.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD) }.getOrNull()

        val hasCameraFeature = pm.hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY)
        val hasFlashFeature = pm.hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH)
        val cameraPerm = hasPermission(Manifest.permission.CAMERA)

        // Assess monochrome / potential low-IR-filter or depth camera sensor availability
        var monochromeOrIrDetail = "Standard RGB camera sensors include IR-cut filters"
        var hasMonochromeSensor = false
        try {
            val camMgr = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
            camMgr?.cameraIdList?.forEach { camId ->
                val chars = camMgr.getCameraCharacteristics(camId)
                val caps = chars.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
                if (caps != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P &&
                    caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_MONOCHROME)
                ) {
                    hasMonochromeSensor = true
                    monochromeOrIrDetail = "Monochrome sensor detected (ID $camId) — may assist low-light reflection checks"
                }
            }
        } catch (_: Throwable) {
        }

        val hasUsbHost = pm.hasSystemFeature(PackageManager.FEATURE_USB_HOST)
        val usbManager = context.getSystemService(Context.USB_SERVICE) as? UsbManager
        val attachedUsbCount = runCatching { usbManager?.deviceList?.size ?: 0 }.getOrDefault(0)

        val permissions = linkedMapOf(
            "BLUETOOTH_SCAN" to if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) hasPermission(Manifest.permission.BLUETOOTH_SCAN) else true,
            "BLUETOOTH_CONNECT" to if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) hasPermission(Manifest.permission.BLUETOOTH_CONNECT) else true,
            "ACCESS_FINE_LOCATION" to hasPermission(Manifest.permission.ACCESS_FINE_LOCATION),
            "CAMERA" to cameraPerm,
            "UWB_RANGING" to uwbPermGranted,
            "POST_NOTIFICATIONS" to if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) hasPermission(Manifest.permission.POST_NOTIFICATIONS) else true
        )

        return HardwareDiagnosticsReport(
            generatedAt = System.currentTimeMillis(),
            androidVersion = Build.VERSION.RELEASE ?: "Unknown",
            sdkInt = Build.VERSION.SDK_INT,
            manufacturer = Build.MANUFACTURER.replaceFirstChar { it.uppercase() },
            model = Build.MODEL,
            bluetooth = CapabilityStatus(
                name = "Classic Bluetooth Adapter",
                supported = (hasBtFeature || btAdapter != null) && !btHalInactiveWithSettingOn,
                enabled = btEnabled,
                permissionGranted = hasBtConnectPerm && hasBleScanPerm,
                detail = when {
                    btAdapter == null -> "No Bluetooth adapter reported by device/emulator"
                    btHalInactiveWithSettingOn -> "System Bluetooth ON, but adapter HAL is inactive"
                    btEnabled -> "Adapter state: ON"
                    else -> "Adapter state: OFF"
                },
                limitationNote = when {
                    btAdapter == null -> "This device or emulator has no Bluetooth adapter."
                    btHalInactiveWithSettingOn -> "Android Bluetooth setting is ON, but the hardware/emulator Bluetooth controller is inactive."
                    !btEnabled -> "Enable Bluetooth in system settings to scan."
                    else -> null
                }
            ),
            ble = CapabilityStatus(
                name = "Bluetooth Low Energy (BLE)",
                supported = (hasBleFeature || hasBleScanner) && !btHalInactiveWithSettingOn,
                enabled = hasBleScanner,
                permissionGranted = hasBleScanPerm,
                detail = buildString {
                    append(
                        when {
                            hasBleScanner -> "Bluetooth ON • BLE Scanner Ready"
                            btHalInactiveWithSettingOn -> "System Bluetooth ON • BLE HAL inactive"
                            btEnabled -> "Bluetooth ON • BluetoothLeScanner unavailable"
                            btAdapter == null -> "No Bluetooth adapter"
                            hasBleFeature -> "Bluetooth OFF"
                            else -> "BLE hardware absent"
                        }
                    )
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && btAdapter != null) {
                        if (runCatching { btAdapter.isLe2MPhySupported }.getOrDefault(false)) append(" • 2M PHY")
                        if (runCatching { btAdapter.isLeExtendedAdvertisingSupported }.getOrDefault(false)) append(" • ExtAdv")
                    }
                },
                limitationNote = when {
                    btHalInactiveWithSettingOn -> "System Bluetooth setting is ON, but the emulator/device Bluetooth HAL is not active."
                    btEnabled && !hasBleScanner -> "Bluetooth is ON, but Android did not provide a BluetoothLeScanner (common on emulators without virtual BLE HAL)."
                    else -> "BLE scanning cannot detect powered-off tags or non-BLE cellular/GPS trackers."
                }
            ),
            wifi = CapabilityStatus(
                name = "Wi-Fi & Authorized LAN",
                supported = hasWifiFeature && wifiManager != null,
                enabled = wifiEnabled,
                permissionGranted = hasFineLocationPermission(),
                detail = buildString {
                    append(if (wifiEnabled) "Wi-Fi enabled" else "Wi-Fi disabled")
                    if (hasCoarseLocationOnly()) append(" • Approximate location only (Precise needed)")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && wifiManager != null) {
                        if (runCatching { wifiManager.is5GHzBandSupported }.getOrDefault(false)) append(" • 5 GHz")
                        if (runCatching { wifiManager.is6GHzBandSupported }.getOrDefault(false)) append(" • 6 GHz")
                    }
                },
                limitationNote = "Android throttles active Wi-Fi scans (4 scans per 2 min in foreground) and strictly requires Precise (Fine) Location + System Location ON."
            ),
            locationServices = CapabilityStatus(
                name = "Location Services (Opt-In)",
                supported = locationManager != null,
                enabled = locationEnabled,
                permissionGranted = hasLocationPermission(),
                detail = if (locationEnabled) "System Location ON" else "System Location OFF",
                limitationNote = "Used only when user explicitly opts in or when Android requires it for Wi-Fi scan results."
            ),
            nfc = CapabilityStatus(
                name = "NFC Reader (13.56 MHz)",
                supported = hasNfcFeature && nfcAdapter != null,
                enabled = nfcEnabled,
                permissionGranted = true,
                detail = if (nfcAdapter != null) "NFC ${if (nfcEnabled) "Enabled" else "Disabled"}" else "No NFC radio",
                limitationNote = "Reads 13.56 MHz tags at ~1–4 cm only. Cannot detect 125 kHz LF or 900 MHz UHF RFID."
            ),
            uwb = CapabilityStatus(
                name = "Ultra-Wideband (UWB)",
                supported = hasUwbFeature,
                enabled = hasUwbFeature && uwbPermGranted,
                permissionGranted = uwbPermGranted,
                detail = if (hasUwbFeature) "UWB chipset present (FiRa compatible)" else "UWB chipset not present on this device",
                limitationNote = "Android UWB requires FiRa OOB pairing; it cannot passively sniff AirTag or SmartTag UWB pulses."
            ),
            magnetometer = CapabilityStatus(
                name = "3-Axis Magnetometer",
                supported = magSensor != null,
                enabled = magSensor != null,
                permissionGranted = true,
                detail = if (magSensor != null) {
                    "${magSensor.name} (${magSensor.vendor}, res ${"%.2f".format(magSensor.resolution)} µT)"
                } else {
                    "No magnetometer sensor reported"
                },
                limitationNote = "Detects static magnetic fields (speakers, chassis steel, magnets), not trackers specifically."
            ),
            cameraOptical = CapabilityStatus(
                name = "Optical Camera & Torch",
                supported = hasCameraFeature,
                enabled = hasCameraFeature && cameraPerm,
                permissionGranted = cameraPerm,
                detail = "Camera: ${if (hasCameraFeature) "Present" else "Absent"} • Torch: ${if (hasFlashFeature) "Present" else "Absent"}",
                limitationNote = "Optical reflection highlights glass lenses visually; human verification is required."
            ),
            infraredCamera = CapabilityStatus(
                name = "Infrared / Monochrome Sensor",
                supported = hasMonochromeSensor,
                enabled = hasMonochromeSensor && cameraPerm,
                permissionGranted = cameraPerm,
                detail = monochromeOrIrDetail,
                limitationNote = "Most consumer phones filter out 850nm/940nm IR light on rear cameras; front cameras or external IR tools may differ."
            ),
            usbHostExternalRf = CapabilityStatus(
                name = "USB OTG / External RF Host",
                supported = hasUsbHost,
                enabled = hasUsbHost,
                permissionGranted = true,
                detail = if (hasUsbHost) "USB Host supported • $attachedUsbCount USB device(s) attached" else "USB Host OTG not reported",
                limitationNote = "Broadband RF, SDR spectrum analysis, and LF/UHF RFID require compatible external USB-C/OTG or BLE hardware."
            ),
            permissionMatrix = permissions
        )
    }
}
