package com.example.sensors

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import androidx.core.content.ContextCompat

data class LocationSnapshot(
    val latitude: Double,
    val longitude: Double,
    val accuracyMeters: Float,
    val provider: String,
    val label: String
)

/**
 * Strictly opt-in foreground-only location snapshot helper.
 * Never requests or collects background location, and returns null unless
 * both user opt-in setting and runtime permission are granted.
 */
class LocationProviderHelper(private val context: Context) {

    @SuppressLint("MissingPermission")
    fun getLastKnownLocationIfAuthorized(optInEnabled: Boolean): LocationSnapshot? {
        if (!optInEnabled) return null

        val hasFine = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val hasCoarse = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasFine && !hasCoarse) return null

        val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
        val providers = buildList {
            if (hasFine) add(LocationManager.GPS_PROVIDER)
            add(LocationManager.NETWORK_PROVIDER)
            add(LocationManager.PASSIVE_PROVIDER)
        }

        var best: Location? = null
        for (provider in providers) {
            val loc = runCatching { lm.getLastKnownLocation(provider) }.getOrNull() ?: continue
            if (best == null || loc.time > best.time) {
                best = loc
            }
        }

        return best?.let {
            val formatted = "${"%.4f".format(it.latitude)}, ${"%.4f".format(it.longitude)}"
            LocationSnapshot(
                latitude = it.latitude,
                longitude = it.longitude,
                accuracyMeters = it.accuracy,
                provider = it.provider ?: "unknown",
                label = formatted
            )
        }
    }
}
