package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.WifiFind
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.sensors.LanHostObservation
import com.example.sensors.WifiApObservation
import com.example.ui.components.EmptyStatePanel
import com.example.ui.components.LimitationBanner
import com.example.ui.components.PermissionPromptCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.TacticalCard
import com.example.ui.theme.LocalSentinelPalette

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WifiInvestigationScreen(
    hasLocationPermission: Boolean,
    hasCoarseOnly: Boolean,
    wifiEnabled: Boolean,
    locationServicesEnabled: Boolean,
    firstScanPermissionsRequested: Boolean,
    wifiScanning: Boolean,
    lanScanning: Boolean,
    connectedSummary: String?,
    wifiBanner: String?,
    lanBanner: String?,
    accessPoints: List<WifiApObservation>,
    lanHosts: List<LanHostObservation>,
    onRefreshPermissions: () -> Unit,
    onRunWifiScan: () -> Unit,
    onRunAuthorizedLanScan: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val palette = LocalSentinelPalette.current
    var permHint by remember { mutableStateOf<String?>(null) }
    val permLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        onRefreshPermissions()
        if (results[Manifest.permission.ACCESS_FINE_LOCATION] == true) {
            permHint = null
            if (wifiEnabled && locationServicesEnabled) {
                onRunWifiScan()
            }
        } else {
            permHint = "Precise (Fine) Location was not granted. If Android did not show a prompt, tap 'App Settings' > Permissions > Location > Allow while using + Use precise location."
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Wi-Fi & Authorized LAN Audit") },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (!hasLocationPermission) {
                item {
                    val promptTitle = if (hasCoarseOnly) {
                        "Precise (Fine) Location Needed — Currently Approximate"
                    } else {
                        "Fine Location Needed for Android Wi-Fi Scans"
                    }
                    val promptRationale = permHint ?: if (hasCoarseOnly) {
                        "Location access is currently set to Approximate. Android requires Precise (ACCESS_FINE_LOCATION) to read nearby Wi-Fi BSSIDs and SSIDs. Tap Upgrade to Precise or enable 'Use precise location' in App Settings."
                    } else {
                        "Android OS requires ACCESS_FINE_LOCATION (Precise) to return nearby Wi-Fi BSSIDs and SSIDs. SENTINEL only reads Wi-Fi scan results on-device when you trigger a scan."
                    }
                    PermissionPromptCard(
                        title = promptTitle,
                        rationale = promptRationale,
                        buttonText = if (hasCoarseOnly) "Upgrade to Precise" else "Grant Fine Location",
                        testTag = "wifi_grant_location_button",
                        onGrantClick = {
                            val perms = if (hasCoarseOnly) {
                                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
                            } else {
                                arrayOf(
                                    Manifest.permission.ACCESS_FINE_LOCATION,
                                    Manifest.permission.ACCESS_COARSE_LOCATION
                                )
                            }
                            permLauncher.launch(perms)
                        },
                        secondaryButtonText = "App Settings",
                        onSecondaryClick = {
                            val intent = Intent(
                                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.fromParts("package", context.packageName, null)
                            )
                            runCatching { context.startActivity(intent) }
                        }
                    )
                }
            }

            if (!wifiEnabled || !locationServicesEnabled) {
                item {
                    TacticalCard(accentColor = palette.moderate) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = when {
                                    !wifiEnabled -> "Wi-Fi Radio is Turned Off"
                                    else -> "System Location Services Turned Off"
                                },
                                style = MaterialTheme.typography.titleMedium,
                                color = palette.moderate
                            )
                            Text(
                                text = when {
                                    !wifiEnabled -> "Enable Wi-Fi to scan nearby access points and inspect authorized LAN devices."
                                    else -> "Android 9+ hides all Wi-Fi scan results when System Location is OFF in Quick Settings, even with permission granted."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (!wifiEnabled) {
                                    OutlinedButton(
                                        onClick = { runCatching { context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) } },
                                        modifier = Modifier.minimumInteractiveComponentSize()
                                    ) {
                                        Text("Wi-Fi Settings")
                                    }
                                }
                                if (!locationServicesEnabled) {
                                    OutlinedButton(
                                        onClick = { runCatching { context.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) } },
                                        modifier = Modifier.minimumInteractiveComponentSize()
                                    ) {
                                        Text("Location Settings")
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item {
                TacticalCard(accentColor = MaterialTheme.colorScheme.primary) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = connectedSummary?.let { "Connected: $it" } ?: "Not connected to Wi-Fi",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Authorized inspection only: scans nearby public beacons and discovers mDNS/camera services on networks you are authorized to investigate. Never attempts password cracking or unauthorized access.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    onRefreshPermissions()
                                    if (!hasLocationPermission && firstScanPermissionsRequested) {
                                        val perms = if (hasCoarseOnly) {
                                            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
                                        } else {
                                            arrayOf(
                                                Manifest.permission.ACCESS_FINE_LOCATION,
                                                Manifest.permission.ACCESS_COARSE_LOCATION
                                            )
                                        }
                                        permLauncher.launch(perms)
                                    } else {
                                        onRunWifiScan()
                                    }
                                },
                                enabled = !wifiScanning,
                                modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("wifi_scan_button")
                            ) {
                                if (wifiScanning) {
                                    CircularProgressIndicator(modifier = Modifier.width(18.dp).height(18.dp), strokeWidth = 2.dp)
                                } else {
                                    Text("Scan Wi-Fi APs")
                                }
                            }
                            OutlinedButton(
                                onClick = onRunAuthorizedLanScan,
                                enabled = !lanScanning,
                                modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("lan_scan_button")
                            ) {
                                Text(if (lanScanning) "Scanning LAN..." else "Authorized LAN")
                            }
                        }
                    }
                }
            }

            if (wifiBanner != null) {
                item {
                    LimitationBanner(title = "Wi-Fi Scanner Note", message = wifiBanner)
                }
            }
            if (lanBanner != null) {
                item {
                    LimitationBanner(title = "LAN Discovery Note", message = lanBanner, tint = palette.cyanAccent)
                }
            }

            // Authorized LAN Hosts Section
            item {
                SectionHeader(
                    title = "Authorized Local Network Devices (${lanHosts.size})",
                    subtitle = "Distinguishes confirmed RTSP/ONVIF camera services from heuristic suspicion"
                )
            }

            if (lanHosts.isEmpty()) {
                item {
                    TacticalCard {
                        Text(
                            text = "Tap Authorized LAN while connected to a home, office, or hotel Wi-Fi network to check for mDNS camera services and reachable LAN hosts.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(14.dp)
                        )
                    }
                }
            } else {
                items(lanHosts, key = { it.ipAddress }) { host ->
                    TacticalCard(
                        accentColor = if (host.hasCameraIndicator) palette.high else null,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (host.hostname.isNotBlank()) "${host.hostname} (${host.ipAddress})" else host.ipAddress,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = host.confirmationStatus,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (host.hasCameraIndicator) palette.high else palette.low
                                )
                            }
                            Text(
                                text = "${host.manufacturerName}${host.macAddress?.let { " • $it" } ?: ""}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (host.openServices.isNotEmpty()) {
                                Text(
                                    text = "Services: ${host.openServices.joinToString(", ")}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = palette.cyanAccent
                                )
                            }
                        }
                    }
                }
            }

            // Nearby Wi-Fi Access Points
            item {
                SectionHeader(
                    title = "Nearby Access Points (${accessPoints.size})",
                    subtitle = "Checks duplicate SSIDs, mismatched security, and camera-vendor OUIs"
                )
            }

            if (accessPoints.isEmpty()) {
                item {
                    EmptyStatePanel(
                        icon = Icons.Filled.WifiFind,
                        title = "No Wi-Fi Access Points Scanned Yet",
                        tip = "Grant Fine Location permission and tap Scan Wi-Fi APs."
                    )
                }
            } else {
                items(accessPoints, key = { "${it.bssid}_${it.frequencyMhz}" }) { ap ->
                    TacticalCard(
                        accentColor = if (ap.isDuplicateSsidAnomaly) palette.moderate else null,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(ap.ssid.ifBlank { "<Hidden SSID>" }, style = MaterialTheme.typography.titleMedium)
                                Text("${ap.rssi} dBm", style = MaterialTheme.typography.labelLarge, color = palette.cyanAccent)
                            }
                            Text(
                                text = "BSSID: ${ap.bssid} • ${ap.manufacturerName}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Ch ${ap.channel} (${ap.frequencyMhz} MHz) • ${ap.securityLabel}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            ap.suspicionNote?.let {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(it, style = MaterialTheme.typography.bodySmall, color = palette.moderate)
                            }
                        }
                    }
                }
            }
        }
    }
}
