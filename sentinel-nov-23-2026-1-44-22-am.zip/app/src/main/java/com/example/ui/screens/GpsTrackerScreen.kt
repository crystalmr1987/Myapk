package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.core.data.InvestigationContentCatalog
import com.example.core.database.DeviceIntelEntryEntity
import com.example.core.model.InvestigationMode
import com.example.ui.components.LimitationBanner
import com.example.ui.components.SectionHeader
import com.example.ui.components.TacticalCard
import com.example.ui.theme.LocalSentinelPalette

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GpsTrackerScreen(
    intelEntries: List<DeviceIntelEntryEntity>,
    persistedChecklist: Map<String, Boolean>,
    onChecklistChange: (Map<String, Boolean>) -> Unit,
    onOpenMagnetometer: () -> Unit,
    onOpenBleScanner: () -> Unit,
    onOpenExternalRf: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val palette = LocalSentinelPalette.current
    val vehicleChecklist = remember { InvestigationContentCatalog.checklistForMode(InvestigationMode.VEHICLE) }
    var checked by remember(persistedChecklist) { mutableStateOf(persistedChecklist) }
    val gpsProducts = remember(intelEntries) {
        intelEntries.filter {
            it.category in listOf("GPS_TRACKER", "CELLULAR_TRACKER", "OBD2_TRACKER")
        }
    }

    fun toggleItem(itemId: String, done: Boolean) {
        val updated = checked.toMutableMap().apply { put(itemId, done) }
        checked = updated
        onChecklistChange(updated)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("GPS & Cellular Tracker Investigation") },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                LimitationBanner(
                    title = "Important Technical Reality",
                    message = "Passive GPS receivers ONLY listen to satellite signals and emit zero RF energy—no smartphone can detect a GPS receiver remotely. Real-time GPS trackers transmit via Cellular (LTE/2G) uplinks, which Android phones cannot intercept directly without external RF spectrum hardware.",
                    tint = palette.high
                )
            }

            item {
                TacticalCard {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Signal Technologies Compared", style = MaterialTheme.typography.titleMedium)
                        Text("• GPS Reception: One-way receive-only from satellites (1575.42 MHz). Zero radio emission.", style = MaterialTheme.typography.bodySmall)
                        Text("• Cellular Transmission: Periodic LTE-M / 4G / 2G uplinks (700–2100 MHz). Requires external RF detector / tinySA / HackRF to observe bursts.", style = MaterialTheme.typography.bodySmall)
                        Text("• Bluetooth LE (2.4 GHz): Directly scannable by SENTINEL if the tracker broadcasts BLE config/beacon frames.", style = MaterialTheme.typography.bodySmall)
                        Text("• Wi-Fi (2.4 / 5 GHz): Directly scannable by SENTINEL if OBD/dashcam exposes a hotspot.", style = MaterialTheme.typography.bodySmall)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = onOpenMagnetometer, modifier = Modifier.weight(1f).minimumInteractiveComponentSize()) {
                                Text("Magnetometer")
                            }
                            OutlinedButton(onClick = onOpenBleScanner, modifier = Modifier.weight(1f).minimumInteractiveComponentSize()) {
                                Text("BLE Sweep")
                            }
                            OutlinedButton(onClick = onOpenExternalRf, modifier = Modifier.weight(1f).minimumInteractiveComponentSize()) {
                                Text("Ext. RF")
                            }
                        }
                    }
                }
            }

            item {
                SectionHeader(
                    title = "Vehicle, OBD-II & Hardwired Inspection Guide",
                    subtitle = "${vehicleChecklist.count { checked[it.id] == true }} / ${vehicleChecklist.size} checked"
                )
            }

            items(vehicleChecklist, key = { it.id }) { item ->
                val isDone = checked[item.id] == true
                TacticalCard(onClick = { toggleItem(item.id, !isDone) }) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Checkbox(checked = isDone, onCheckedChange = { toggleItem(item.id, it) })
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(item.area, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            Text(item.title, style = MaterialTheme.typography.titleMedium)
                            Text(item.guidance, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            item {
                SectionHeader(
                    title = "Known GPS, Cellular & OBD-II Reference (${gpsProducts.size})",
                    subtitle = "Offline reference database"
                )
            }

            items(gpsProducts, key = { it.id }) { entry ->
                TacticalCard {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(entry.productName, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                            Text(entry.verificationStatus, style = MaterialTheme.typography.labelSmall, color = palette.cyanAccent)
                        }
                        Text("${entry.manufacturer} • ${entry.category}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(entry.identifyingCharacteristics, style = MaterialTheme.typography.bodySmall)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(entry.notes, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}
