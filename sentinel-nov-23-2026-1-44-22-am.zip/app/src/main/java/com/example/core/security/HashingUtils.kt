package com.example.core.security

import java.io.InputStream
import java.security.MessageDigest

object HashingUtils {

    fun sha256Hex(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hashBytes = digest.digest(input.toByteArray(Charsets.UTF_8))
        return hashBytes.joinToString("") { "%02x".format(it) }
    }

    fun sha256Hex(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hashBytes = digest.digest(bytes)
        return hashBytes.joinToString("") { "%02x".format(it) }
    }

    fun sha256Hex(stream: InputStream): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(8192)
        var bytesRead: Int
        while (stream.read(buffer).also { bytesRead = it } != -1) {
            digest.update(buffer, 0, bytesRead)
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    /**
     * Produces a short, privacy-preserving identifier token from structural characteristics
     * without storing raw sensitive payloads directly as primary keys.
     */
    fun fingerprintId(prefix: String, structuralBasis: String): String {
        val digest = sha256Hex(structuralBasis).take(16)
        return "${prefix}_$digest"
    }
}
