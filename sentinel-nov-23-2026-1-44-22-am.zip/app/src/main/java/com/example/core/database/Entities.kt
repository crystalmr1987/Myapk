package com.example.core.database

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "scan_sessions")
data class ScanSessionEntity(
    @PrimaryKey val id: String,
    val modeId: String,
    val caseId: String?,
    val startedAt: Long,
    val endedAt: Long,
    val durationMs: Long,
    val status: String, // COMPLETED, PARTIAL, CANCELLED, FAILED
    val modulesExecutedJson: String,
    val warningsJson: String,
    val totalObservedCount: Int,
    val suspiciousCount: Int,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val locationLabel: String? = null
)

@Entity(
    tableName = "observed_devices",
    indices = [Index(value = ["lastSeenAt"])]
)
data class ObservedDeviceEntity(
    @PrimaryKey val fingerprintId: String,
    val displayName: String,
    val rawAddress: String,
    val addressType: String, // PUBLIC, RANDOM_RPA, UNKNOWN
    val sourceType: String, // DetectionSource.name
    val manufacturerName: String,
    val companyIdOrOui: String,
    val serviceUuidsJson: String,
    val deviceCategory: String, // DeviceCategory.name
    val firstSeenAt: Long,
    val lastSeenAt: Long,
    val observationCount: Int,
    val lastRssi: Int,
    val minRssi: Int,
    val maxRssi: Int,
    val avgRssi: Int,
    val rssiHistoryJson: String, // JSON array of recent RSSI ints
    val macRotationCount: Int,
    val distinctLocationsCount: Int,
    val riskLevel: String, // RiskLevel.name
    val confidenceScore: Int, // 0..100
    val riskReasoning: String,
    val supportingObservationsJson: String,
    val uncertaintiesJson: String,
    val recommendedNextStepsJson: String,
    val userStatus: String // UserDeviceStatus.name
)

@Entity(
    tableName = "device_appearances",
    indices = [
        Index(value = ["fingerprintId"]),
        Index(value = ["sessionId"]),
        Index(value = ["timestamp"]),
        Index(value = ["fingerprintId", "sessionId"])
    ]
)
data class DeviceAppearanceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fingerprintId: String,
    val sessionId: String,
    val timestamp: Long,
    val rssi: Int,
    val rawAddressSnapshot: String,
    val manufacturerDataHex: String,
    val frequencyMhz: Int? = null,
    val extraMetadata: String = "",
    val latitude: Double? = null,
    val longitude: Double? = null,
    val locationLabel: String? = null
)

@Entity(tableName = "device_intel_entries")
data class DeviceIntelEntryEntity(
    @PrimaryKey val id: String,
    val manufacturer: String,
    val productName: String,
    val category: String,
    val identifyingCharacteristics: String,
    val serviceUuidOrOuiPattern: String,
    val sourceAttribution: String,
    val verificationStatus: String, // VERIFIED, REFERENCE_ONLY, COMMUNITY_REPORTED
    val confidenceLevel: String, // HIGH, MEDIUM, LOW
    val notes: String,
    val lastUpdatedAt: Long
)

@Entity(tableName = "investigation_cases")
data class InvestigationCaseEntity(
    @PrimaryKey val id: String,
    val title: String,
    val investigationType: String, // InvestigationMode.name or GENERAL
    val createdAt: Long,
    val updatedAt: Long,
    val locationNote: String,
    val status: String, // ACTIVE, ARCHIVED, CLOSED
    val encryptedNotesCiphertext: String,
    val notesIv: String,
    val checklistStateJson: String // Map<itemId, Boolean>
)

@Entity(
    tableName = "evidence_records",
    indices = [Index(value = ["caseId"])]
)
data class EvidenceRecordEntity(
    @PrimaryKey val id: String,
    val caseId: String,
    val createdAt: Long,
    val detectionMethod: String,
    val deviceFingerprintId: String?,
    val deviceSummary: String,
    val supportingObservations: String,
    val encryptedNotesCiphertext: String,
    val notesIv: String,
    val photoUri: String?, // Preserved original image URI, never overwritten
    val photoSha256: String?,
    val editedAnnotationNote: String?, // Separated derived annotation
    val latitude: Double?,
    val longitude: Double?,
    val riskLevelSnapshot: String,
    val auditTrailJson: String
)

@Entity(
    tableName = "magnetometer_logs",
    indices = [Index(value = ["timestamp"])]
)
data class MagnetometerLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: String?,
    val timestamp: Long,
    val xUt: Float,
    val yUt: Float,
    val zUt: Float,
    val magnitudeUt: Float,
    val baselineUt: Float,
    val deltaUt: Float,
    val isRelativeAnomaly: Boolean
)
