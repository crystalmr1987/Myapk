package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.SentinelAppContainer
import com.example.core.database.DeviceAppearanceEntity
import com.example.core.database.DeviceIntelEntryEntity
import com.example.core.database.EvidenceRecordEntity
import com.example.core.database.InvestigationCaseEntity
import com.example.core.database.ObservedDeviceEntity
import com.example.core.database.ScanSessionEntity
import com.example.core.intelligence.DeviceIntelligenceEngine
import com.example.core.intelligence.DeviceRelationshipCluster
import com.example.core.model.BleScanProfile
import com.example.core.model.DeviceCategory
import com.example.core.model.InvestigationMode
import com.example.core.model.RiskLevel
import com.example.core.model.ThemePreference
import com.example.core.model.UserDeviceStatus
import com.example.core.preferences.ChecklistJsonCodec
import com.example.core.preferences.SentinelSettings
import com.example.services.ExportedArtifact
import com.example.services.FullScanUiState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

data class DashboardSummary(
    val totalObserved: Int = 0,
    val trustedCount: Int = 0,
    val unknownCount: Int = 0,
    val potentialTrackersCount: Int = 0,
    val potentialCamerasCount: Int = 0,
    val suspiciousNetworkCount: Int = 0,
    val highOrCriticalCount: Int = 0,
    val activeCasesCount: Int = 0,
    val totalEvidenceCount: Int = 0,
    val totalScansCount: Int = 0
)

class SentinelViewModel(private val container: SentinelAppContainer) : ViewModel() {

    private val repo = container.repository
    private val prefs = container.preferences

    val settings: StateFlow<SentinelSettings> = prefs.settingsFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, SentinelSettings())

    val settingsLoaded: StateFlow<Boolean> = prefs.settingsFlow
        .map { true }
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    val scanSessions: StateFlow<List<ScanSessionEntity>> = repo.scanSessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val observedDevices: StateFlow<List<ObservedDeviceEntity>> = repo.observedDevices
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAppearances: StateFlow<List<DeviceAppearanceEntity>> = repo.allAppearances
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val intelEntries: StateFlow<List<DeviceIntelEntryEntity>> = repo.intelEntries
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val investigationCases: StateFlow<List<InvestigationCaseEntity>> = repo.investigationCases
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allEvidence: StateFlow<List<EvidenceRecordEntity>> = repo.allEvidence
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val relationships: StateFlow<List<DeviceRelationshipCluster>> = combine(
        observedDevices,
        allAppearances
    ) { devices, appearances ->
        DeviceIntelligenceEngine.analyzeCoOccurrences(devices, appearances)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dashboardSummary: StateFlow<DashboardSummary> = combine(
        observedDevices,
        investigationCases,
        allEvidence,
        scanSessions
    ) { devices, cases, evidence, sessions ->
        DashboardSummary(
            totalObserved = devices.size,
            trustedCount = devices.count { it.userStatus == UserDeviceStatus.TRUSTED.name },
            unknownCount = devices.count { it.deviceCategory == DeviceCategory.UNKNOWN_TRANSMITTER.name && it.userStatus != UserDeviceStatus.TRUSTED.name },
            potentialTrackersCount = devices.count {
                it.deviceCategory == DeviceCategory.COMMERCIAL_TRACKER.name && it.userStatus != UserDeviceStatus.TRUSTED.name
            },
            potentialCamerasCount = devices.count {
                it.deviceCategory == DeviceCategory.SUSPECTED_CAMERA.name && it.userStatus != UserDeviceStatus.TRUSTED.name
            },
            suspiciousNetworkCount = devices.count {
                (it.sourceType == "WIFI_AP" || it.sourceType == "LAN_HOST") &&
                    (it.riskLevel == RiskLevel.MODERATE.name || it.riskLevel == RiskLevel.HIGH.name || it.riskLevel == RiskLevel.CRITICAL.name) &&
                    it.userStatus != UserDeviceStatus.TRUSTED.name
            },
            highOrCriticalCount = devices.count {
                (it.riskLevel == RiskLevel.HIGH.name || it.riskLevel == RiskLevel.CRITICAL.name) &&
                    it.userStatus != UserDeviceStatus.TRUSTED.name &&
                    it.userStatus != UserDeviceStatus.DISMISSED.name
            },
            activeCasesCount = cases.count { it.status == "ACTIVE" },
            totalEvidenceCount = evidence.size,
            totalScansCount = sessions.size
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardSummary())

    private val _fullScanState = MutableStateFlow(FullScanUiState())
    val fullScanState: StateFlow<FullScanUiState> = _fullScanState.asStateFlow()
    private var fullScanJob: Job? = null

    private val _lastExportedArtifact = MutableStateFlow<ExportedArtifact?>(null)
    val lastExportedArtifact: StateFlow<ExportedArtifact?> = _lastExportedArtifact.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    fun showStatusBanner(message: String) {
        _statusBanner.value = message
    }

    fun clearStatusBanner() {
        _statusBanner.value = null
    }

    fun clearExportArtifact() {
        _lastExportedArtifact.value = null
    }

    fun startFullScan(mode: InvestigationMode = InvestigationMode.DEEP, caseId: String? = null) {
        if (fullScanJob?.isActive == true) return
        fullScanJob = viewModelScope.launch {
            container.fullScanCoordinator.runComprehensiveScan(mode, settings.value, caseId)
                .collect { state ->
                    _fullScanState.value = state
                }
        }
    }

    fun cancelFullScan() {
        fullScanJob?.cancel()
        _fullScanState.value = _fullScanState.value.copy(
            isRunning = false,
            currentStepLabel = "Scan cancelled by user"
        )
    }

    fun observeDevice(fingerprintId: String): Flow<ObservedDeviceEntity?> =
        repo.observeDevice(fingerprintId)

    fun observeAppearancesForDevice(fingerprintId: String): Flow<List<DeviceAppearanceEntity>> =
        repo.observeAppearancesForDevice(fingerprintId)

    fun observeCase(caseId: String): Flow<InvestigationCaseEntity?> =
        repo.observeCase(caseId)

    fun observeEvidenceForCase(caseId: String): Flow<List<EvidenceRecordEntity>> =
        repo.observeEvidenceForCase(caseId)

    fun updateDeviceStatus(fingerprintId: String, status: UserDeviceStatus) {
        viewModelScope.launch {
            repo.updateDeviceUserStatus(fingerprintId, status)
        }
    }

    fun createCase(
        title: String,
        mode: InvestigationMode,
        locationNote: String,
        notes: String,
        initialChecklistJson: String = "{}",
        onCreated: (String) -> Unit = {}
    ) {
        viewModelScope.launch {
            val created = repo.createCase(title, mode, locationNote, notes, initialChecklistJson)
            _statusBanner.value = "Created encrypted case ${created.id}"
            onCreated(created.id)
        }
    }

    fun updateCase(caseId: String, notes: String? = null, status: String? = null, checklistJson: String? = null) {
        viewModelScope.launch {
            repo.updateCaseNotesAndStatus(caseId, notes, status, checklistJson)
        }
    }

    fun deleteCase(caseId: String) {
        viewModelScope.launch {
            repo.deleteCaseAndEvidence(caseId)
            _statusBanner.value = "Case $caseId deleted"
        }
    }

    fun decryptNotes(ciphertext: String, iv: String): String? =
        repo.decryptNotes(ciphertext, iv)

    fun addEvidenceToCase(
        caseId: String,
        detectionMethod: String,
        deviceFingerprintId: String?,
        deviceSummary: String,
        supportingObservations: String,
        notes: String,
        photoUri: String?,
        riskLevelSnapshot: String
    ) {
        viewModelScope.launch {
            val loc = container.locationHelper.getLastKnownLocationIfAuthorized(settings.value.optInLocationCorrelation)
            val record = repo.addEvidenceRecord(
                caseId = caseId,
                detectionMethod = detectionMethod,
                deviceFingerprintId = deviceFingerprintId,
                deviceSummary = deviceSummary,
                supportingObservations = supportingObservations,
                plainNotes = notes,
                photoUri = photoUri,
                latitude = loc?.latitude,
                longitude = loc?.longitude,
                riskLevelSnapshot = riskLevelSnapshot
            )
            _statusBanner.value = "Evidence ${record.id} preserved with SHA-256 hash"
        }
    }

    fun annotateEvidence(record: EvidenceRecordEntity, annotation: String) {
        viewModelScope.launch {
            repo.updateEvidenceAnnotation(record, annotation)
            _statusBanner.value = "Annotation saved (original evidence untouched)"
        }
    }

    fun deleteEvidence(evidenceId: String) {
        viewModelScope.launch {
            repo.deleteEvidence(evidenceId)
        }
    }

    fun exportReport(format: String, caseId: String? = null, deviceId: String? = null) {
        viewModelScope.launch {
            val artifact = withContext(Dispatchers.IO) {
                val diag = container.diagnosticsManager.generateReport()
                val sessions = scanSessions.value
                val allDevs = observedDevices.value
                val devs = if (deviceId != null) allDevs.filter { it.fingerprintId == deviceId } else allDevs
                val cases = if (caseId != null) investigationCases.value.filter { it.id == caseId } else investigationCases.value
                val evds = if (caseId != null) allEvidence.value.filter { it.caseId == caseId } else allEvidence.value
                val reportId = "SENTINEL-${UUID.randomUUID().toString().take(8).uppercase()}"
                val title = when {
                    caseId != null -> "Investigation Case $caseId"
                    deviceId != null -> "Device Investigation Report"
                    else -> "Full Security History Report"
                }

                when (format.uppercase()) {
                    "PDF" -> container.reportExporter.exportPdfReport(reportId, title, diag, sessions, devs, cases, evds)
                    "CSV" -> container.reportExporter.exportCsvReport(reportId, devs)
                    else -> container.reportExporter.exportJsonReport(reportId, title, diag, sessions, devs, cases, evds)
                }
            }
            _lastExportedArtifact.value = artifact
            _statusBanner.value = "${format.uppercase()} exported • SHA-256 ${artifact.sha256.take(12)}..."
        }
    }

    // Settings Controls
    fun setThemePreference(theme: ThemePreference) = viewModelScope.launch { prefs.setThemePreference(theme) }
    fun setTextScale(scale: Float) = viewModelScope.launch { prefs.setTextScaleMultiplier(scale) }
    fun setOptInLocation(enabled: Boolean) = viewModelScope.launch { prefs.setOptInLocationCorrelation(enabled) }
    fun setBleScanProfile(profile: BleScanProfile) = viewModelScope.launch { prefs.setBleScanProfile(profile) }
    fun setMagnetometerSensitivity(ut: Float) = viewModelScope.launch { prefs.setMagnetometerSensitivityUt(ut) }
    fun setMagnetometerHaptic(enabled: Boolean) = viewModelScope.launch { prefs.setMagnetometerHapticEnabled(enabled) }
    fun setTrackerAlertsEnabled(enabled: Boolean) = viewModelScope.launch { prefs.setPersistentTrackerAlertsEnabled(enabled) }
    fun completeOnboarding() = viewModelScope.launch { prefs.setOnboardingCompleted(true) }
    fun reopenOnboarding() = viewModelScope.launch { prefs.setOnboardingCompleted(false) }
    fun markFirstScanPermissionsRequested() = viewModelScope.launch { prefs.setFirstScanPermissionsRequested(true) }

    fun updateChecklistState(scope: String, activeCaseId: String?, updatedMap: Map<String, Boolean>) {
        viewModelScope.launch {
            if (activeCaseId != null) {
                val existingCase = investigationCases.value.firstOrNull { it.id == activeCaseId }
                val merged = ChecklistJsonCodec.parseFlatMap(existingCase?.checklistStateJson).toMutableMap()
                merged.putAll(updatedMap)
                repo.updateCaseNotesAndStatus(
                    caseId = activeCaseId,
                    checklistStateJson = ChecklistJsonCodec.encodeFlatMap(merged)
                )
            } else {
                val newScoped = ChecklistJsonCodec.updateScopedMap(
                    settings.value.checklistStatesJson,
                    scope,
                    updatedMap
                )
                prefs.setChecklistStatesJson(newScoped)
            }
        }
    }

    fun wipeAllUserData() {
        viewModelScope.launch {
            repo.wipeAllUserData()
            prefs.setChecklistStatesJson("{}")
            _fullScanState.value = FullScanUiState()
            _statusBanner.value = "All local scans, devices, cases, photos, and reports erased."
        }
    }

    class Factory(private val container: SentinelAppContainer) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SentinelViewModel(container) as T
        }
    }
}
