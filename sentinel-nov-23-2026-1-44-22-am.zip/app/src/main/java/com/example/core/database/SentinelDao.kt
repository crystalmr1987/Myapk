package com.example.core.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

data class DeviceCoordinateTuple(
    val latitude: Double,
    val longitude: Double
)

@Dao
interface SentinelDao {

    // Scan Sessions
    @Query("SELECT * FROM scan_sessions ORDER BY startedAt DESC")
    fun observeScanSessions(): Flow<List<ScanSessionEntity>>

    @Query("SELECT * FROM scan_sessions ORDER BY startedAt DESC LIMIT 1")
    fun observeLatestScanSession(): Flow<ScanSessionEntity?>

    @Query("SELECT * FROM scan_sessions WHERE id = :id")
    suspend fun getScanSession(id: String): ScanSessionEntity?

    @Upsert
    suspend fun insertScanSession(session: ScanSessionEntity)

    // Observed Devices
    @Query("SELECT * FROM observed_devices ORDER BY lastSeenAt DESC")
    fun observeAllDevices(): Flow<List<ObservedDeviceEntity>>

    @Query("SELECT * FROM observed_devices WHERE fingerprintId = :fingerprintId")
    fun observeDevice(fingerprintId: String): Flow<ObservedDeviceEntity?>

    @Query("SELECT * FROM observed_devices WHERE fingerprintId = :fingerprintId")
    suspend fun getDeviceSync(fingerprintId: String): ObservedDeviceEntity?

    @Query("SELECT * FROM observed_devices")
    suspend fun getAllDevicesSync(): List<ObservedDeviceEntity>

    @Upsert
    suspend fun upsertDevice(device: ObservedDeviceEntity)

    @Query("UPDATE observed_devices SET userStatus = :status, riskLevel = :riskLevel, riskReasoning = :reasoning WHERE fingerprintId = :fingerprintId")
    suspend fun updateDeviceClassification(
        fingerprintId: String,
        status: String,
        riskLevel: String,
        reasoning: String
    )

    // Device Appearances (Historical observations, signal trend, location & co-occurrence)
    @Query("SELECT * FROM device_appearances ORDER BY timestamp DESC")
    fun observeAllAppearances(): Flow<List<DeviceAppearanceEntity>>

    @Query("SELECT * FROM device_appearances WHERE fingerprintId = :fingerprintId ORDER BY timestamp ASC")
    fun observeAppearancesForDevice(fingerprintId: String): Flow<List<DeviceAppearanceEntity>>

    @Query("SELECT * FROM device_appearances WHERE fingerprintId = :fingerprintId ORDER BY timestamp ASC")
    suspend fun getAppearancesForDeviceSync(fingerprintId: String): List<DeviceAppearanceEntity>

    @Query("SELECT * FROM device_appearances WHERE sessionId = :sessionId ORDER BY timestamp DESC")
    suspend fun getAppearancesForSessionSync(sessionId: String): List<DeviceAppearanceEntity>

    @Query("SELECT * FROM device_appearances")
    suspend fun getAllAppearancesSync(): List<DeviceAppearanceEntity>

    @Query("SELECT COUNT(DISTINCT sessionId) FROM device_appearances WHERE fingerprintId = :fingerprintId AND sessionId != :currentSessionId")
    suspend fun countPriorDistinctSessions(fingerprintId: String, currentSessionId: String): Int

    @Query("SELECT DISTINCT latitude, longitude FROM device_appearances WHERE fingerprintId = :fingerprintId AND latitude IS NOT NULL AND longitude IS NOT NULL")
    suspend fun getDistinctCoordinatesForDevice(fingerprintId: String): List<DeviceCoordinateTuple>

    @Insert
    suspend fun insertAppearance(appearance: DeviceAppearanceEntity)

    // Local Device Intelligence Database
    @Query("SELECT * FROM device_intel_entries ORDER BY category ASC, manufacturer ASC")
    fun observeIntelEntries(): Flow<List<DeviceIntelEntryEntity>>

    @Query("SELECT COUNT(*) FROM device_intel_entries")
    suspend fun countIntelEntries(): Int

    @Upsert
    suspend fun insertIntelEntries(entries: List<DeviceIntelEntryEntity>)

    // Investigation Cases
    @Query("SELECT * FROM investigation_cases ORDER BY updatedAt DESC")
    fun observeCases(): Flow<List<InvestigationCaseEntity>>

    @Query("SELECT * FROM investigation_cases WHERE id = :caseId")
    fun observeCase(caseId: String): Flow<InvestigationCaseEntity?>

    @Query("SELECT * FROM investigation_cases WHERE id = :caseId")
    suspend fun getCaseSync(caseId: String): InvestigationCaseEntity?

    @Upsert
    suspend fun upsertCase(investigationCase: InvestigationCaseEntity)

    @Update
    suspend fun updateCase(investigationCase: InvestigationCaseEntity)

    @Query("DELETE FROM investigation_cases WHERE id = :caseId")
    suspend fun deleteCase(caseId: String)

    // Evidence Records
    @Query("SELECT * FROM evidence_records ORDER BY createdAt DESC")
    fun observeAllEvidence(): Flow<List<EvidenceRecordEntity>>

    @Query("SELECT * FROM evidence_records WHERE caseId = :caseId ORDER BY createdAt DESC")
    fun observeEvidenceForCase(caseId: String): Flow<List<EvidenceRecordEntity>>

    @Query("SELECT * FROM evidence_records WHERE caseId = :caseId ORDER BY createdAt DESC")
    suspend fun getEvidenceForCaseSync(caseId: String): List<EvidenceRecordEntity>

    @Upsert
    suspend fun upsertEvidence(record: EvidenceRecordEntity)

    @Query("DELETE FROM evidence_records WHERE id = :evidenceId")
    suspend fun deleteEvidence(evidenceId: String)

    @Query("DELETE FROM evidence_records WHERE caseId = :caseId")
    suspend fun deleteEvidenceForCase(caseId: String)

    // Magnetometer Logs
    @Query("SELECT * FROM magnetometer_logs ORDER BY timestamp DESC LIMIT 200")
    fun observeRecentMagnetometerLogs(): Flow<List<MagnetometerLogEntity>>

    @Insert
    suspend fun insertMagnetometerLog(log: MagnetometerLogEntity)

    @Query("DELETE FROM magnetometer_logs WHERE timestamp < :olderThan")
    suspend fun pruneOldMagnetometerLogs(olderThan: Long)

    // Complete User-Controlled Data Deletion (leaves verified reference Intel DB intact or resets cleanly)
    @Query("DELETE FROM scan_sessions")
    suspend fun clearScanSessions()

    @Query("DELETE FROM observed_devices")
    suspend fun clearObservedDevices()

    @Query("DELETE FROM device_appearances")
    suspend fun clearDeviceAppearances()

    @Query("DELETE FROM investigation_cases")
    suspend fun clearCases()

    @Query("DELETE FROM evidence_records")
    suspend fun clearEvidence()

    @Query("DELETE FROM magnetometer_logs")
    suspend fun clearMagnetometerLogs()
}
