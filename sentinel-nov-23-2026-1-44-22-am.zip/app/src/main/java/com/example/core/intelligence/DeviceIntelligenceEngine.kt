package com.example.core.intelligence

import com.example.core.database.DeviceAppearanceEntity
import com.example.core.database.ObservedDeviceEntity
import com.example.core.model.DetectionSource
import com.example.core.model.DeviceCategory
import com.example.core.model.RiskLevel
import com.example.core.model.UserDeviceStatus
import com.example.core.security.HashingUtils
import com.example.core.security.ManufacturerLookup
import org.json.JSONArray
import kotlin.math.abs

data class RawDeviceObservation(
    val source: DetectionSource,
    val displayName: String,
    val rawAddress: String,
    val addressType: String, // PUBLIC, RANDOM_RPA, UNKNOWN
    val manufacturerName: String,
    val companyIdOrOui: String,
    val serviceUuids: List<String>,
    val manufacturerDataHex: String,
    val rssi: Int,
    val timestamp: Long,
    val frequencyMhz: Int? = null,
    val categoryHint: DeviceCategory? = null,
    val extraIndicators: List<String> = emptyList(),
    val isDuplicateSsidConflict: Boolean = false,
    val hasCameraServicePort: Boolean = false,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val locationLabel: String? = null
)

data class DeviceRiskAssessment(
    val riskLevel: RiskLevel,
    val confidenceScore: Int,
    val reasoning: String,
    val supportingObservations: List<String>,
    val uncertainties: List<String>,
    val recommendedNextSteps: List<String>
)

data class DeviceRelationshipCluster(
    val primaryFingerprintId: String,
    val primaryLabel: String,
    val relatedFingerprintId: String,
    val relatedLabel: String,
    val sharedSessionCount: Int,
    val sharedSessionIds: List<String>,
    val temporalCorrelationNote: String
)

/**
 * Centralized, transparent Device Intelligence Engine.
 * Evaluates multi-factor evidence, respects MAC randomization, prevents false-positive
 * escalation (an unknown device alone is NEVER rated CRITICAL), and surfaces explicit
 * uncertainties and actionable next steps.
 */
object DeviceIntelligenceEngine {

    fun computeFingerprintId(obs: RawDeviceObservation): String {
        val normalizedMac = obs.rawAddress.uppercase()
        val isRandomized = obs.addressType == "RANDOM_RPA" || ManufacturerLookup.isRandomizedMac(normalizedMac)
        val hasStructuralIdentity =
            obs.companyIdOrOui.isNotBlank() ||
                obs.serviceUuids.isNotEmpty() ||
                obs.manufacturerDataHex.isNotBlank() ||
                (obs.displayName.isNotBlank() && obs.displayName != "Unnamed BLE Device")

        // When BLE uses a randomized rotating MAC and advertises at least one structural
        // discriminator, correlate by payload characteristics; otherwise key off the MAC so
        // empty/anonymous randomized adverts never merge into one bucket.
        val basis = when {
            obs.source == DetectionSource.BLE && isRandomized && hasStructuralIdentity -> {
                val payloadHeader = obs.manufacturerDataHex.take(8)
                val sortedUuids = obs.serviceUuids.sorted().joinToString(",")
                "BLE_STRUCT|${obs.companyIdOrOui}|$sortedUuids|$payloadHeader|${obs.displayName.takeIf { it != "Unnamed BLE Device" } ?: ""}"
            }
            obs.source == DetectionSource.BLE && isRandomized ->
                "BLE_ADDR|$normalizedMac"
            obs.source == DetectionSource.BLE ->
                "BLE_ADDR|$normalizedMac|${obs.companyIdOrOui}"
            obs.source == DetectionSource.WIFI_AP -> "WIFI_AP|$normalizedMac|${obs.displayName}"
            obs.source == DetectionSource.LAN_HOST -> "LAN_HOST|$normalizedMac|${obs.displayName}"
            obs.source == DetectionSource.NFC_TAG -> "NFC_UID|$normalizedMac"
            obs.source == DetectionSource.UWB -> "UWB_PEER|$normalizedMac"
            obs.source == DetectionSource.EXTERNAL_RF -> "RF_SIG|${obs.frequencyMhz}|${obs.displayName}"
            else -> "OTHER|${obs.source.name}|$normalizedMac|${obs.displayName}"
        }
        return HashingUtils.fingerprintId(obs.source.name.lowercase(), basis)
    }

    fun inferCategory(obs: RawDeviceObservation): DeviceCategory {
        obs.categoryHint?.let { return it }

        val uuidsUpper = obs.serviceUuids.map { it.uppercase() }
        val hasTrackerUuid = uuidsUpper.any { uuid ->
            ManufacturerLookup.knownTrackerServiceUuids.keys.any { uuid.contains(it) }
        }
        if (hasTrackerUuid) return DeviceCategory.COMMERCIAL_TRACKER

        // Apple Find My Offline Finding continuity header: Company 0x004C, byte 0 == 0x12
        if (obs.companyIdOrOui.contains("004C", ignoreCase = true) &&
            obs.manufacturerDataHex.startsWith("12", ignoreCase = true)
        ) {
            return DeviceCategory.COMMERCIAL_TRACKER
        }

        if (obs.hasCameraServicePort) return DeviceCategory.SUSPECTED_CAMERA

        val lowerName = obs.displayName.lowercase()
        if (lowerName.contains("obd") || lowerName.contains("elm327") || lowerName.contains("teltonika")) {
            return DeviceCategory.VEHICLE_OBD
        }
        if (lowerName.contains("cam") || lowerName.contains("ipcam") || lowerName.contains("hik") ||
            lowerName.contains("dahua") || lowerName.contains("reolink") || lowerName.contains("nvr")
        ) {
            return DeviceCategory.SUSPECTED_CAMERA
        }
        if (obs.source == DetectionSource.WIFI_AP) return DeviceCategory.NETWORK_EQUIPMENT

        ManufacturerLookup.lookupOui(obs.rawAddress)?.categoryHint?.let { return it }
        return DeviceCategory.UNKNOWN_TRANSMITTER
    }

    fun assessRisk(
        existing: ObservedDeviceEntity?,
        obs: RawDeviceObservation,
        appearancesHistory: List<DeviceAppearanceEntity>,
        category: DeviceCategory
    ): DeviceRiskAssessment {
        val priorDistinctSessions = appearancesHistory.map { it.sessionId }.distinct().size
        val historyCoords = appearancesHistory.mapNotNull {
            if (it.latitude != null && it.longitude != null) it.latitude to it.longitude else null
        }
        val distinctLocations = countDistinctLocationsFromCoords(historyCoords, obs.latitude, obs.longitude)
        return assessRiskWithCounts(
            existing = existing,
            obs = obs,
            distinctSessions = priorDistinctSessions + 1,
            distinctLocations = distinctLocations,
            category = category
        )
    }

    fun assessRiskWithCounts(
        existing: ObservedDeviceEntity?,
        obs: RawDeviceObservation,
        distinctSessions: Int,
        distinctLocations: Int,
        category: DeviceCategory
    ): DeviceRiskAssessment {
        // Respect explicit user classifications
        if (existing?.userStatus == UserDeviceStatus.TRUSTED.name) {
            return DeviceRiskAssessment(
                riskLevel = RiskLevel.LOW,
                confidenceScore = 95,
                reasoning = "Marked as Trusted by user. Suppressed from elevated alerts unless status is reset.",
                supportingObservations = listOf("User verified device as trusted"),
                uncertainties = listOf("If an unauthorized device shares a rotating structural signature, review periodically."),
                recommendedNextSteps = listOf("No action required unless behavior changes unexpectedly.")
            )
        }
        if (existing?.userStatus == UserDeviceStatus.DISMISSED.name) {
            return DeviceRiskAssessment(
                riskLevel = RiskLevel.LOW,
                confidenceScore = 70,
                reasoning = "Dismissed by user as benign.",
                supportingObservations = listOf("User dismissed previous alert"),
                uncertainties = emptyList(),
                recommendedNextSteps = listOf("Re-open investigation if the device persists across new locations.")
            )
        }

        val supporting = mutableListOf<String>()
        val uncertainties = mutableListOf<String>()
        val nextSteps = mutableListOf<String>()

        val totalObsCount = (existing?.observationCount ?: 0) + 1
        val macRotated = (existing != null && existing.rawAddress != obs.rawAddress && obs.rawAddress.isNotBlank())
        val strongProximity = obs.rssi >= -55
        val hasDultSeparationSignal = obs.extraIndicators.any {
            it.contains("DULT", ignoreCase = true) || it.contains("separation", ignoreCase = true)
        }

        var indicatorCount = 0
        var confidence = 35

        // 1. Known commercial tracker signature
        val isTrackerSignature = category == DeviceCategory.COMMERCIAL_TRACKER
        if (isTrackerSignature) {
            indicatorCount += 1
            confidence += 30
            supporting.add("Advertises known tracker service/manufacturer signature (${obs.manufacturerName})")
            uncertainties.add("Commercial trackers legitimately belong to nearby people, luggage, or passersby; presence alone does not prove unauthorized tracking.")
        }

        // 2. Camera signature or open camera service
        if (category == DeviceCategory.SUSPECTED_CAMERA) {
            indicatorCount += 1
            confidence += 20
            supporting.add("Matches camera OUI vendor or exposes camera-related service/port (${obs.manufacturerName})")
            if (obs.hasCameraServicePort) {
                indicatorCount += 1
                confidence += 15
                supporting.add("Active RTSP/ONVIF/HTTP camera-associated service detected on authorized LAN")
            }
            uncertainties.add("Network cameras may be legitimate property security equipment (check property disclosures/host authorization).")
        }

        // 3. Wi-Fi impersonation / duplicate SSID anomaly
        if (obs.isDuplicateSsidConflict) {
            indicatorCount += 1
            confidence += 15
            supporting.add("Duplicate SSID observed across multiple BSSIDs or mismatched security parameters")
            uncertainties.add("Mesh Wi-Fi systems and enterprise access points legitimately broadcast the same SSID across multiple BSSIDs.")
        }

        // 4. Persistence across multiple scan sessions
        if (distinctSessions >= 3) {
            indicatorCount += 1
            confidence += 15
            supporting.add("Observed persistently across $distinctSessions separate scan sessions")
            uncertainties.add("Fixed neighbor devices, home electronics, or co-workers' devices also appear repeatedly in stationary environments.")
        } else if (totalObsCount >= 2) {
            supporting.add("Observed $totalObsCount times since first detection")
        }

        // 5. Multi-location correlation (only if opt-in location was recorded)
        if (distinctLocations >= 2) {
            indicatorCount += 1
            confidence += 15
            supporting.add("Observed at $distinctLocations distinct opt-in GPS locations (>150m apart)")
            uncertainties.add("Appearing at multiple locations does not by itself prove tracking; a traveling companion's device or transit equipment produces similar patterns.")
        }

        // 6. Close physical proximity
        if (strongProximity) {
            confidence += 5
            supporting.add("Strong signal proximity (${obs.rssi} dBm) suggesting close physical range")
        } else if (obs.rssi >= -65) {
            supporting.add("Moderate signal proximity (${obs.rssi} dBm)")
        }

        // 7. OS-level separation / DULT signal (strongest corroborator)
        if (hasDultSeparationSignal) {
            indicatorCount += 1
            confidence += 10
            supporting.add("Separated-from-owner / DULT tracker state indicated")
        }

        // 8. MAC rotation noted strictly as informational uncertainty (never increments risk score)
        if (macRotated) {
            uncertainties.add("Observed BLE MAC address changed while maintaining a matching payload; modern phones, audio gear, and tags rotate addresses for privacy.")
        }

        // 9. Unknown device baseline uncertainty
        if (obs.manufacturerName.contains("Unknown", ignoreCase = true) ||
            obs.manufacturerName.contains("Randomized", ignoreCase = true)
        ) {
            uncertainties.add("Device uses a randomized address or undisclosed manufacturer ID; physical identity cannot be confirmed from radio frames alone.")
        }

        // Extra observations supplied by scanner
        obs.extraIndicators.forEach { supporting.add(it) }

        // Conservative Risk Level Classification Rules:
        // - Unknown devices alone NEVER receive CRITICAL.
        // - Stationary brief encounters (e.g., stranger's AirTag seen twice in a cafe at weak RSSI) stay MODERATE.
        // - HIGH: Known tracker across >= 3 sessions (or >= 2 sessions with multi-location, close proximity, or DULT separation),
        //         verified LAN camera service, or >= 3 independent indicators.
        // - CRITICAL: Corroborated persistence (distinctSessions >= 4) + multi-location (distinctLocations >= 2)
        //             AND close proximity (or OS DULT separation corroboration).
        val riskLevel = when {
            isTrackerSignature && distinctSessions >= 4 && distinctLocations >= 2 && (strongProximity || hasDultSeparationSignal) -> {
                RiskLevel.CRITICAL
            }
            (isTrackerSignature && (distinctSessions >= 3 || (distinctSessions >= 2 && (distinctLocations >= 2 || strongProximity || hasDultSeparationSignal)))) ||
                (category == DeviceCategory.SUSPECTED_CAMERA && obs.hasCameraServicePort && indicatorCount >= 2) ||
                (indicatorCount >= 3) -> {
                RiskLevel.HIGH
            }
            category == DeviceCategory.UNKNOWN_TRANSMITTER ||
                indicatorCount >= 1 ||
                obs.isDuplicateSsidConflict -> {
                RiskLevel.MODERATE
            }
            else -> RiskLevel.LOW
        }

        // Actionable next steps
        when (riskLevel) {
            RiskLevel.CRITICAL -> {
                nextSteps.add("Check Android Settings > Safety & emergency > Unknown tracker alerts for OS-level verification.")
                nextSteps.add("Perform a careful physical inspection of bags, pockets, and vehicle wheel wells/OBD area without touching or destroying potential evidence prematurely.")
                nextSteps.add("Document this finding into an Investigation Case and export a timestamped report.")
            }
            RiskLevel.HIGH -> {
                nextSteps.add("Run a follow-up scan in a different location or after moving 200+ meters to verify whether the device moves with you.")
                nextSteps.add("Use signal strength (RSSI) proximity sweep or physical checklist to locate the hardware source.")
                nextSteps.add("If this is your own accessory or neighbor's device, mark it as Trusted to reduce false positives.")
            }
            RiskLevel.MODERATE -> {
                nextSteps.add("Observe whether this device reappears in future scans before drawing conclusions.")
                nextSteps.add("Verify whether it matches household electronics, nearby routers, or Bluetooth headphones.")
            }
            RiskLevel.LOW -> {
                nextSteps.add("No immediate anomaly detected; continue periodic sweeps if concerns persist.")
            }
        }

        val reasoning = buildString {
            append("Classified as ${riskLevel.label} (${confidence.coerceIn(10, 99)}% confidence). ")
            if (supporting.isEmpty()) {
                append("Standard device advertisement with no correlated tracking indicators.")
            } else {
                append(supporting.first())
                if (supporting.size > 1) append("; plus ${supporting.size - 1} additional observation(s).")
            }
        }

        return DeviceRiskAssessment(
            riskLevel = riskLevel,
            confidenceScore = confidence.coerceIn(10, 99),
            reasoning = reasoning,
            supportingObservations = supporting.ifEmpty { listOf("Routine ${obs.source.label} detection") },
            uncertainties = uncertainties.ifEmpty { listOf("Radio frequency presence indicates nearby transmission, not intent.") },
            recommendedNextSteps = nextSteps
        )
    }

    fun countDistinctLocationsFromCoords(
        existingCoords: List<Pair<Double, Double>>,
        newLat: Double?,
        newLon: Double?
    ): Int {
        val coords = existingCoords.toMutableList()
        if (newLat != null && newLon != null) coords.add(newLat to newLon)
        if (coords.isEmpty()) return 0

        val clusters = mutableListOf<Pair<Double, Double>>()
        for (c in coords) {
            val matched = clusters.any { existing ->
                // Roughly ~150m threshold
                abs(existing.first - c.first) < 0.0015 && abs(existing.second - c.second) < 0.0015
            }
            if (!matched) clusters.add(c)
        }
        return clusters.size
    }

    fun analyzeCoOccurrences(
        devices: List<ObservedDeviceEntity>,
        appearances: List<DeviceAppearanceEntity>
    ): List<DeviceRelationshipCluster> {
        val deviceMap = devices.associateBy { it.fingerprintId }
        val sessionsByDevice = appearances.groupBy { it.fingerprintId }
            .mapValues { (_, list) -> list.map { it.sessionId }.toSet() }

        val keys = sessionsByDevice.keys.toList()
        val clusters = mutableListOf<DeviceRelationshipCluster>()

        for (i in keys.indices) {
            for (j in i + 1 until keys.size) {
                val idA = keys[i]
                val idB = keys[j]
                val shared = sessionsByDevice[idA].orEmpty().intersect(sessionsByDevice[idB].orEmpty())
                if (shared.size >= 2) {
                    val devA = deviceMap[idA] ?: continue
                    val devB = deviceMap[idB] ?: continue
                    // Only highlight pairs where at least one is Moderate/High/Critical or non-trusted
                    if (devA.userStatus == UserDeviceStatus.TRUSTED.name &&
                        devB.userStatus == UserDeviceStatus.TRUSTED.name
                    ) {
                        continue
                    }
                    clusters.add(
                        DeviceRelationshipCluster(
                            primaryFingerprintId = idA,
                            primaryLabel = devA.displayName,
                            relatedFingerprintId = idB,
                            relatedLabel = devB.displayName,
                            sharedSessionCount = shared.size,
                            sharedSessionIds = shared.toList(),
                            temporalCorrelationNote = "Co-observed in ${shared.size} shared scan sessions. Note: shared appearance does not prove shared ownership or malicious intent."
                        )
                    )
                }
            }
        }
        return clusters.sortedByDescending { it.sharedSessionCount }.take(25)
    }

    fun mergeRssiHistory(existingJson: String?, newRssi: Int): String {
        val arr = try {
            if (existingJson.isNullOrBlank()) JSONArray() else JSONArray(existingJson)
        } catch (_: Throwable) {
            JSONArray()
        }
        val list = mutableListOf<Int>()
        for (i in 0 until arr.length()) {
            list.add(arr.optInt(i))
        }
        list.add(newRssi)
        val trimmed = if (list.size > 30) list.takeLast(30) else list
        return JSONArray(trimmed).toString()
    }
}
