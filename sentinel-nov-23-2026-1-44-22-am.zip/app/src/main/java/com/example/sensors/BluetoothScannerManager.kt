package com.example.sensors

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import com.example.core.intelligence.RawDeviceObservation
import com.example.core.model.BleScanProfile
import com.example.core.model.DetectionSource
import com.example.core.model.DeviceCategory
import com.example.core.security.ManufacturerLookup
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch

data class LiveBleFrame(
    val address: String,
    val name: String,
    val manufacturerName: String,
    val companyIdHex: String,
    val serviceUuids: List<String>,
    val manufacturerDataHex: String,
    val rssi: Int,
    val txPower: Int?,
    val timestamp: Long,
    val isTrackerSignature: Boolean,
    val trackerSignatureNote: String?,
    val addressType: String
) {
    fun toRawObservation(location: LocationSnapshot?): RawDeviceObservation {
        val extra = mutableListOf<String>()
        if (trackerSignatureNote != null) extra.add(trackerSignatureNote)
        if (txPower != null && txPower != Int.MIN_VALUE) extra.add("TX Power: $txPower dBm")
        return RawDeviceObservation(
            source = DetectionSource.BLE,
            displayName = name,
            rawAddress = address,
            addressType = addressType,
            manufacturerName = manufacturerName,
            companyIdOrOui = companyIdHex,
            serviceUuids = serviceUuids,
            manufacturerDataHex = manufacturerDataHex,
            rssi = rssi,
            timestamp = timestamp,
            categoryHint = if (isTrackerSignature) DeviceCategory.COMMERCIAL_TRACKER else null,
            extraIndicators = extra,
            latitude = location?.latitude,
            longitude = location?.longitude,
            locationLabel = location?.label
        )
    }
}

sealed class BleScanEvent {
    data class DeviceSeen(val frame: LiveBleFrame) : BleScanEvent()
    data class Error(val message: String) : BleScanEvent()
    data object Completed : BleScanEvent()
}

class BluetoothScannerManager(
    private val context: Context,
    private val diagnosticsManager: DiagnosticsManager
) {

    @SuppressLint("MissingPermission")
    fun scanBle(profile: BleScanProfile): Flow<BleScanEvent> = callbackFlow {
        val btManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        @Suppress("DEPRECATION")
        val adapter = btManager?.adapter ?: BluetoothAdapter.getDefaultAdapter()

        diagnosticsManager.verifyBleScanPreconditions(allowTurningOnTransition = true)?.let { failureReason ->
            trySend(BleScanEvent.Error(failureReason))
            close()
            return@callbackFlow
        }
        if (adapter == null) {
            trySend(BleScanEvent.Error("This device does not have a Bluetooth radio."))
            close()
            return@callbackFlow
        }

        // Wait briefly if Bluetooth is currently transitioning from OFF to ON
        val initialState = runCatching { adapter.state }.getOrNull()
        if (initialState == BluetoothAdapter.STATE_TURNING_ON || initialState == 14 /* STATE_BLE_TURNING_ON */) {
            repeat(8) {
                delay(150L)
                val st = runCatching { adapter.state }.getOrNull()
                if (runCatching { adapter.isEnabled || st == BluetoothAdapter.STATE_ON || st == 15 }.getOrDefault(false)) {
                    return@repeat
                }
            }
        }

        // Re-verify preconditions after any turning-on transition before acquiring scanner
        diagnosticsManager.verifyBleScanPreconditions(allowTurningOnTransition = false)?.let { failureReason ->
            trySend(BleScanEvent.Error(failureReason))
            close()
            return@callbackFlow
        }

        var scanner = runCatching { adapter.bluetoothLeScanner }.getOrNull()
        if (scanner == null) {
            delay(250L)
            @Suppress("DEPRECATION")
            val refreshedAdapter = btManager?.adapter ?: BluetoothAdapter.getDefaultAdapter()
            scanner = runCatching { refreshedAdapter?.bluetoothLeScanner }.getOrNull()
        }
        if (scanner == null) {
            trySend(BleScanEvent.Error("Bluetooth is ON, but BluetoothLeScanner is unavailable on this device or emulator."))
            close()
            return@callbackFlow
        }

        val scanMode = when (profile) {
            BleScanProfile.QUICK -> ScanSettings.SCAN_MODE_LOW_POWER
            BleScanProfile.BALANCED -> ScanSettings.SCAN_MODE_BALANCED
            BleScanProfile.EXTENDED -> ScanSettings.SCAN_MODE_LOW_LATENCY
        }

        val settings = ScanSettings.Builder()
            .setScanMode(scanMode)
            .build()

        val callback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                parseScanResult(result)?.let { trySend(BleScanEvent.DeviceSeen(it)) }
            }

            override fun onBatchScanResults(results: MutableList<ScanResult>) {
                results.forEach { r -> parseScanResult(r)?.let { trySend(BleScanEvent.DeviceSeen(it)) } }
            }

            override fun onScanFailed(errorCode: Int) {
                trySend(BleScanEvent.Error(describeBleScanError(errorCode)))
                close()
            }
        }

        try {
            scanner.startScan(null, settings, callback)
        } catch (se: SecurityException) {
            trySend(BleScanEvent.Error("SecurityException starting BLE scan: ${se.localizedMessage}"))
            close()
            return@callbackFlow
        } catch (t: Throwable) {
            trySend(BleScanEvent.Error("Unable to start BLE scan: ${t.localizedMessage}"))
            close()
            return@callbackFlow
        }

        val timerJob = launch {
            delay(profile.durationMs)
            runCatching { scanner.stopScan(callback) }
            trySend(BleScanEvent.Completed)
            close()
        }

        awaitClose {
            timerJob.cancel()
            runCatching { scanner.stopScan(callback) }
        }
    }

    private fun describeBleScanError(errorCode: Int): String = when (errorCode) {
        ScanCallback.SCAN_FAILED_ALREADY_STARTED ->
            "BLE scan already active; stopping previous session before retrying."
        ScanCallback.SCAN_FAILED_APPLICATION_REGISTRATION_FAILED ->
            "Android BLE stack failed to register scanner (error 2). Toggle Bluetooth off/on and retry."
        ScanCallback.SCAN_FAILED_INTERNAL_ERROR ->
            "Internal Bluetooth hardware error during scan (error 3)."
        ScanCallback.SCAN_FAILED_FEATURE_UNSUPPORTED ->
            "BLE scanning is unsupported by this adapter/emulator (error 4)."
        5 -> // SCAN_FAILED_OUT_OF_HARDWARE_RESOURCES
            "Bluetooth hardware scan filters exhausted (error 5). Close other BLE apps and retry."
        6 -> // SCAN_FAILED_SCANNING_TOO_FREQUENTLY
            "Android throttled BLE scanning (>5 scans in 30s). Wait 30 seconds and retry."
        else -> "BLE scan failed (Android error code $errorCode)."
    }

    @SuppressLint("MissingPermission")
    private fun parseScanResult(result: ScanResult): LiveBleFrame? {
        val device = result.device ?: return null
        val record = result.scanRecord
        val address = runCatching { device.address }.getOrNull() ?: "00:00:00:00:00:00"
        val rawName = runCatching {
            record?.deviceName ?: if (diagnosticsManager.hasBluetoothConnectPermission()) device.name else null
        }.getOrNull()

        val mfgData = record?.manufacturerSpecificData
        var companyId = -1
        var mfgBytesHex = ""
        if (mfgData != null && mfgData.size() > 0) {
            companyId = mfgData.keyAt(0)
            val bytes = mfgData.valueAt(0)
            mfgBytesHex = bytes?.joinToString("") { "%02X".format(it) } ?: ""
        }
        val companyHex = if (companyId >= 0) "0x%04X".format(companyId) else ""
        val companyMatch = if (companyId >= 0) ManufacturerLookup.lookupBleCompany(companyId) else null

        val uuidList = record?.serviceUuids?.map { parcelUuid ->
            val str = parcelUuid.uuid.toString().uppercase()
            // Extract 16-bit short UUID if Bluetooth Base UUID (0000XXXX-0000-1000-8000-00805F9B34FB)
            if (str.startsWith("0000") && str.endsWith("-0000-1000-8000-00805F9B34FB")) {
                str.substring(4, 8)
            } else {
                str
            }
        } ?: emptyList()

        // Also check serviceData keys
        val serviceDataUuids = record?.serviceData?.keys?.map { parcelUuid ->
            val str = parcelUuid.uuid.toString().uppercase()
            if (str.startsWith("0000") && str.endsWith("-0000-1000-8000-00805F9B34FB")) {
                str.substring(4, 8)
            } else {
                str
            }
        } ?: emptyList()

        val allUuids = (uuidList + serviceDataUuids).distinct()

        // Evaluate known tracker signatures
        var trackerNote: String? = null
        var isTrackerSig = false
        for (u in allUuids) {
            val match = ManufacturerLookup.knownTrackerServiceUuids[u]
            if (match != null && u != "FFF0") {
                isTrackerSig = true
                trackerNote = "${match.first}: ${match.second}"
                break
            }
        }
        if (!isTrackerSig && companyId == 0x004C && mfgBytesHex.startsWith("12")) {
            isTrackerSig = true
            trackerNote = "Apple Offline Finding / Find My Continuity frame (0x004C / 0x12)"
        }
        if (!isTrackerSig && companyId == 0x0642) {
            isTrackerSig = true
            trackerNote = "Tile, Inc. BLE Company ID 0x0642"
        }

        val ouiMatch = ManufacturerLookup.lookupOui(address)
        val manufacturerName = when {
            companyMatch != null -> companyMatch.manufacturer
            ouiMatch != null -> ouiMatch.manufacturer
            else -> "Unknown Manufacturer"
        }

        val addrType = if (ManufacturerLookup.isRandomizedMac(address)) "RANDOM_RPA" else "PUBLIC"
        val displayName = rawName?.takeIf { it.isNotBlank() }
            ?: if (isTrackerSig) "${manufacturerName.substringBefore(",")} Beacon" else "Unnamed BLE Device"

        val txPower = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            result.txPower.takeIf { it != ScanResult.TX_POWER_NOT_PRESENT }
        } else {
            record?.txPowerLevel?.takeIf { it != Int.MIN_VALUE }
        }

        return LiveBleFrame(
            address = address,
            name = displayName,
            manufacturerName = manufacturerName,
            companyIdHex = companyHex,
            serviceUuids = allUuids,
            manufacturerDataHex = mfgBytesHex,
            rssi = result.rssi,
            txPower = txPower,
            timestamp = System.currentTimeMillis(),
            isTrackerSignature = isTrackerSig,
            trackerSignatureNote = trackerNote,
            addressType = addrType
        )
    }

    /**
     * Opens Android's Unknown Tracker Alerts settings when available on Play Services devices,
     * falling back safely to public Privacy, Bluetooth, or main System Settings.
     */
    fun createAndroidTrackerSafetyIntent(): Intent {
        val candidates = listOf(
            Intent("com.google.android.gms.findmydevice.UNWANTED_TRACKER_SETTINGS"),
            Intent(Settings.ACTION_PRIVACY_SETTINGS),
            Intent(Settings.ACTION_BLUETOOTH_SETTINGS),
            Intent(Settings.ACTION_SETTINGS)
        )
        val pm = context.packageManager
        return candidates.firstOrNull { it.resolveActivity(pm) != null } ?: Intent(Settings.ACTION_SETTINGS)
    }
}
