package com.example

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.runBlocking
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class SentinelComposeUiTest {

    @get:Rule
    val composeTestRule = createAndroidComposeRule<MainActivity>()

    private fun ensureOnDashboard() {
        composeTestRule.waitUntil(timeoutMillis = 5000) {
            composeTestRule.onAllNodesWithTag("onboarding_continue_button").fetchSemanticsNodes().isNotEmpty() ||
                composeTestRule.onAllNodesWithTag("dashboard_start_full_scan_button").fetchSemanticsNodes().isNotEmpty()
        }
        if (composeTestRule.onAllNodesWithTag("onboarding_continue_button").fetchSemanticsNodes().isNotEmpty()) {
            composeTestRule.onNodeWithTag("onboarding_continue_button").assertIsDisplayed().performClick()
            composeTestRule.waitUntil(timeoutMillis = 5000) {
                composeTestRule.onAllNodesWithTag("dashboard_start_full_scan_button")
                    .fetchSemanticsNodes().isNotEmpty()
            }
        }
    }

    @Test
    fun `onboarding transitions to dashboard and bottom tabs navigate cleanly`() {
        ensureOnDashboard()
        composeTestRule.onNodeWithTag("dashboard_start_full_scan_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("dashboard_quick_ble_button").assertIsDisplayed()

        composeTestRule.onNodeWithTag("nav_tab_tools").performClick()
        composeTestRule.waitUntil(timeoutMillis = 5000) {
            composeTestRule.onAllNodesWithTag("hub_full_scan_button")
                .fetchSemanticsNodes().isNotEmpty()
        }
        composeTestRule.onNodeWithTag("hub_full_scan_button").assertIsDisplayed()

        composeTestRule.onNodeWithTag("nav_tab_intel").performClick()
        composeTestRule.waitUntil(timeoutMillis = 5000) {
            composeTestRule.onAllNodesWithTag("intel_tab_3")
                .fetchSemanticsNodes().isNotEmpty()
        }
        composeTestRule.onNodeWithTag("intel_tab_3").performClick()
        composeTestRule.waitUntil(timeoutMillis = 5000) {
            composeTestRule.onAllNodesWithTag("intel_db_search_input")
                .fetchSemanticsNodes().isNotEmpty()
        }
        composeTestRule.onNodeWithTag("intel_db_search_input").assertIsDisplayed()

        composeTestRule.onNodeWithTag("nav_tab_cases").performClick()
        composeTestRule.waitUntil(timeoutMillis = 5000) {
            composeTestRule.onAllNodesWithTag("cases_create_fab")
                .fetchSemanticsNodes().isNotEmpty()
        }
        composeTestRule.onNodeWithTag("cases_create_fab").assertIsDisplayed()
    }

    @Test
    fun `first scan attempt shows all-permissions dialog and proceeds after selection`() {
        val app = ApplicationProvider.getApplicationContext<SentinelApplication>()
        runBlocking {
            app.container.preferences.setFirstScanPermissionsRequested(false)
        }
        ensureOnDashboard()
        composeTestRule.onNodeWithTag("dashboard_start_full_scan_button").performClick()

        composeTestRule.waitUntil(timeoutMillis = 5000) {
            composeTestRule.onAllNodesWithTag("first_scan_grant_all_button")
                .fetchSemanticsNodes().isNotEmpty()
        }
        composeTestRule.onNodeWithTag("first_scan_grant_all_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("first_scan_skip_button").assertIsDisplayed().performClick()

        composeTestRule.waitUntil(timeoutMillis = 5000) {
            composeTestRule.onAllNodesWithTag("full_scan_cancel_button")
                .fetchSemanticsNodes().isNotEmpty() ||
                composeTestRule.onAllNodesWithTag("full_scan_run_button")
                    .fetchSemanticsNodes().isNotEmpty()
        }
    }
}
