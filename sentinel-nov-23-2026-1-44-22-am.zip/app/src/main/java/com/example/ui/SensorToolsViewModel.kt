package com.example.ui

import android.content.Intent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.SentinelAppContainer
import com.example.core.database.ScanSessionEntity
import com.example.core.model.BleScanProfile
import com.example.core.model.HardwareDiagnosticsReport
import com.example.core.model.RiskLevel
import com.example.sensors.AttachedUsbHardware
import com.example.sensors.BleScanEvent
import com.example.sensors.ExternalRfHardwareProfile
import com.example.sensors.LanHostObservation
import com.example.sensors.LiveBleFrame
import com.example.sensors.MagnetometerSample
import com.example.sensors.NfcTagInspection
import com.example.sensors.ScanPermissionDescriptor
import com.example.sensors.UwbDiagnosticState
import com.example.sensors.WifiApObservation
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.util.UUID

data class BleLiveDeviceEntry(
    val fingerprintId: String,
    val latestFrame: LiveBleFrame,
    val rssiHistory: List<Int>,
    val seenCount: Int
)

class SensorToolsViewModel(private val container: SentinelAppContainer) : ViewModel() {

    // Diagnostics & Runtime Permissions (populated off the main thread)
    private val _diagnostics = MutableStateFlow(HardwareDiagnosticsReport.empty())
    val diagnostics: StateFlow<HardwareDiagnosticsReport> = _diagnostics.asStateFlow()

    private val _permissionDescriptors = MutableStateFlow<List<ScanPermissionDescriptor>>(emptyList())
    val permissionDescriptors: StateFlow<List<ScanPermissionDescriptor>> = _permissionDescriptors.asStateFlow()

    private val _hasCoarseLocationOnly = MutableStateFlow(false)
    val hasCoarseLocationOnly: StateFlow<Boolean> = _hasCoarseLocationOnly.asStateFlow()

    init {
        refreshDiagnosticsAsync()
    }

    fun refreshDiagnostics() {
        refreshDiagnosticsAsync()
    }

    fun refreshDiagnosticsAsync() {
        viewModelScope.launch(Dispatchers.IO) {
            val report = container.diagnosticsManager.generateReport()
            val descriptors = container.diagnosticsManager.allScanPermissionDescriptors()
            val coarseOnly = container.diagnosticsManager.hasCoarseLocationOnly()
            _diagnostics.value = report
            _permissionDescriptors.value = descriptors
            _hasCoarseLocationOnly.value = coarseOnly
        }
    }

    /** Lightweight permission-only snapshot for immediate modal display without hardware IPC. */
    fun refreshPermissionStateOnly() {
        _permissionDescriptors.value = container.diagnosticsManager.allScanPermissionDescriptors()
        _hasCoarseLocationOnly.value = container.diagnosticsManager.hasCoarseLocationOnly()
    }

    fun missingScanPermissions(): Array<String> =
        container.diagnosticsManager.getMissingScanPermissions()

    // Live BLE Scanner
    private val _bleScanning = MutableStateFlow(false)
    val bleScanning: StateFlow<Boolean> = _bleScanning.asStateFlow()

    private val _bleError = MutableStateFlow<String?>(null)
    val bleError: StateFlow<String?> = _bleError.asStateFlow()

    private val _bleDevices = MutableStateFlow<List<BleLiveDeviceEntry>>(emptyList())
    val bleDevices: StateFlow<List<BleLiveDeviceEntry>> = _bleDevices.asStateFlow()

    private var bleJob: Job? = null

    fun startBleScan(profile: BleScanProfile, optInLocation: Boolean) {
        if (bleJob?.isActive == true) return
        refreshDiagnosticsAsync()
        container.diagnosticsManager.verifyBleScanPreconditions(allowTurningOnTransition = true)?.let { failureReason ->
            _bleError.value = failureReason
            _bleScanning.value = false
            return
        }
        _bleError.value = null
        _bleScanning.value = true
        val sessionId = "BLE-${UUID.randomUUID().toString().take(8).uppercase()}"
        val startedAt = System.currentTimeMillis()
        val loc = container.locationHelper.getLastKnownLocationIfAuthorized(optInLocation)
        val map = linkedMapOf<String, BleLiveDeviceEntry>()
        val suspiciousIds = mutableSetOf<String>()

        bleJob = viewModelScope.launch {
            var scanError: String? = null
            var wasCancelled = false
            try {
                container.bluetoothScanner.scanBle(profile).collect { event ->
                    when (event) {
                        is BleScanEvent.DeviceSeen -> {
                            val saved = container.repository.recordObservation(
                                sessionId,
                                event.frame.toRawObservation(loc)
                            )
                            if (saved.riskLevel == RiskLevel.HIGH.name || saved.riskLevel == RiskLevel.CRITICAL.name) {
                                suspiciousIds.add(saved.fingerprintId)
                            }
                            val existing = map[saved.fingerprintId]
                            val hist = ((existing?.rssiHistory ?: emptyList()) + event.frame.rssi).takeLast(24)
                            map[saved.fingerprintId] = BleLiveDeviceEntry(
                                fingerprintId = saved.fingerprintId,
                                latestFrame = event.frame,
                                rssiHistory = hist,
                                seenCount = (existing?.seenCount ?: 0) + 1
                            )
                            _bleDevices.value = map.values.sortedByDescending { it.latestFrame.rssi }
                        }
                        is BleScanEvent.Error -> {
                            scanError = event.message
                            _bleError.value = event.message
                            _bleScanning.value = false
                        }
                        BleScanEvent.Completed -> {
                            _bleScanning.value = false
                        }
                    }
                }
            } catch (ce: CancellationException) {
                wasCancelled = true
                throw ce
            } finally {
                _bleScanning.value = false
                withContext(NonCancellable + Dispatchers.IO) {
                    val endedAt = System.currentTimeMillis()
                    val status = when {
                        wasCancelled -> "CANCELLED"
                        scanError != null -> "FAILED"
                        else -> "COMPLETED"
                    }
                    runCatching {
                        container.repository.saveScanSession(
                            ScanSessionEntity(
                                id = sessionId,
                                modeId = "QUICK_BLE",
                                caseId = null,
                                startedAt = startedAt,
                                endedAt = endedAt,
                                durationMs = (endedAt - startedAt).coerceAtLeast(1L),
                                status = status,
                                modulesExecutedJson = JSONArray(listOf("BLE")).toString(),
                                warningsJson = JSONArray(listOfNotNull(scanError)).toString(),
                                totalObservedCount = map.size,
                                suspiciousCount = suspiciousIds.size,
                                latitude = loc?.latitude,
                                longitude = loc?.longitude,
                                locationLabel = loc?.label
                            )
                        )
                    }
                }
            }
        }
    }

    fun stopBleScan() {
        bleJob?.cancel()
        _bleScanning.value = false
    }

    fun getAndroidTrackerSafetyIntent(): Intent =
        container.bluetoothScanner.createAndroidTrackerSafetyIntent()

    // Wi-Fi & Authorized LAN
    private val _wifiScanning = MutableStateFlow(false)
    val wifiScanning: StateFlow<Boolean> = _wifiScanning.asStateFlow()

    private val _wifiAps = MutableStateFlow<List<WifiApObservation>>(emptyList())
    val wifiAps: StateFlow<List<WifiApObservation>> = _wifiAps.asStateFlow()

    private val _wifiBanner = MutableStateFlow<String?>(null)
    val wifiBanner: StateFlow<String?> = _wifiBanner.asStateFlow()

    private val _connectedWifiLabel = MutableStateFlow<String?>(null)
    val connectedWifiLabel: StateFlow<String?> = _connectedWifiLabel.asStateFlow()

    private val _lanScanning = MutableStateFlow(false)
    val lanScanning: StateFlow<Boolean> = _lanScanning.asStateFlow()

    private val _lanHosts = MutableStateFlow<List<LanHostObservation>>(emptyList())
    val lanHosts: StateFlow<List<LanHostObservation>> = _lanHosts.asStateFlow()

    private val _lanBanner = MutableStateFlow<String?>(null)
    val lanBanner: StateFlow<String?> = _lanBanner.asStateFlow()

    fun runWifiScan(optInLocation: Boolean) {
        if (_wifiScanning.value) return
        refreshDiagnosticsAsync()
        container.diagnosticsManager.verifyWifiScanPreconditions()?.let { failureReason ->
            _wifiBanner.value = failureReason
            _wifiScanning.value = false
            return
        }
        viewModelScope.launch {
            _wifiScanning.value = true
            val sessionId = "WIFI-${UUID.randomUUID().toString().take(8).uppercase()}"
            val startedAt = System.currentTimeMillis()
            val loc = container.locationHelper.getLastKnownLocationIfAuthorized(optInLocation)
            val report = container.wifiInspector.scanNearbyAccessPoints()
            _wifiAps.value = report.accessPoints
            _wifiBanner.value = report.warning
            _connectedWifiLabel.value = listOfNotNull(report.connectedSsid, report.connectedSubnet)
                .joinToString(" • ").ifBlank { null }
            val suspiciousIds = mutableSetOf<String>()
            val seenIds = mutableSetOf<String>()
            report.accessPoints.forEach { ap ->
                val saved = container.repository.recordObservation(sessionId, ap.toRawObservation(loc))
                seenIds.add(saved.fingerprintId)
                if (saved.riskLevel == RiskLevel.HIGH.name || saved.riskLevel == RiskLevel.CRITICAL.name) {
                    suspiciousIds.add(saved.fingerprintId)
                }
            }
            val endedAt = System.currentTimeMillis()
            container.repository.saveScanSession(
                ScanSessionEntity(
                    id = sessionId,
                    modeId = "WIFI_AUDIT",
                    caseId = null,
                    startedAt = startedAt,
                    endedAt = endedAt,
                    durationMs = (endedAt - startedAt).coerceAtLeast(1L),
                    status = "COMPLETED",
                    modulesExecutedJson = JSONArray(listOf("WIFI_AP")).toString(),
                    warningsJson = JSONArray(listOfNotNull(report.warning)).toString(),
                    totalObservedCount = seenIds.size,
                    suspiciousCount = suspiciousIds.size,
                    latitude = loc?.latitude,
                    longitude = loc?.longitude,
                    locationLabel = loc?.label
                )
            )
            _wifiScanning.value = false
            refreshDiagnosticsAsync()
        }
    }

    fun runAuthorizedLanScan(optInLocation: Boolean) {
        if (_lanScanning.value) return
        viewModelScope.launch {
            _lanScanning.value = true
            val sessionId = "LAN-${UUID.randomUUID().toString().take(8).uppercase()}"
            val startedAt = System.currentTimeMillis()
            val loc = container.locationHelper.getLastKnownLocationIfAuthorized(optInLocation)
            val (hosts, note) = container.wifiInspector.discoverAuthorizedLanDevices()
            _lanHosts.value = hosts
            _lanBanner.value = note
            val suspiciousIds = mutableSetOf<String>()
            val seenIds = mutableSetOf<String>()
            hosts.forEach { h ->
                val saved = container.repository.recordObservation(sessionId, h.toRawObservation(loc))
                seenIds.add(saved.fingerprintId)
                if (saved.riskLevel == RiskLevel.HIGH.name || saved.riskLevel == RiskLevel.CRITICAL.name) {
                    suspiciousIds.add(saved.fingerprintId)
                }
            }
            val endedAt = System.currentTimeMillis()
            container.repository.saveScanSession(
                ScanSessionEntity(
                    id = sessionId,
                    modeId = "LAN_AUDIT",
                    caseId = null,
                    startedAt = startedAt,
                    endedAt = endedAt,
                    durationMs = (endedAt - startedAt).coerceAtLeast(1L),
                    status = "COMPLETED",
                    modulesExecutedJson = JSONArray(listOf("LAN_HOST")).toString(),
                    warningsJson = JSONArray(listOfNotNull(note)).toString(),
                    totalObservedCount = seenIds.size,
                    suspiciousCount = suspiciousIds.size,
                    latitude = loc?.latitude,
                    longitude = loc?.longitude,
                    locationLabel = loc?.label
                )
            )
            _lanScanning.value = false
        }
    }

    // Live Magnetometer
    private val _magRunning = MutableStateFlow(false)
    val magRunning: StateFlow<Boolean> = _magRunning.asStateFlow()

    private val _magCurrent = MutableStateFlow<MagnetometerSample?>(null)
    val magCurrent: StateFlow<MagnetometerSample?> = _magCurrent.asStateFlow()

    private val _magBaselineUt = MutableStateFlow<Float?>(null)
    val magBaselineUt: StateFlow<Float?> = _magBaselineUt.asStateFlow()

    private val _magHistory = MutableStateFlow<List<Float>>(emptyList())
    val magHistory: StateFlow<List<Float>> = _magHistory.asStateFlow()

    private val _magAnomalyCount = MutableStateFlow(0)
    val magAnomalyCount: StateFlow<Int> = _magAnomalyCount.asStateFlow()

    private var magJob: Job? = null
    private var lastMagLogTs = 0L

    fun isMagnetometerAvailable(): Boolean = container.magnetometerManager.isAvailable()
    fun magnetometerMetadata(): String = container.magnetometerManager.sensorMetadata()

    fun startMagnetometer(sensitivityUt: Float) {
        if (!container.magnetometerManager.isAvailable() || magJob?.isActive == true) return
        _magRunning.value = true
        magJob = viewModelScope.launch {
            container.magnetometerManager.observeMagneticField().collect { sample ->
                _magCurrent.value = sample
                if (_magBaselineUt.value == null) {
                    _magBaselineUt.value = sample.magnitudeUt
                }
                _magHistory.value = (_magHistory.value + sample.magnitudeUt).takeLast(60)
                val base = _magBaselineUt.value ?: sample.magnitudeUt
                val delta = kotlin.math.abs(sample.magnitudeUt - base)
                val isAnomaly = delta >= sensitivityUt
                if (isAnomaly) {
                    _magAnomalyCount.value += 1
                    val now = System.currentTimeMillis()
                    if (now - lastMagLogTs > 1500L) {
                        lastMagLogTs = now
                        container.repository.logMagnetometerSample(
                            sessionId = null,
                            x = sample.xUt,
                            y = sample.yUt,
                            z = sample.zUt,
                            magnitude = sample.magnitudeUt,
                            baseline = base,
                            delta = delta,
                            isAnomaly = true
                        )
                    }
                }
            }
        }
    }

    fun calibrateMagnetometerBaseline() {
        val recent = _magHistory.value.takeLast(8)
        if (recent.isNotEmpty()) {
            _magBaselineUt.value = recent.average().toFloat()
            _magAnomalyCount.value = 0
        } else {
            _magCurrent.value?.let {
                _magBaselineUt.value = it.magnitudeUt
                _magAnomalyCount.value = 0
            }
        }
    }

    fun stopMagnetometer() {
        magJob?.cancel()
        _magRunning.value = false
    }

    // NFC
    val nfcLastTag: StateFlow<NfcTagInspection?> = container.nfcRfidManager.lastTag
    val nfcTagHistory: StateFlow<List<NfcTagInspection>> = container.nfcRfidManager.tagHistory
    fun isNfcSupported() = container.nfcRfidManager.isNfcSupported()
    fun isNfcEnabled() = container.nfcRfidManager.isNfcEnabled()
    fun externalRfidSpecs() = container.nfcRfidManager.supportedExternalRfidSpecs

    // UWB
    private val _uwbState = MutableStateFlow<UwbDiagnosticState?>(null)
    val uwbState: StateFlow<UwbDiagnosticState?> = _uwbState.asStateFlow()

    fun refreshUwbDiagnostics() {
        viewModelScope.launch {
            _uwbState.value = container.uwbHelper.inspectUwbCapabilities()
        }
    }

    // External RF USB OTG
    private val _usbDevices = MutableStateFlow<List<AttachedUsbHardware>>(emptyList())
    val usbDevices: StateFlow<List<AttachedUsbHardware>> = _usbDevices.asStateFlow()

    fun refreshUsbHardware() {
        _usbDevices.value = container.externalRfManager.scanAttachedUsbDevices()
    }

    fun externalRfCompatibilityList(): List<ExternalRfHardwareProfile> =
        container.externalRfManager.compatibilityDatabase

    fun isUsbHostSupported(): Boolean = container.externalRfManager.isUsbHostSupported()

    override fun onCleared() {
        stopBleScan()
        stopMagnetometer()
        super.onCleared()
    }

    class Factory(private val container: SentinelAppContainer) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SensorToolsViewModel(container) as T
        }
    }
}
