package com.example

import android.content.Context
import com.example.core.data.SentinelRepository
import com.example.core.preferences.SentinelPreferences
import com.example.sensors.BluetoothScannerManager
import com.example.sensors.DiagnosticsManager
import com.example.sensors.ExternalRfHardwareManager
import com.example.sensors.LocationProviderHelper
import com.example.sensors.MagnetometerManager
import com.example.sensors.NfcRfidManager
import com.example.sensors.UwbManagerHelper
import com.example.sensors.WifiNetworkInspector
import com.example.services.FullScanCoordinator
import com.example.services.ReportExporter

class SentinelAppContainer(context: Context) {
    private val appContext = context.applicationContext

    val preferences = SentinelPreferences(appContext)
    val repository = SentinelRepository(appContext)
    val diagnosticsManager = DiagnosticsManager(appContext)
    val locationHelper = LocationProviderHelper(appContext)
    val bluetoothScanner = BluetoothScannerManager(appContext, diagnosticsManager)
    val wifiInspector = WifiNetworkInspector(appContext, diagnosticsManager)
    val magnetometerManager = MagnetometerManager(appContext)
    val nfcRfidManager = NfcRfidManager(appContext)
    val uwbHelper = UwbManagerHelper(appContext)
    val externalRfManager = ExternalRfHardwareManager(appContext)
    val reportExporter = ReportExporter(appContext)

    val fullScanCoordinator = FullScanCoordinator(
        repository = repository,
        diagnosticsManager = diagnosticsManager,
        bluetoothScanner = bluetoothScanner,
        wifiInspector = wifiInspector,
        magnetometerManager = magnetometerManager,
        nfcRfidManager = nfcRfidManager,
        uwbHelper = uwbHelper,
        externalRfManager = externalRfManager,
        locationHelper = locationHelper
    )
}
