package com.example.sensors

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlin.math.sqrt

data class MagnetometerSample(
    val xUt: Float,
    val yUt: Float,
    val zUt: Float,
    val magnitudeUt: Float,
    val timestamp: Long
)

class MagnetometerManager(private val context: Context) {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    private val magSensor: Sensor? = sensorManager?.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)

    fun isAvailable(): Boolean = magSensor != null

    fun sensorMetadata(): String {
        val s = magSensor ?: return "No magnetometer hardware available"
        return "${s.name} (${s.vendor}) • Max range ${s.maximumRange} µT • Resolution ${"%.3f".format(s.resolution)} µT"
    }

    fun observeMagneticField(samplingPeriodUs: Int = SensorManager.SENSOR_DELAY_UI): Flow<MagnetometerSample> = callbackFlow {
        val sensor = magSensor
        val mgr = sensorManager
        if (sensor == null || mgr == null) {
            close()
            return@callbackFlow
        }

        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                val x = event.values[0]
                val y = event.values[1]
                val z = event.values[2]
                val mag = sqrt(x * x + y * y + z * z)
                trySend(
                    MagnetometerSample(
                        xUt = x,
                        yUt = y,
                        zUt = z,
                        magnitudeUt = mag,
                        timestamp = System.currentTimeMillis()
                    )
                )
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }

        mgr.registerListener(listener, sensor, samplingPeriodUs)
        awaitClose {
            mgr.unregisterListener(listener)
        }
    }

    /**
     * Collects a brief real sensor baseline snapshot (~1.2s) for Full Scan orchestration.
     * Returns null if no magnetometer exists or emits no events.
     */
    suspend fun captureBriefBaseline(windowMs: Long = 1200L): List<MagnetometerSample> {
        if (!isAvailable()) return emptyList()
        val samples = mutableListOf<MagnetometerSample>()
        kotlinx.coroutines.coroutineScope {
            val collectJob = launch {
                observeMagneticField(SensorManager.SENSOR_DELAY_GAME).collect {
                    synchronized(samples) { samples.add(it) }
                }
            }
            delay(windowMs)
            collectJob.cancelAndJoin()
        }
        return synchronized(samples) { samples.toList() }
    }
}
