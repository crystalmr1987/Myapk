package com.example.core.model

enum class RiskLevel(val label: String, val rank: Int) {
    LOW("LOW", 0),
    MODERATE("MODERATE", 1),
    HIGH("HIGH", 2),
    CRITICAL("CRITICAL", 3)
}

enum class DetectionSource(val label: String) {
    BLE("Bluetooth LE"),
    WIFI_AP("Wi-Fi Access Point"),
    LAN_HOST("Authorized LAN Host"),
    MAGNETOMETER("Magnetometer"),
    NFC_TAG("NFC / RFID"),
    UWB("Ultra-Wideband"),
    OPTICAL_CAMERA("Optical Camera"),
    EXTERNAL_RF("External RF Hardware"),
    MANUAL_EVIDENCE("Manual Investigation")
}

enum class DeviceCategory(val label: String) {
    COMMERCIAL_TRACKER("Commercial Tracker"),
    SUSPECTED_CAMERA("Potential Camera / Video"),
    NETWORK_EQUIPMENT("Network / Access Point"),
    VEHICLE_OBD("Vehicle / OBD-II"),
    PERSONAL_ACCESSORY("Personal Accessory"),
    IOT_SMART_DEVICE("Smart / IoT Device"),
    UNKNOWN_TRANSMITTER("Unknown Transmitter")
}

enum class UserDeviceStatus(val label: String) {
    UNREVIEWED("Unreviewed"),
    TRUSTED("Trusted"),
    INVESTIGATING("Investigating"),
    DISMISSED("Dismissed")
}

enum class InvestigationMode(
    val id: String,
    val title: String,
    val shortTitle: String,
    val subtitle: String,
    val recommendedModules: List<DetectionSource>
) {
    PERSONAL(
        id = "personal",
        title = "Personal Security",
        shortTitle = "Personal",
        subtitle = "Investigate unknown trackers around your person, bags, and clothing",
        recommendedModules = listOf(DetectionSource.BLE, DetectionSource.NFC_TAG, DetectionSource.UWB)
    ),
    VEHICLE(
        id = "vehicle",
        title = "Vehicle Security",
        shortTitle = "Vehicle",
        subtitle = "Investigate OBD-II ports, magnetic mounts, hardwired GPS, and BLE beacons",
        recommendedModules = listOf(
            DetectionSource.BLE,
            DetectionSource.MAGNETOMETER,
            DetectionSource.WIFI_AP,
            DetectionSource.EXTERNAL_RF
        )
    ),
    HOME(
        id = "home",
        title = "Home Security",
        shortTitle = "Home",
        subtitle = "Investigate wireless devices, authorized LAN cameras, and suspicious electronics",
        recommendedModules = listOf(
            DetectionSource.WIFI_AP,
            DetectionSource.LAN_HOST,
            DetectionSource.BLE,
            DetectionSource.OPTICAL_CAMERA,
            DetectionSource.MAGNETOMETER
        )
    ),
    HOTEL(
        id = "hotel",
        title = "Hotel & Travel",
        shortTitle = "Hotel",
        subtitle = "Guided physical & optical inspection for temporary rooms and rentals",
        recommendedModules = listOf(
            DetectionSource.OPTICAL_CAMERA,
            DetectionSource.WIFI_AP,
            DetectionSource.LAN_HOST,
            DetectionSource.BLE,
            DetectionSource.MAGNETOMETER
        )
    ),
    OFFICE(
        id = "office",
        title = "Office Security",
        shortTitle = "Office",
        subtitle = "Investigate unauthorized wireless transmitters and equipment in authorized rooms",
        recommendedModules = listOf(
            DetectionSource.WIFI_AP,
            DetectionSource.LAN_HOST,
            DetectionSource.BLE,
            DetectionSource.OPTICAL_CAMERA,
            DetectionSource.EXTERNAL_RF
        )
    ),
    DEEP(
        id = "deep",
        title = "Deep Investigation",
        shortTitle = "Deep Scan",
        subtitle = "Comprehensive multi-module sweep across all available sensors and hardware",
        recommendedModules = listOf(
            DetectionSource.BLE,
            DetectionSource.WIFI_AP,
            DetectionSource.LAN_HOST,
            DetectionSource.MAGNETOMETER,
            DetectionSource.NFC_TAG,
            DetectionSource.UWB,
            DetectionSource.EXTERNAL_RF
        )
    )
}

enum class BleScanProfile(val label: String, val durationMs: Long, val description: String) {
    QUICK("Quick Sweep", 6_000L, "Low-battery 6s BLE & Wi-Fi snapshot"),
    BALANCED("Standard Scan", 12_000L, "Balanced 12s detection with signal averaging"),
    EXTENDED("Extended Observation", 25_000L, "High-sensitivity 25s sweep for intermittent beacons")
}

enum class ThemePreference(val label: String) {
    DARK("Tactical Dark"),
    LIGHT("Daylight High-Contrast"),
    SYSTEM("Follow System")
}

enum class ModuleExecutionState {
    PENDING, RUNNING, COMPLETED, LIMITED, UNAVAILABLE, PERMISSION_DENIED, FAILED
}

data class ModuleProgressItem(
    val moduleName: String,
    val source: DetectionSource,
    val state: ModuleExecutionState,
    val detail: String,
    val itemsFound: Int = 0
)

data class CapabilityStatus(
    val name: String,
    val supported: Boolean,
    val enabled: Boolean,
    val permissionGranted: Boolean,
    val detail: String,
    val limitationNote: String? = null
)

data class HardwareDiagnosticsReport(
    val generatedAt: Long,
    val androidVersion: String,
    val sdkInt: Int,
    val manufacturer: String,
    val model: String,
    val bluetooth: CapabilityStatus,
    val ble: CapabilityStatus,
    val wifi: CapabilityStatus,
    val locationServices: CapabilityStatus,
    val nfc: CapabilityStatus,
    val uwb: CapabilityStatus,
    val magnetometer: CapabilityStatus,
    val cameraOptical: CapabilityStatus,
    val infraredCamera: CapabilityStatus,
    val usbHostExternalRf: CapabilityStatus,
    val permissionMatrix: Map<String, Boolean>
) {
    companion object {
        fun empty(): HardwareDiagnosticsReport {
            val pending = CapabilityStatus(
                name = "Initializing...",
                supported = false,
                enabled = false,
                permissionGranted = false,
                detail = "Checking hardware..."
            )
            return HardwareDiagnosticsReport(
                generatedAt = 0L,
                androidVersion = android.os.Build.VERSION.RELEASE ?: "Unknown",
                sdkInt = android.os.Build.VERSION.SDK_INT,
                manufacturer = android.os.Build.MANUFACTURER.replaceFirstChar { it.uppercase() },
                model = android.os.Build.MODEL,
                bluetooth = pending.copy(name = "Classic Bluetooth Adapter"),
                ble = pending.copy(name = "Bluetooth Low Energy (BLE)"),
                wifi = pending.copy(name = "Wi-Fi & Authorized LAN"),
                locationServices = pending.copy(name = "Location Services (Opt-In)"),
                nfc = pending.copy(name = "NFC Reader (13.56 MHz)"),
                uwb = pending.copy(name = "Ultra-Wideband (UWB)"),
                magnetometer = pending.copy(name = "3-Axis Magnetometer"),
                cameraOptical = pending.copy(name = "Optical Camera & Torch"),
                infraredCamera = pending.copy(name = "Infrared / Monochrome Sensor"),
                usbHostExternalRf = pending.copy(name = "USB OTG / External RF Host"),
                permissionMatrix = emptyMap()
            )
        }
    }
}

data class ChecklistTemplateItem(
    val id: String,
    val area: String,
    val title: String,
    val guidance: String
)

data class GuideArticle(
    val id: String,
    val category: String,
    val title: String,
    val summary: String,
    val sections: List<Pair<String, String>>,
    val keyLimitation: String
)
