package com.example.services

import com.example.core.data.SentinelRepository
import com.example.core.database.ObservedDeviceEntity
import com.example.core.database.ScanSessionEntity
import com.example.core.model.BleScanProfile
import com.example.core.model.DetectionSource
import com.example.core.model.InvestigationMode
import com.example.core.model.ModuleExecutionState
import com.example.core.model.ModuleProgressItem
import com.example.core.model.RiskLevel
import com.example.core.preferences.SentinelSettings
import com.example.sensors.BleScanEvent
import com.example.sensors.BluetoothScannerManager
import com.example.sensors.DiagnosticsManager
import com.example.sensors.ExternalRfHardwareManager
import com.example.sensors.LocationProviderHelper
import com.example.sensors.MagnetometerManager
import com.example.sensors.NfcRfidManager
import com.example.sensors.UwbManagerHelper
import com.example.sensors.WifiNetworkInspector
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import org.json.JSONArray
import java.util.UUID

data class FullScanUiState(
    val isRunning: Boolean = false,
    val progressFraction: Float = 0f,
    val currentStepLabel: String = "Ready",
    val modules: List<ModuleProgressItem> = emptyList(),
    val warnings: List<String> = emptyList(),
    val detectedDevices: List<ObservedDeviceEntity> = emptyList(),
    val completedSession: ScanSessionEntity? = null
)

class FullScanCoordinator(
    private val repository: SentinelRepository,
    private val diagnosticsManager: DiagnosticsManager,
    private val bluetoothScanner: BluetoothScannerManager,
    private val wifiInspector: WifiNetworkInspector,
    private val magnetometerManager: MagnetometerManager,
    private val nfcRfidManager: NfcRfidManager,
    private val uwbHelper: UwbManagerHelper,
    private val externalRfManager: ExternalRfHardwareManager,
    private val locationHelper: LocationProviderHelper
) {

    fun runComprehensiveScan(
        mode: InvestigationMode,
        settings: SentinelSettings,
        caseId: String? = null
    ): Flow<FullScanUiState> = flow {
        val startedAt = System.currentTimeMillis()
        val sessionId = "SCAN-${UUID.randomUUID().toString().take(8).uppercase()}"
        val warnings = mutableListOf<String>()
        val observedList = mutableListOf<ObservedDeviceEntity>()
        val seenThisScan = linkedSetOf<String>()

        val initialModules = listOf(
            ModuleProgressItem("Hardware & Permissions Check", DetectionSource.MANUAL_EVIDENCE, ModuleExecutionState.RUNNING, "Inspecting radios & permissions"),
            ModuleProgressItem("Magnetometer Baseline", DetectionSource.MAGNETOMETER, ModuleExecutionState.PENDING, "Queued"),
            ModuleProgressItem("Bluetooth LE Sweep", DetectionSource.BLE, ModuleExecutionState.PENDING, "Queued"),
            ModuleProgressItem("Wi-Fi Access Point Audit", DetectionSource.WIFI_AP, ModuleExecutionState.PENDING, "Queued"),
            ModuleProgressItem("Authorized LAN Discovery", DetectionSource.LAN_HOST, ModuleExecutionState.PENDING, "Queued"),
            ModuleProgressItem("NFC / UWB / External RF Check", DetectionSource.EXTERNAL_RF, ModuleExecutionState.PENDING, "Queued")
        ).toMutableList()

        fun snapshot(step: String, progress: Float, running: Boolean = true, session: ScanSessionEntity? = null) =
            FullScanUiState(
                isRunning = running,
                progressFraction = progress,
                currentStepLabel = step,
                modules = initialModules.toList(),
                warnings = warnings.toList(),
                detectedDevices = observedList.distinctBy { it.fingerprintId },
                completedSession = session
            )

        emit(snapshot("1/6 Checking device hardware & permissions...", 0.08f))
        repository.ensureIntelSeeded()
        val diag = diagnosticsManager.generateReport()
        val location = locationHelper.getLastKnownLocationIfAuthorized(settings.optInLocationCorrelation)
        if (settings.optInLocationCorrelation && location == null) {
            warnings.add("Opt-in location correlation is enabled, but no recent GPS/network fix or location permission was available.")
        }

        initialModules[0] = initialModules[0].copy(
            state = ModuleExecutionState.COMPLETED,
            detail = "${diag.manufacturer} ${diag.model} (Android ${diag.androidVersion})"
        )

        // Step 2: Magnetometer Baseline
        initialModules[1] = initialModules[1].copy(state = ModuleExecutionState.RUNNING, detail = "Sampling 3-axis magnetic field...")
        emit(snapshot("2/6 Establishing magnetometer baseline...", 0.20f))
        try {
            if (!magnetometerManager.isAvailable()) {
                initialModules[1] = initialModules[1].copy(state = ModuleExecutionState.UNAVAILABLE, detail = "No magnetometer sensor")
                warnings.add("Magnetometer unavailable on this hardware.")
            } else {
                val magSamples = magnetometerManager.captureBriefBaseline(1_100L)
                if (magSamples.isEmpty()) {
                    initialModules[1] = initialModules[1].copy(state = ModuleExecutionState.LIMITED, detail = "No magnetometer events received")
                    warnings.add("Magnetometer present but emitted no samples during baseline window.")
                } else {
                    val avgMag = magSamples.map { it.magnitudeUt }.average().toFloat()
                    val peakMag = magSamples.maxOf { it.magnitudeUt }
                    val delta = peakMag - avgMag
                    val last = magSamples.last()
                    repository.logMagnetometerSample(
                        sessionId = sessionId,
                        x = last.xUt,
                        y = last.yUt,
                        z = last.zUt,
                        magnitude = last.magnitudeUt,
                        baseline = avgMag,
                        delta = delta,
                        isAnomaly = delta >= settings.magnetometerSensitivityUt
                    )
                    initialModules[1] = initialModules[1].copy(
                        state = ModuleExecutionState.COMPLETED,
                        detail = "Baseline ${"%.1f".format(avgMag)} µT (peak Δ ${"%.1f".format(delta)} µT)",
                        itemsFound = magSamples.size
                    )
                }
            }
        } catch (ce: CancellationException) {
            throw ce
        } catch (t: Throwable) {
            val msg = "Magnetometer check error: ${t.localizedMessage ?: t.javaClass.simpleName}"
            initialModules[1] = initialModules[1].copy(state = ModuleExecutionState.FAILED, detail = msg)
            warnings.add(msg)
        }

        // Step 3: Bluetooth LE Sweep
        initialModules[2] = initialModules[2].copy(state = ModuleExecutionState.RUNNING, detail = "Scanning BLE advertisements (${settings.bleScanProfile.label})...")
        emit(snapshot("3/6 Scanning nearby Bluetooth LE devices...", 0.38f))
        try {
            if (!diag.ble.permissionGranted) {
                initialModules[2] = initialModules[2].copy(state = ModuleExecutionState.PERMISSION_DENIED, detail = "BLE permission required")
                warnings.add("Bluetooth scan permission was not granted.")
            } else if (!diag.ble.supported) {
                val msg = diag.bluetooth.limitationNote ?: "BLE radio absent or HAL inactive on this device/emulator."
                initialModules[2] = initialModules[2].copy(state = ModuleExecutionState.UNAVAILABLE, detail = diag.ble.detail)
                warnings.add(msg)
            } else if (!diag.bluetooth.enabled) {
                initialModules[2] = initialModules[2].copy(state = ModuleExecutionState.LIMITED, detail = "Bluetooth is turned off")
                warnings.add("Bluetooth adapter is disabled; enable Bluetooth for BLE scanning.")
            } else if (!diag.ble.enabled) {
                initialModules[2] = initialModules[2].copy(state = ModuleExecutionState.UNAVAILABLE, detail = "BluetoothLeScanner unavailable (emulator or adapter limit)")
                warnings.add("BluetoothLeScanner is unavailable on this device or emulator.")
            } else {
                var bleCount = 0
                var bleErr: String? = null
                bluetoothScanner.scanBle(settings.bleScanProfile).collect { event ->
                    when (event) {
                        is BleScanEvent.DeviceSeen -> {
                            val saved = repository.recordObservation(sessionId, event.frame.toRawObservation(location))
                            if (seenThisScan.add(saved.fingerprintId)) {
                                bleCount++
                                observedList.add(saved)
                            } else {
                                val idx = observedList.indexOfFirst { it.fingerprintId == saved.fingerprintId }
                                if (idx >= 0) observedList[idx] = saved
                            }
                        }
                        is BleScanEvent.Error -> {
                            bleErr = event.message
                        }
                        BleScanEvent.Completed -> Unit
                    }
                }
                val errMsg = bleErr
                if (errMsg != null) {
                    initialModules[2] = initialModules[2].copy(state = ModuleExecutionState.FAILED, detail = errMsg)
                    warnings.add(errMsg)
                } else {
                    initialModules[2] = initialModules[2].copy(
                        state = ModuleExecutionState.COMPLETED,
                        detail = "$bleCount unique BLE signature(s) observed",
                        itemsFound = bleCount
                    )
                }
            }
        } catch (ce: CancellationException) {
            throw ce
        } catch (t: Throwable) {
            val msg = "BLE sweep error: ${t.localizedMessage ?: t.javaClass.simpleName}"
            initialModules[2] = initialModules[2].copy(state = ModuleExecutionState.FAILED, detail = msg)
            warnings.add(msg)
        }

        // Step 4: Wi-Fi Access Point Audit
        initialModules[3] = initialModules[3].copy(state = ModuleExecutionState.RUNNING, detail = "Auditing nearby Wi-Fi networks...")
        emit(snapshot("4/6 Auditing nearby Wi-Fi access points...", 0.62f))
        try {
            if (!diag.wifi.supported) {
                initialModules[3] = initialModules[3].copy(state = ModuleExecutionState.UNAVAILABLE, detail = "Wi-Fi hardware absent")
            } else if (!diag.wifi.permissionGranted) {
                initialModules[3] = initialModules[3].copy(state = ModuleExecutionState.PERMISSION_DENIED, detail = "Fine Location permission required by Android for Wi-Fi scan")
                warnings.add("Wi-Fi scan skipped: Android requires Fine Location permission to access Wi-Fi scan results.")
            } else if (!diag.wifi.enabled) {
                initialModules[3] = initialModules[3].copy(state = ModuleExecutionState.LIMITED, detail = "Wi-Fi is turned off")
                warnings.add("Wi-Fi is disabled; enable Wi-Fi to inspect nearby access points.")
            } else if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P && !diagnosticsManager.isLocationServicesEnabled()) {
                initialModules[3] = initialModules[3].copy(state = ModuleExecutionState.LIMITED, detail = "System Location OFF (Android requires Location ON for Wi-Fi scans)")
                warnings.add("Wi-Fi scan skipped: System Location Services are turned off in Android settings.")
            } else {
                val wifiReport = wifiInspector.scanNearbyAccessPoints()
                wifiReport.warning?.let { warnings.add(it) }
                var apCount = 0
                wifiReport.accessPoints.forEach { ap ->
                    val saved = repository.recordObservation(sessionId, ap.toRawObservation(location))
                    if (seenThisScan.add(saved.fingerprintId)) {
                        apCount++
                        observedList.add(saved)
                    }
                }
                initialModules[3] = initialModules[3].copy(
                    state = if (wifiReport.accessPoints.isEmpty() && wifiReport.warning != null) ModuleExecutionState.LIMITED else ModuleExecutionState.COMPLETED,
                    detail = "$apCount access point(s) observed",
                    itemsFound = apCount
                )
            }
        } catch (ce: CancellationException) {
            throw ce
        } catch (t: Throwable) {
            val msg = "Wi-Fi audit error: ${t.localizedMessage ?: t.javaClass.simpleName}"
            initialModules[3] = initialModules[3].copy(state = ModuleExecutionState.FAILED, detail = msg)
            warnings.add(msg)
        }

        // Step 5: Authorized LAN Discovery
        initialModules[4] = initialModules[4].copy(state = ModuleExecutionState.RUNNING, detail = "Checking connected subnet & mDNS services...")
        emit(snapshot("5/6 Inspecting authorized local network...", 0.80f))
        try {
            val (lanHosts, lanNote) = wifiInspector.discoverAuthorizedLanDevices()
            lanHosts.forEach { host ->
                val saved = repository.recordObservation(sessionId, host.toRawObservation(location))
                if (seenThisScan.add(saved.fingerprintId)) {
                    observedList.add(saved)
                }
            }
            initialModules[4] = initialModules[4].copy(
                state = if (lanHosts.isNotEmpty()) ModuleExecutionState.COMPLETED else ModuleExecutionState.LIMITED,
                detail = lanNote ?: "${lanHosts.size} LAN host(s) found",
                itemsFound = lanHosts.size
            )
        } catch (ce: CancellationException) {
            throw ce
        } catch (t: Throwable) {
            val msg = "LAN discovery error: ${t.localizedMessage ?: t.javaClass.simpleName}"
            initialModules[4] = initialModules[4].copy(state = ModuleExecutionState.FAILED, detail = msg)
            warnings.add(msg)
        }

        // Step 6: NFC / UWB / External RF Check
        initialModules[5] = initialModules[5].copy(state = ModuleExecutionState.RUNNING, detail = "Checking NFC, UWB & USB OTG RF hardware...")
        emit(snapshot("6/6 Checking NFC, UWB & external RF hardware...", 0.92f))
        try {
            val uwbState = uwbHelper.inspectUwbCapabilities()
            val usbAttached = externalRfManager.scanAttachedUsbDevices()
            val rfMatched = usbAttached.count { it.matchedProfile != null }
            val nfcSummary = if (nfcRfidManager.isNfcEnabled()) "NFC Ready" else if (nfcRfidManager.isNfcSupported()) "NFC Off" else "No NFC"
            val uwbSummary = if (uwbState.uwbServiceAvailable) "UWB Active" else if (uwbState.hardwareFeaturePresent) "UWB Limited" else "No UWB"
            val rfSummary = if (rfMatched > 0) "$rfMatched RF hardware unit(s) attached" else "No optional external RF/SDR attached"
            initialModules[5] = initialModules[5].copy(
                state = if (rfMatched > 0) ModuleExecutionState.COMPLETED else ModuleExecutionState.LIMITED,
                detail = "$nfcSummary • $uwbSummary • $rfSummary",
                itemsFound = usbAttached.size
            )
        } catch (ce: CancellationException) {
            throw ce
        } catch (t: Throwable) {
            val msg = "Peripheral hardware check error: ${t.localizedMessage ?: t.javaClass.simpleName}"
            initialModules[5] = initialModules[5].copy(state = ModuleExecutionState.FAILED, detail = msg)
            warnings.add(msg)
        }

        val endedAt = System.currentTimeMillis()
        val suspiciousCount = observedList.count {
            it.riskLevel == RiskLevel.MODERATE.name ||
                it.riskLevel == RiskLevel.HIGH.name ||
                it.riskLevel == RiskLevel.CRITICAL.name
        }

        val sessionEntity = ScanSessionEntity(
            id = sessionId,
            modeId = mode.id,
            caseId = caseId,
            startedAt = startedAt,
            endedAt = endedAt,
            durationMs = endedAt - startedAt,
            status = if (warnings.isEmpty()) "COMPLETED" else "PARTIAL",
            modulesExecutedJson = JSONArray(initialModules.map { "${it.moduleName}: ${it.state.name}" }).toString(),
            warningsJson = JSONArray(warnings).toString(),
            totalObservedCount = observedList.size,
            suspiciousCount = suspiciousCount,
            latitude = location?.latitude,
            longitude = location?.longitude,
            locationLabel = location?.label
        )
        repository.saveScanSession(sessionEntity)

        emit(
            snapshot(
                step = "Scan complete (${(endedAt - startedAt) / 1000.0}s)",
                progress = 1f,
                running = false,
                session = sessionEntity
            )
        )
    }.flowOn(Dispatchers.Default)
}
