package com.example

import com.example.core.database.DeviceAppearanceEntity
import com.example.core.database.ObservedDeviceEntity
import com.example.core.intelligence.DeviceIntelligenceEngine
import com.example.core.intelligence.RawDeviceObservation
import com.example.core.model.DetectionSource
import com.example.core.model.DeviceCategory
import com.example.core.model.RiskLevel
import com.example.core.model.UserDeviceStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SentinelIntelligenceTest {

    @Test
    fun `unknown device alone never receives critical rating`() {
        val obs = RawDeviceObservation(
            source = DetectionSource.BLE,
            displayName = "Unnamed BLE Device",
            rawAddress = "62:11:22:33:44:55",
            addressType = "RANDOM_RPA",
            manufacturerName = "Unknown Manufacturer",
            companyIdOrOui = "",
            serviceUuids = emptyList(),
            manufacturerDataHex = "",
            rssi = -55,
            timestamp = 1000L
        )
        val cat = DeviceIntelligenceEngine.inferCategory(obs)
        val assessment = DeviceIntelligenceEngine.assessRisk(null, obs, emptyList(), cat)
        assertNotEquals(RiskLevel.CRITICAL, assessment.riskLevel)
        assertEquals(RiskLevel.MODERATE, assessment.riskLevel)
        assertTrue(assessment.uncertainties.isNotEmpty())
        assertTrue(assessment.recommendedNextSteps.isNotEmpty())
    }

    @Test
    fun `randomized MAC rotation preserves structural fingerprint for tracker`() {
        val frame1 = RawDeviceObservation(
            source = DetectionSource.BLE,
            displayName = "AirTag",
            rawAddress = "4A:11:22:33:44:55",
            addressType = "RANDOM_RPA",
            manufacturerName = "Apple, Inc.",
            companyIdOrOui = "0x004C",
            serviceUuids = listOf("FD6F"),
            manufacturerDataHex = "12190011223344",
            rssi = -60,
            timestamp = 1000L,
            categoryHint = DeviceCategory.COMMERCIAL_TRACKER
        )
        val frame2 = frame1.copy(
            rawAddress = "5E:99:88:77:66:55",
            timestamp = 2000L
        )
        val fp1 = DeviceIntelligenceEngine.computeFingerprintId(frame1)
        val fp2 = DeviceIntelligenceEngine.computeFingerprintId(frame2)
        assertEquals(fp1, fp2)
    }

    @Test
    fun `persistent commercial tracker across multiple locations reaches critical`() {
        val obs = RawDeviceObservation(
            source = DetectionSource.BLE,
            displayName = "Tile Beacon",
            rawAddress = "D1:22:33:44:55:66",
            addressType = "RANDOM_RPA",
            manufacturerName = "Tile, Inc.",
            companyIdOrOui = "0x0642",
            serviceUuids = listOf("FEED"),
            manufacturerDataHex = "01020304",
            rssi = -52,
            timestamp = 5000L,
            categoryHint = DeviceCategory.COMMERCIAL_TRACKER,
            latitude = 37.8000,
            longitude = -122.4000
        )
        val history = listOf(
            DeviceAppearanceEntity(1, "fp", "S1", 1000L, -65, "D1:22:33:44:55:66", "", null, "", 37.7000, -122.3000),
            DeviceAppearanceEntity(2, "fp", "S2", 2000L, -60, "D1:22:33:44:55:66", "", null, "", 37.7000, -122.3000),
            DeviceAppearanceEntity(3, "fp", "S3", 3000L, -58, "D1:22:33:44:55:66", "", null, "", 37.8000, -122.4000),
            DeviceAppearanceEntity(4, "fp", "S4", 4000L, -54, "D1:22:33:44:55:66", "", null, "", 37.8000, -122.4000)
        )
        val assessment = DeviceIntelligenceEngine.assessRisk(null, obs, history, DeviceCategory.COMMERCIAL_TRACKER)
        assertEquals(RiskLevel.CRITICAL, assessment.riskLevel)
        assertTrue(assessment.confidenceScore >= 80)
    }

    @Test
    fun `trusted user status suppresses elevated risk`() {
        val existing = ObservedDeviceEntity(
            fingerprintId = "ble_test",
            displayName = "My AirTag",
            rawAddress = "AA:BB:CC:DD:EE:FF",
            addressType = "RANDOM_RPA",
            sourceType = "BLE",
            manufacturerName = "Apple, Inc.",
            companyIdOrOui = "0x004C",
            serviceUuidsJson = "[\"FD6F\"]",
            deviceCategory = DeviceCategory.COMMERCIAL_TRACKER.name,
            firstSeenAt = 1000L,
            lastSeenAt = 2000L,
            observationCount = 5,
            lastRssi = -55,
            minRssi = -60,
            maxRssi = -50,
            avgRssi = -55,
            rssiHistoryJson = "[-60,-55]",
            macRotationCount = 1,
            distinctLocationsCount = 2,
            riskLevel = RiskLevel.LOW.name,
            confidenceScore = 95,
            riskReasoning = "Trusted",
            supportingObservationsJson = "[]",
            uncertaintiesJson = "[]",
            recommendedNextStepsJson = "[]",
            userStatus = UserDeviceStatus.TRUSTED.name
        )
        val obs = RawDeviceObservation(
            source = DetectionSource.BLE,
            displayName = "My AirTag",
            rawAddress = "AA:BB:CC:DD:EE:FF",
            addressType = "RANDOM_RPA",
            manufacturerName = "Apple, Inc.",
            companyIdOrOui = "0x004C",
            serviceUuids = listOf("FD6F"),
            manufacturerDataHex = "1219",
            rssi = -50,
            timestamp = 3000L,
            categoryHint = DeviceCategory.COMMERCIAL_TRACKER
        )
        val assessment = DeviceIntelligenceEngine.assessRisk(existing, obs, emptyList(), DeviceCategory.COMMERCIAL_TRACKER)
        assertEquals(RiskLevel.LOW, assessment.riskLevel)
    }

    @Test
    fun `anonymous empty randomized BLE devices do not collapse into one fingerprint`() {
        val anon1 = RawDeviceObservation(
            source = DetectionSource.BLE,
            displayName = "Unnamed BLE Device",
            rawAddress = "4A:11:22:33:44:55",
            addressType = "RANDOM_RPA",
            manufacturerName = "Unknown Manufacturer",
            companyIdOrOui = "",
            serviceUuids = emptyList(),
            manufacturerDataHex = "",
            rssi = -70,
            timestamp = 1000L
        )
        val anon2 = anon1.copy(rawAddress = "5E:66:77:88:99:AA", timestamp = 2000L)
        val fp1 = DeviceIntelligenceEngine.computeFingerprintId(anon1)
        val fp2 = DeviceIntelligenceEngine.computeFingerprintId(anon2)
        assertNotEquals(fp1, fp2)
    }

    @Test
    fun `brief stationary commercial tracker seen twice at weak signal stays moderate`() {
        val obs = RawDeviceObservation(
            source = DetectionSource.BLE,
            displayName = "Nearby AirTag",
            rawAddress = "4A:11:22:33:44:55",
            addressType = "RANDOM_RPA",
            manufacturerName = "Apple, Inc.",
            companyIdOrOui = "0x004C",
            serviceUuids = listOf("FD6F"),
            manufacturerDataHex = "1219001122",
            rssi = -82,
            timestamp = 2000L,
            categoryHint = DeviceCategory.COMMERCIAL_TRACKER
        )
        val history = listOf(
            DeviceAppearanceEntity(1, "fp", "S1", 1000L, -84, "4A:11:22:33:44:55", "", null, "")
        )
        val assessment = DeviceIntelligenceEngine.assessRisk(null, obs, history, DeviceCategory.COMMERCIAL_TRACKER)
        assertEquals(RiskLevel.MODERATE, assessment.riskLevel)
    }
}
