package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.BluetoothSearching
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Hotel
import androidx.compose.material.icons.filled.Nfc
import androidx.compose.material.icons.filled.PersonSearch
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material.icons.filled.WifiFind
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.core.model.InvestigationMode
import com.example.ui.components.SectionHeader
import com.example.ui.components.TacticalCard
import com.example.ui.theme.LocalSentinelPalette

@Composable
fun ScanToolsHubScreen(
    isExtendedServiceRunning: Boolean,
    extendedCycleSummary: String,
    onStartFullScan: () -> Unit,
    onToggleExtendedService: () -> Unit,
    onOpenMode: (InvestigationMode) -> Unit,
    onOpenBle: () -> Unit,
    onOpenWifi: () -> Unit,
    onOpenHiddenCamera: () -> Unit,
    onOpenMagnetometer: () -> Unit,
    onOpenGps: () -> Unit,
    onOpenNfc: () -> Unit,
    onOpenUwb: () -> Unit,
    onOpenExternalRf: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalSentinelPalette.current

    val modeIcons = mapOf(
        InvestigationMode.PERSONAL to Icons.Filled.PersonSearch,
        InvestigationMode.VEHICLE to Icons.Filled.DirectionsCar,
        InvestigationMode.HOME to Icons.Filled.Home,
        InvestigationMode.HOTEL to Icons.Filled.Hotel,
        InvestigationMode.OFFICE to Icons.Filled.Apartment,
        InvestigationMode.DEEP to Icons.Filled.Radar
    )

    val hardwareModules: List<Triple<String, String, Pair<ImageVector, () -> Unit>>> = listOf(
        Triple("Bluetooth LE Scanner", "Live BLE discovery, tracker signatures & RSSI telemetry", Icons.Filled.BluetoothSearching to onOpenBle),
        Triple("Wi-Fi & Authorized LAN", "Nearby APs, duplicate SSID flags & authorized camera/mDNS discovery", Icons.Filled.WifiFind to onOpenWifi),
        Triple("Hidden Camera Center", "CameraX + torch reflection inspector, IR sensor check & physical targets", Icons.Filled.CameraAlt to onOpenHiddenCamera),
        Triple("Magnetometer Analyzer", "3-axis µT readings, baseline calibration & relative anomaly chart", Icons.Filled.Explore to onOpenMagnetometer),
        Triple("GPS & Cellular Investigation", "OBD-II, hardwired, magnetic vehicle checklists & tracker product DB", Icons.Filled.GpsFixed to onOpenGps),
        Triple("NFC & RFID Investigation", "13.56 MHz NFC tag reader + external LF/UHF RFID reader bridge", Icons.Filled.Nfc to onOpenNfc),
        Triple("Ultra-Wideband (UWB)", "UWB chipset diagnostics & FiRa OOB compatibility info", Icons.Filled.Sensors to onOpenUwb),
        Triple("External RF & SDR Hardware", "USB-C / OTG SDR & spectrum analyzer interface (RTL-SDR, HackRF, tinySA)", Icons.Filled.Usb to onOpenExternalRf)
    )

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            TacticalCard(accentColor = MaterialTheme.colorScheme.primary) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "One-Touch Comprehensive Full Scan",
                        style = MaterialTheme.typography.titleLarge
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Executes hardware & permission verification, magnetometer baseline, BLE sweep, Wi-Fi audit, authorized LAN discovery, NFC/UWB/RF checks, and intelligence correlation.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = onStartFullScan,
                        modifier = Modifier
                            .fillMaxWidth()
                            .minimumInteractiveComponentSize()
                            .testTag("hub_full_scan_button")
                    ) {
                        Icon(Icons.Filled.Radar, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Launch Full Multi-Module Scan")
                    }
                }
            }
        }

        // Foreground Extended Observation Service
        item {
            TacticalCard(
                accentColor = if (isExtendedServiceRunning) palette.low else null
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Extended Observation Session (Foreground Service)",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = if (isExtendedServiceRunning) {
                                    "Active • $extendedCycleSummary"
                                } else {
                                    "Runs periodic BLE sweeps with an active Android foreground notification (stops automatically after 6 cycles to protect battery)."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = onToggleExtendedService,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("toggle_extended_service_button")
                    ) {
                        Text(if (isExtendedServiceRunning) "Stop Extended Observation" else "Start Extended Observation")
                    }
                }
            }
        }

        item {
            SectionHeader(
                title = "6 Dedicated Investigation Modes",
                subtitle = "Tailored workflows, checklists, and risk inventories per environment"
            )
        }

        items(InvestigationMode.entries, key = { it.id }) { mode ->
            TacticalCard(
                onClick = { onOpenMode(mode) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("mode_card_${mode.id}")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = modeIcons[mode] ?: Icons.Filled.Radar,
                        contentDescription = mode.title,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(26.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = mode.title, style = MaterialTheme.typography.titleMedium)
                        Text(
                            text = mode.subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        item {
            SectionHeader(
                title = "Individual Sensor & Radio Modules",
                subtitle = "Run standalone hardware diagnostics or focused sweeps"
            )
        }

        items(hardwareModules, key = { it.first }) { (title, subtitle, iconAndClick) ->
            TacticalCard(
                onClick = iconAndClick.second,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = iconAndClick.first,
                        contentDescription = title,
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = title, style = MaterialTheme.typography.titleMedium)
                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}
