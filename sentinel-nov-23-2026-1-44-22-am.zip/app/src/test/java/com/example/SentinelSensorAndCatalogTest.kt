package com.example

import android.Manifest
import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.core.data.InvestigationContentCatalog
import com.example.core.model.DeviceCategory
import com.example.core.model.InvestigationMode
import com.example.core.security.ManufacturerLookup
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class SentinelSensorAndCatalogTest {

    @Test
    fun `all six investigation modes have checklists and recommended modules`() {
        assertEquals(6, InvestigationMode.entries.size)
        InvestigationMode.entries.forEach { mode ->
            val items = InvestigationContentCatalog.checklistForMode(mode)
            assertTrue("Checklist empty for ${mode.id}", items.isNotEmpty())
            assertTrue("Modules empty for ${mode.id}", mode.recommendedModules.isNotEmpty())
        }
        assertTrue(InvestigationContentCatalog.hiddenCameraPhysicalTargets.size >= 10)
        assertTrue(InvestigationContentCatalog.educationalGuides.size >= 9)
    }

    @Test
    fun `manufacturer lookup resolves tracker company IDs, camera OUIs, and NFC silicon`() {
        assertEquals("Apple, Inc.", ManufacturerLookup.lookupBleCompany(0x004C)?.manufacturer)
        assertEquals("Tile, Inc. (Life360)", ManufacturerLookup.lookupBleCompany(0x0642)?.manufacturer)
        assertEquals(DeviceCategory.SUSPECTED_CAMERA, ManufacturerLookup.lookupOui("B4:A3:82:11:22:33")?.categoryHint)
        assertTrue(ManufacturerLookup.isRandomizedMac("4A:11:22:33:44:55"))
        assertTrue(ManufacturerLookup.isRandomizedMac("4a-11-22-33-44-55"))
        assertTrue(ManufacturerLookup.isRandomizedMac("4A1122334455"))
        assertFalse(ManufacturerLookup.isRandomizedMac("B4:A3:82:11:22:33"))
        assertFalse(ManufacturerLookup.isRandomizedMac("B4-A3-82-11-22-33"))
        assertTrue(ManufacturerLookup.lookupNfcManufacturerByUid(byteArrayOf(0x04, 0x11, 0x22)).contains("NXP"))
    }

    @Test
    fun `external RF hardware compatibility database includes SDR and spectrum analyzers`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val rfMgr = (context.applicationContext as SentinelApplication).container.externalRfManager
        val db = rfMgr.compatibilityDatabase
        assertTrue(db.any { it.name.contains("RTL-SDR") })
        assertTrue(db.any { it.name.contains("HackRF") })
        assertTrue(db.any { it.name.contains("tinySA") })
        assertNotNull(rfMgr.scanAttachedUsbDevices())
    }

    @Test
    fun `missing scan permissions includes all required runtime permissions and clears when granted`() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val diag = (app as SentinelApplication).container.diagnosticsManager
        val missingInitial = diag.getMissingScanPermissions().toSet()

        assertTrue(Manifest.permission.BLUETOOTH_SCAN in missingInitial)
        assertTrue(Manifest.permission.BLUETOOTH_CONNECT in missingInitial)
        assertTrue(Manifest.permission.ACCESS_FINE_LOCATION in missingInitial)
        assertTrue(Manifest.permission.ACCESS_COARSE_LOCATION in missingInitial)
        assertTrue(Manifest.permission.POST_NOTIFICATIONS in missingInitial)

        Shadows.shadowOf(app).grantPermissions(*missingInitial.toTypedArray())
        assertTrue(diag.getMissingScanPermissions().isEmpty())
    }

    @Test
    fun `manifest omits INTERNET and CHANGE_WIFI_STATE for zero-cloud privacy`() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        @Suppress("DEPRECATION")
        val pkgInfo = app.packageManager.getPackageInfo(
            app.packageName,
            android.content.pm.PackageManager.GET_PERMISSIONS
        )
        val requested = pkgInfo.requestedPermissions?.toSet().orEmpty()
        assertFalse(Manifest.permission.INTERNET in requested)
        assertFalse(Manifest.permission.CHANGE_WIFI_STATE in requested)
        assertTrue(Manifest.permission.ACCESS_WIFI_STATE in requested)
        assertTrue(Manifest.permission.ACCESS_NETWORK_STATE in requested)
    }
}
