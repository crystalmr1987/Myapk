package com.example

import android.app.Application
import com.example.services.DatabaseMaintenanceWorker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SentinelApplication : Application() {
    lateinit var container: SentinelAppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = SentinelAppContainer(this)
        CoroutineScope(Dispatchers.IO).launch {
            container.repository.ensureIntelSeeded()
            DatabaseMaintenanceWorker.schedule(this@SentinelApplication)
        }
    }
}
