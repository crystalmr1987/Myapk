package com.example

import android.Manifest
import android.app.Application
import android.bluetooth.BluetoothManager
import android.content.Context
import android.location.LocationManager
import android.net.wifi.WifiManager
import android.provider.Settings
import androidx.test.core.app.ApplicationProvider
import com.example.core.model.BleScanProfile
import com.example.core.model.InvestigationMode
import com.example.core.model.ModuleExecutionState
import com.example.core.preferences.SentinelSettings
import com.example.sensors.BleScanEvent
import com.example.ui.SensorToolsViewModel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class SentinelScannerDiagnosticsTest {

    @Test
    fun `bluetooth adapter enabled state is recognized even when BLE scanner is unavailable`() = runBlocking {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val container = (app as SentinelApplication).container
        val btManager = app.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter = btManager.adapter
        Shadows.shadowOf(app).grantPermissions(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_CONNECT
        )

        if (adapter != null) {
            Shadows.shadowOf(adapter).setEnabled(true)
            val report = container.diagnosticsManager.generateReport()
            assertTrue("Expected Bluetooth enabled to be recognized", report.bluetooth.enabled)
            assertTrue(report.bluetooth.detail.contains("ON"))

            val events = withTimeout(8_000L) {
                container.bluetoothScanner.scanBle(BleScanProfile.QUICK).toList()
            }
            // Should complete cleanly or emit a non-"turned off" diagnostic
            val errorEvent = events.filterIsInstance<BleScanEvent.Error>().firstOrNull()
            if (errorEvent != null) {
                assertFalse(
                    "Should not falsely claim Bluetooth is turned off when enabled: ${errorEvent.message}",
                    errorEvent.message.contains("turned off", ignoreCase = true)
                )
            } else {
                assertTrue(events.any { it is BleScanEvent.Completed })
            }
        }
    }

    @Test
    fun `bluetooth scanner terminates immediately with clear error when bluetooth is off`() = runBlocking {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val container = (app as SentinelApplication).container
        Shadows.shadowOf(app).grantPermissions(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_CONNECT
        )
        Settings.Global.putInt(app.contentResolver, Settings.Global.BLUETOOTH_ON, 0)
        val btManager = app.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        btManager.adapter?.let { Shadows.shadowOf(it).setEnabled(false) }

        val events = withTimeout(1_500L) {
            container.bluetoothScanner.scanBle(BleScanProfile.QUICK).toList()
        }
        val err = events.filterIsInstance<BleScanEvent.Error>().firstOrNull()
        assertTrue("Expected BleScanEvent.Error when Bluetooth is off", err != null)
        assertTrue(err!!.message.contains("turned off", ignoreCase = true) || err.message.contains("radio", ignoreCase = true))
    }

    @Test
    fun `diagnostics and wifi inspector distinguish coarse-only from fine location and system location off`() = runBlocking {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val container = (app as SentinelApplication).container
        val wifiMgr = app.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        @Suppress("DEPRECATION")
        wifiMgr.isWifiEnabled = true

        // Case 1: Only Approximate (COARSE) location granted
        Shadows.shadowOf(app).grantPermissions(Manifest.permission.ACCESS_COARSE_LOCATION)
        assertTrue(container.diagnosticsManager.hasCoarseLocationOnly())
        assertFalse(container.diagnosticsManager.hasFineLocationPermission())
        assertFalse(container.diagnosticsManager.generateReport().wifi.permissionGranted)

        val coarseReport = container.wifiInspector.scanNearbyAccessPoints()
        assertTrue(coarseReport.warning?.contains("Approximate", ignoreCase = true) == true)

        // Case 2: Precise (FINE) location granted, but System Location OFF
        Shadows.shadowOf(app).grantPermissions(Manifest.permission.ACCESS_FINE_LOCATION)
        assertFalse(container.diagnosticsManager.hasCoarseLocationOnly())
        assertTrue(container.diagnosticsManager.hasFineLocationPermission())
        assertTrue(container.diagnosticsManager.generateReport().wifi.permissionGranted)

        val locMgr = app.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        Shadows.shadowOf(locMgr).setLocationEnabled(false)
        val locOffReport = container.wifiInspector.scanNearbyAccessPoints()
        assertTrue(locOffReport.warning?.contains("Location Services", ignoreCase = true) == true)
    }

    @Test
    fun `full scan coordinator completes promptly and never fails step 6 without optional usb sdr`() = runBlocking {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val container = (app as SentinelApplication).container

        val states = withTimeout(8_000L) {
            container.fullScanCoordinator
                .runComprehensiveScan(InvestigationMode.DEEP, SentinelSettings())
                .toList()
        }
        val finalState = states.last()
        assertFalse(finalState.isRunning)
        assertEquals(6, finalState.modules.size)
        val peripheralStep = finalState.modules.last()
        assertFalse(peripheralStep.state == ModuleExecutionState.FAILED)
        assertFalse(finalState.warnings.any { it.contains("SDR", ignoreCase = true) })
    }

    @Test
    fun `system BLUETOOTH_ON setting prevents false turned-off error when HAL inactive or permission missing`() = runBlocking {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val container = (app as SentinelApplication).container
        val btManager = app.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        btManager.adapter?.let { Shadows.shadowOf(it).setEnabled(false) }
        Settings.Global.putInt(app.contentResolver, Settings.Global.BLUETOOTH_ON, 1)

        // When BLE permission is not granted yet, BLUETOOTH_ON=1 keeps bluetooth.enabled true
        val reportNoPerm = container.diagnosticsManager.generateReport()
        if (btManager.adapter != null) {
            assertTrue(reportNoPerm.bluetooth.enabled)
            assertFalse(reportNoPerm.bluetooth.permissionGranted)
        }

        // When permission IS granted but adapter HAL stays inactive despite BLUETOOTH_ON=1,
        // error message should clearly explain HAL inactivity rather than saying "Bluetooth is turned off"
        Shadows.shadowOf(app).grantPermissions(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_CONNECT
        )
        val events = withTimeout(1_500L) {
            container.bluetoothScanner.scanBle(BleScanProfile.QUICK).toList()
        }
        val err = events.filterIsInstance<BleScanEvent.Error>().firstOrNull()
        if (btManager.adapter != null && err != null) {
            assertFalse("Should not claim Bluetooth is turned off when BLUETOOTH_ON=1", err.message.contains("turned off", ignoreCase = true))
        }
    }

    @Test
    fun `viewmodel verifies BLUETOOTH_SCAN and ACCESS_FINE_LOCATION state before triggering scanners`() = runBlocking {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val container = (app as SentinelApplication).container
        val vm = SensorToolsViewModel(container)

        // 1. BLE scan without BLUETOOTH_SCAN permission is blocked synchronously before scanning
        vm.startBleScan(BleScanProfile.QUICK, optInLocation = false)
        assertFalse(vm.bleScanning.value)
        assertTrue(vm.bleError.value?.contains("BLUETOOTH_SCAN", ignoreCase = true) == true)

        // 2. Granting BLUETOOTH_SCAN satisfies hasBleScanPermission() even before BLUETOOTH_CONNECT
        Shadows.shadowOf(app).grantPermissions(Manifest.permission.BLUETOOTH_SCAN)
        assertTrue(container.diagnosticsManager.hasBleScanPermission())
        val btManager = app.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        btManager.adapter?.let {
            Shadows.shadowOf(it).setEnabled(false)
            Settings.Global.putInt(app.contentResolver, Settings.Global.BLUETOOTH_ON, 0)
            vm.startBleScan(BleScanProfile.QUICK, optInLocation = false)
            assertFalse(vm.bleScanning.value)
            assertTrue(vm.bleError.value?.contains("turned off", ignoreCase = true) == true)
        }

        // 3. Wi-Fi scan with only COARSE location is blocked before triggering Wi-Fi scan
        val wifiMgr = app.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        @Suppress("DEPRECATION")
        wifiMgr.isWifiEnabled = true
        Shadows.shadowOf(app).grantPermissions(Manifest.permission.ACCESS_COARSE_LOCATION)
        vm.runWifiScan(optInLocation = false)
        assertFalse(vm.wifiScanning.value)
        assertTrue(vm.wifiBanner.value?.contains("ACCESS_FINE_LOCATION", ignoreCase = true) == true)
    }

    @Test
    fun `tracker safety intent prioritizes DULT action when available and quick LAN scan persists session`() = runBlocking {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val container = (app as SentinelApplication).container
        val intent = container.bluetoothScanner.createAndroidTrackerSafetyIntent()
        assertTrue(intent.action != null)

        val vm = SensorToolsViewModel(container)
        val beforeCount = container.repository.scanSessions.first().size
        vm.runAuthorizedLanScan(optInLocation = false)
        Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
        withTimeout(5_000L) {
            while (vm.lanScanning.value) {
                Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
                kotlinx.coroutines.delay(25)
            }
            val sessions = container.repository.scanSessions.first { list ->
                list.size >= beforeCount + 1 && list.any { it.modeId == "LAN_AUDIT" && it.status == "COMPLETED" }
            }
            assertTrue("Expected LAN audit session to be persisted", sessions.size >= beforeCount + 1)
        }
        container.repository.wipeAllUserData()
    }
}
