package com.example.sensors

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.core.uwb.UwbManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class UwbDiagnosticState(
    val hardwareFeaturePresent: Boolean,
    val permissionGranted: Boolean,
    val uwbServiceAvailable: Boolean,
    val localAddressSummary: String,
    val channelSummary: String,
    val statusDetail: String,
    val limitationExplanation: String
)

class UwbManagerHelper(private val context: Context) {

    suspend fun inspectUwbCapabilities(): UwbDiagnosticState = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val hasFeature = pm.hasSystemFeature("android.hardware.uwb")
        val hasPerm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.UWB_RANGING) ==
                PackageManager.PERMISSION_GRANTED
        } else {
            true
        }

        if (!hasFeature) {
            return@withContext UwbDiagnosticState(
                hardwareFeaturePresent = false,
                permissionGranted = hasPerm,
                uwbServiceAvailable = false,
                localAddressSummary = "Unavailable",
                channelSummary = "Unavailable",
                statusDetail = "No UWB radio detected on this Android device.",
                limitationExplanation = "UWB ranging requires dedicated UWB hardware (e.g., Pixel Pro, Samsung Galaxy Ultra/Plus/Fold). Furthermore, Android UWB requires FiRa out-of-band (OOB) parameter exchange via BLE and cannot passively intercept proprietary AirTag or SmartTag UWB pulses."
            )
        }

        if (!hasPerm) {
            return@withContext UwbDiagnosticState(
                hardwareFeaturePresent = true,
                permissionGranted = false,
                uwbServiceAvailable = false,
                localAddressSummary = "Permission required",
                channelSummary = "Permission required",
                statusDetail = "UWB hardware present, awaiting UWB_RANGING runtime permission.",
                limitationExplanation = "Grant Nearby Devices / UWB permission to query local FiRa UWB session capabilities."
            )
        }

        return@withContext try {
            val manager = UwbManager.createInstance(context)
            @Suppress("DEPRECATION")
            val available = manager.isAvailable()
            if (available) {
                val scope = manager.controleeSessionScope()
                UwbDiagnosticState(
                    hardwareFeaturePresent = true,
                    permissionGranted = true,
                    uwbServiceAvailable = true,
                    localAddressSummary = scope.localAddress.toString(),
                    channelSummary = "FiRa MAC 1.3 OOB Ready",
                    statusDetail = "UWB subsystem active and ready for FiRa OOB-paired ranging.",
                    limitationExplanation = "Android's UWB API performs secure paired ranging after exchanging session keys over BLE/OOB. It cannot passively sniff unauthorized trackers' UWB frames without pairing."
                )
            } else {
                UwbDiagnosticState(
                    hardwareFeaturePresent = true,
                    permissionGranted = true,
                    uwbServiceAvailable = false,
                    localAddressSummary = "Service disabled",
                    channelSummary = "Unavailable",
                    statusDetail = "UWB hardware detected, but UWB radio is disabled in system settings or Airplane Mode.",
                    limitationExplanation = "Enable Ultra-Wideband in Android Settings > Connected devices > Connection preferences."
                )
            }
        } catch (t: Throwable) {
            UwbDiagnosticState(
                hardwareFeaturePresent = hasFeature,
                permissionGranted = hasPerm,
                uwbServiceAvailable = false,
                localAddressSummary = "Unavailable",
                channelSummary = "Unavailable",
                statusDetail = "UWB query returned: ${t.localizedMessage ?: "Unsupported on current OS build"}",
                limitationExplanation = "UWB ranging requires Android 12+ with Google Play Services UWB module and FiRa-compliant peers."
            )
        }
    }
}
