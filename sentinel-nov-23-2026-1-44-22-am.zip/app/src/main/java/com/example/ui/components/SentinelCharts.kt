package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.example.core.intelligence.DeviceRelationshipCluster
import com.example.ui.theme.LocalSentinelPalette
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun TelemetryLineChart(
    values: List<Float>,
    baseline: Float? = null,
    lineColor: Color,
    unitLabel: String,
    emptyMessage: String,
    modifier: Modifier = Modifier
) {
    val gridColor = LocalSentinelPalette.current.gridLine.copy(alpha = 0.45f)
    val baselineColor = MaterialTheme.colorScheme.tertiary

    Column(modifier = modifier.fillMaxWidth()) {
        if (values.isEmpty()) {
            Text(
                text = emptyMessage,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 24.dp)
            )
            return
        }

        val minVal = (values + listOfNotNull(baseline)).minOrNull() ?: 0f
        val maxVal = (values + listOfNotNull(baseline)).maxOrNull() ?: 1f
        val span = (maxVal - minVal).coerceAtLeast(1f)

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Min: ${"%.1f".format(minVal)} $unitLabel",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (baseline != null) {
                Text(
                    text = "Baseline: ${"%.1f".format(baseline)} $unitLabel",
                    style = MaterialTheme.typography.labelSmall,
                    color = baselineColor
                )
            }
            Text(
                text = "Max: ${"%.1f".format(maxVal)} $unitLabel",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(modifier = Modifier.height(6.dp))

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
        ) {
            val w = size.width
            val h = size.height
            val padY = 12f
            val usableH = (h - padY * 2).coerceAtLeast(1f)

            // Horizontal reference grid
            for (i in 0..3) {
                val gy = padY + usableH * (i / 3f)
                drawLine(
                    color = gridColor,
                    start = Offset(0f, gy),
                    end = Offset(w, gy),
                    strokeWidth = 1f
                )
            }

            if (baseline != null) {
                val by = padY + usableH * (1f - ((baseline - minVal) / span))
                drawLine(
                    color = baselineColor.copy(alpha = 0.8f),
                    start = Offset(0f, by),
                    end = Offset(w, by),
                    strokeWidth = 2f
                )
            }

            if (values.size == 1) {
                val cy = padY + usableH * (1f - ((values[0] - minVal) / span))
                drawCircle(color = lineColor, radius = 6f, center = Offset(w / 2f, cy))
            } else {
                val path = Path()
                val fillPath = Path()
                val stepX = w / (values.size - 1).coerceAtLeast(1)

                values.forEachIndexed { idx, v ->
                    val x = idx * stepX
                    val y = padY + usableH * (1f - ((v - minVal) / span))
                    if (idx == 0) {
                        path.moveTo(x, y)
                        fillPath.moveTo(x, h)
                        fillPath.lineTo(x, y)
                    } else {
                        path.lineTo(x, y)
                        fillPath.lineTo(x, y)
                    }
                }
                fillPath.lineTo(w, h)
                fillPath.close()

                drawPath(
                    path = fillPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(lineColor.copy(alpha = 0.25f), Color.Transparent)
                    )
                )
                drawPath(
                    path = path,
                    color = lineColor,
                    style = Stroke(width = 3.5f, cap = StrokeCap.Round)
                )
            }
        }
    }
}

@Composable
fun RiskDistributionBar(
    low: Int,
    moderate: Int,
    high: Int,
    critical: Int,
    modifier: Modifier = Modifier
) {
    val palette = LocalSentinelPalette.current
    val total = (low + moderate + high + critical).coerceAtLeast(1)

    Column(modifier = modifier.fillMaxWidth()) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(12.dp)
        ) {
            val w = size.width
            val h = size.height
            var startX = 0f
            val segments = listOf(
                low to palette.low,
                moderate to palette.moderate,
                high to palette.high,
                critical to palette.critical
            )
            segments.forEach { (count, color) ->
                if (count > 0) {
                    val segW = w * (count.toFloat() / total)
                    drawRect(
                        color = color,
                        topLeft = Offset(startX, 0f),
                        size = androidx.compose.ui.geometry.Size(segW, h)
                    )
                    startX += segW
                }
            }
            if (low + moderate + high + critical == 0) {
                drawRect(color = palette.gridLine.copy(alpha = 0.4f), size = size)
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("LOW $low", style = MaterialTheme.typography.labelSmall, color = palette.low)
            Text("MOD $moderate", style = MaterialTheme.typography.labelSmall, color = palette.moderate)
            Text("HIGH $high", style = MaterialTheme.typography.labelSmall, color = palette.high)
            Text("CRIT $critical", style = MaterialTheme.typography.labelSmall, color = palette.critical)
        }
    }
}

@Composable
fun RelationshipGraphCanvas(
    clusters: List<DeviceRelationshipCluster>,
    modifier: Modifier = Modifier
) {
    val palette = LocalSentinelPalette.current
    val primaryColor = MaterialTheme.colorScheme.primary
    val nodeStroke = MaterialTheme.colorScheme.onSurface

    val uniqueNodes = clusters.flatMap {
        listOf(it.primaryFingerprintId to it.primaryLabel, it.relatedFingerprintId to it.relatedLabel)
    }.distinctBy { it.first }.take(10)

    if (uniqueNodes.isEmpty()) {
        Text(
            text = "No recurring multi-session co-occurrences recorded yet. Run multiple scans to analyze device relationships.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(12.dp)
        )
        return
    }

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(200.dp)
    ) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val radius = (minOf(size.width, size.height) * 0.36f)
        val positions = mutableMapOf<String, Offset>()

        uniqueNodes.forEachIndexed { idx, (id, _) ->
            val angle = (2.0 * Math.PI * idx / uniqueNodes.size) - Math.PI / 2.0
            positions[id] = Offset(
                x = cx + (radius * cos(angle)).toFloat(),
                y = cy + (radius * sin(angle)).toFloat()
            )
        }

        clusters.forEach { edge ->
            val a = positions[edge.primaryFingerprintId]
            val b = positions[edge.relatedFingerprintId]
            if (a != null && b != null) {
                drawLine(
                    color = palette.moderate.copy(alpha = 0.7f),
                    start = a,
                    end = b,
                    strokeWidth = (2f + edge.sharedSessionCount).coerceAtMost(8f)
                )
            }
        }

        positions.values.forEach { pos ->
            drawCircle(color = primaryColor, radius = 14f, center = pos)
            drawCircle(
                color = nodeStroke,
                radius = 14f,
                center = pos,
                style = Stroke(width = 2f)
            )
        }
    }
}
