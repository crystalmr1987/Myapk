package com.example.core.data

import com.example.core.model.ChecklistTemplateItem
import com.example.core.model.GuideArticle
import com.example.core.model.InvestigationMode

object InvestigationContentCatalog {

    fun checklistForMode(mode: InvestigationMode): List<ChecklistTemplateItem> = when (mode) {
        InvestigationMode.PERSONAL -> listOf(
            ChecklistTemplateItem("per_1", "Outerwear & Pockets", "Inspect jacket linings, seams, and pockets", "Feel for small coin-sized discs (25-35mm) stitched or slipped into seams."),
            ChecklistTemplateItem("per_2", "Bags & Luggage", "Inspect hidden zippers, luggage tags, and lining gaps", "Remove laptop sleeves and inspect internal base boards of backpacks and suitcases."),
            ChecklistTemplateItem("per_3", "Wallet & Keychain", "Inspect cardholders and key fobs", "Slim card trackers resemble credit cards (~2mm thick) inside wallet slots."),
            ChecklistTemplateItem("per_4", "Android Built-In Safety", "Verify Android Unknown Tracker Alerts", "Ensure Android Settings > Safety & emergency > Unknown tracker alerts is enabled.")
        )
        InvestigationMode.VEHICLE -> listOf(
            ChecklistTemplateItem("veh_1", "OBD-II Diagnostic Port", "Inspect port under steering column", "Check for an unfamiliar plug-in module or a Y-splitter cable tucked behind the lower dash."),
            ChecklistTemplateItem("veh_2", "Exterior Magnetic Mounts", "Check wheel wells, frame rails, and bumpers", "Use a flashlight and mirror; sweep with Magnetometer Scanner along non-moving trim."),
            ChecklistTemplateItem("veh_3", "Underbody & Exhaust Shield", "Inspect rear bumper cavity and spare tire well", "Battery-powered magnetic GPS boxes are often placed inside rear bumper plastic lips."),
            ChecklistTemplateItem("veh_4", "Interior & Hardwired 12V", "Check fuse box, under-seat wiring, and trunk", "Look for non-factory black boxes tapped into constant 12V wires or fuse taps."),
            ChecklistTemplateItem("veh_5", "BLE Beacon Sweep", "Run BLE scan with engine off and doors closed", "Isolates trackers transmitting BLE inside cabin from passing vehicles.")
        )
        InvestigationMode.HOME -> listOf(
            ChecklistTemplateItem("hom_1", "Router & Authorized LAN", "Audit connected clients on home Wi-Fi", "Run SENTINEL Authorized LAN Discovery and compare MAC/hostnames against known household devices."),
            ChecklistTemplateItem("hom_2", "Smoke & Carbon Monoxide Detectors", "Check ceiling mounts for extra pinholes or wiring", "Verify brand/model matches property standard; look for secondary lens apertures."),
            ChecklistTemplateItem("hom_3", "USB Chargers & Outlets", "Inspect wall adapters left behind", "Unfamiliar USB wall cubes with a tiny front dark spot or microSD slot warrant removal and inspection."),
            ChecklistTemplateItem("hom_4", "Optical Lens Sweep", "Use Flashlight Camera Reflection tool in dim light", "Slowly pan across bookshelves, clocks, vents, and picture frames.")
        )
        InvestigationMode.HOTEL -> listOf(
            ChecklistTemplateItem("hot_1", "Alarm Clocks & Bedside Electronics", "Inspect clock faces facing the bed", "Shine Camera Flashlight at an angle across glossy black clock plastics for circular lens reflections."),
            ChecklistTemplateItem("hot_2", "Mirrors & Bathroom Fixtures", "Perform fingernail & reflection check on mirrors", "In two-way glass, the reflection touches your fingertip with almost zero gap; check wall frames."),
            ChecklistTemplateItem("hot_3", "Smoke Detectors & HVAC Vents", "Inspect ceiling vents and sprinklers facing sleeping areas", "Look for asymmetrical dark glass dots or misaligned louvers."),
            ChecklistTemplateItem("hot_4", "TVs, Set-Top Boxes & Wi-Fi", "Check devices near TV stand and inspect Wi-Fi SSIDs", "Scan nearby Wi-Fi APs for unusual camera hotspots (e.g. IPC-xxxx, ESP32).")
        )
        InvestigationMode.OFFICE -> listOf(
            ChecklistTemplateItem("off_1", "Desk & Monitor Peripherals", "Inspect unfamiliar USB hubs, docks, or power strips", "Check underside of desks and conference tables for magnetic or adhesive boxes."),
            ChecklistTemplateItem("off_2", "Authorized Network Audit", "Coordinate with IT to inspect unknown LAN hosts", "Do not scan corporate networks without explicit authorization."),
            ChecklistTemplateItem("off_3", "Conference Room Optics", "Inspect ceiling speakers, clocks, and decorative plants", "Use optical sweep in dimmed room.")
        )
        InvestigationMode.DEEP -> listOf(
            ChecklistTemplateItem("deep_1", "Full Multi-Sensor Sweep", "Execute 14-step Full Scan across all available radios", "Collects BLE, Wi-Fi, authorized LAN, Magnetometer, NFC, UWB, and USB RF diagnostics."),
            ChecklistTemplateItem("deep_2", "Move & Re-Scan Baseline", "Re-scan after relocating 200m+ away", "Compares persistent devices across separate environments to filter stationary neighbors."),
            ChecklistTemplateItem("deep_3", "Optical & Physical Inspection", "Complete room or vehicle physical checklist", "Radio scans cannot detect offline SD-card recorders or passive GPS loggers."),
            ChecklistTemplateItem("deep_4", "Evidence Documentation", "Attach unmodified photos and SHA-256 report", "Preserve evidence chain before altering suspected equipment.")
        )
    }

    val hiddenCameraPhysicalTargets: List<ChecklistTemplateItem> = listOf(
        ChecklistTemplateItem("cam_smoke", "Smoke Detectors", "Smoke / CO Detectors", "Look for off-center pinholes, mismatched paint, or extra status LEDs."),
        ChecklistTemplateItem("cam_clock", "Clocks", "Digital Clocks & Radios", "Dark acrylic fronts often hide pinhole optics behind the tint; test with flashlight reflection."),
        ChecklistTemplateItem("cam_outlet", "Outlets", "Electrical Outlets & Wall Plates", "Check unused sockets or protruding screws for glass apertures."),
        ChecklistTemplateItem("cam_usb", "USB Chargers", "USB Wall Chargers & Power Banks", "Many covert Wi-Fi/SD cameras are built into functional 5V USB bricks."),
        ChecklistTemplateItem("cam_lamp", "Lamps", "Lamps & Light Fixtures", "Inspect lamp bases, shades, and smart-bulb housings."),
        ChecklistTemplateItem("cam_mirror", "Mirrors", "Wall & Bathroom Mirrors", "Check behind frames and perform fingertip gap check."),
        ChecklistTemplateItem("cam_vent", "Air Vents", "HVAC & Air Vents", "Look inside slats with flashlight for matte black housings or cables."),
        ChecklistTemplateItem("cam_decor", "Decorative Objects", "Picture Frames, Plants & Hooks", "Check coat hooks, stuffed items, and picture frame corners."),
        ChecklistTemplateItem("cam_furniture", "Furniture", "Bookshelves, Desks & Beds", "Check underside edges and hollow gaps facing seating or beds."),
        ChecklistTemplateItem("cam_electronics", "Electronics", "Speakers, TVs & Routers", "Verify all plugged-in devices belong to the environment.")
    )

    val educationalGuides: List<GuideArticle> = listOf(
        GuideArticle(
            id = "guide_ble_trackers",
            category = "Wireless Trackers",
            title = "How Bluetooth Trackers Work",
            summary = "Understand crowd-sourced BLE networks, rotating MAC addresses, and DULT alerts.",
            sections = listOf(
                "Crowd-Sourced Relay" to "Commercial tags (AirTag, SmartTag, Tile, FMDN) do not contain GPS or cellular chips. They emit low-power BLE beacons picked up by passing smartphones, which relay encrypted locations to the owner.",
                "MAC Address Rotation" to "To prevent third-party tracking of the tracker itself, tags rotate their Bluetooth MAC address periodically. SENTINEL tracks structural payload signatures alongside MAC changes.",
                "Why Single Detections Are Not Proof" to "A tag in a neighbor's bag or passing car will appear on a BLE scan. Persistent observation across multiple times and separated locations is needed before assuming tracking."
            ),
            keyLimitation = "Phones can only receive active BLE broadcasts; powered-off tags or tags inside shielded enclosures may not appear."
        ),
        GuideArticle(
            id = "guide_gps_vs_cellular",
            category = "Vehicle & GPS",
            title = "GPS Receivers vs. Cellular Trackers",
            summary = "Why smartphones cannot detect passive GPS receivers and what CAN be investigated.",
            sections = listOf(
                "GPS Reception Is Passive" to "GPS satellites broadcast one-way timing signals. A GPS receiver chip only listens—it emits zero RF energy. Therefore, NO smartphone or RF detector can detect a passive GPS logger remotely.",
                "Cellular Uplink Transmission" to "Real-time trackers pair a GPS receiver with a cellular modem (LTE-M/4G/2G) to upload coordinates periodically. Android OS blocks apps from intercepting other devices' cellular uplinks.",
                "Practical Detection Methods" to "Use physical inspection (OBD-II port, under-dash wiring, wheel wells, bumper cavities), magnetometer sweeps for neodymium mounting magnets, or an external calibrated RF spectrum analyzer."
            ),
            keyLimitation = "An ordinary Android phone cannot detect cellular tracker transmissions or passive GPS receivers."
        ),
        GuideArticle(
            id = "guide_hidden_cameras",
            category = "Optical & Network",
            title = "How Hidden Cameras Operate",
            summary = "Compare Wi-Fi IP cameras, offline SD recorders, and optical lens reflection.",
            sections = listOf(
                "Connected vs. Offline Cameras" to "Wi-Fi cameras connect to an access point or broadcast their own AP hotspot. Offline pinhole cameras record locally to a microSD card and emit NO Wi-Fi or Bluetooth signal.",
                "Optical Lens Reflection" to "Camera glass optics reflect light differently than matte plastic. Using a flashlight held close to the phone camera axis often produces a sharp pinpoint glint.",
                "Infrared Illumination Limits" to "Most modern phone rear cameras have built-in IR-cut filters that block 850nm/940nm night-vision LEDs. Front selfie cameras sometimes have weaker IR filters, though results vary by device."
            ),
            keyLimitation = "A reflection or unfamiliar LAN device never proves a hidden camera by itself; physical visual confirmation is required."
        ),
        GuideArticle(
            id = "guide_vehicle_inspection",
            category = "Field Checklists",
            title = "How to Inspect a Vehicle Safely",
            summary = "Step-by-step physical & electronic sweep for cars and motorcycles.",
            sections = listOf(
                "Step 1: Isolate the Radio Environment" to "Park in an open lot away from crowded apartments or traffic so nearby phones and cars do not clutter BLE/Wi-Fi results.",
                "Step 2: OBD-II & Cabin Check" to "Inspect the 16-pin OBD-II port beneath the dash. Check for Y-splitters where a fake port faces outward and a real tracker sits tucked behind the kick panel.",
                "Step 3: Exterior & Magnetometer Sweep" to "Inspect plastic bumper lips, frame rails, spare tire well, and wheel arches. Remember steel chassis naturally shifts magnetometer readings—calibrate per zone."
            ),
            keyLimitation = "Hardwired trackers hidden deep inside wiring harnesses may require an automotive technician or mechanic inspection."
        ),
        GuideArticle(
            id = "guide_hotel_inspection",
            category = "Field Checklists",
            title = "Inspecting a Hotel Room or Rental",
            summary = "Practical 10-minute check for temporary accommodations.",
            sections = listOf(
                "Authorized Network Audit" to "Connect to the room Wi-Fi and run SENTINEL Authorized LAN Discovery to see whether recognizable camera vendors or RTSP streams share your subnet.",
                "Line-of-Sight Sweep" to "Focus on objects facing the bed or shower: alarm clocks, smoke detectors, USB charging bricks, lamps, and mirrors.",
                "Do Not Tamper Unnecessarily" to "If you discover suspicious hardware, photograph it in place first and notify property management or local authorities."
            ),
            keyLimitation = "Property routers often use client isolation, which prevents LAN discovery of devices on the same Wi-Fi."
        ),
        GuideArticle(
            id = "guide_evidence_preservation",
            category = "Digital Forensics",
            title = "Preserving Digital & Physical Evidence",
            summary = "Chain-of-custody principles, SHA-256 integrity, and personal safety.",
            sections = listOf(
                "Before Touching Anything" to "Photograph the device in situ before unplugging or removing it. Note exact date, time, and location.",
                "Avoid Alerting Another Party" to "Removing or destroying a tracker immediately may alert the operator that it was found or destroy serial numbers/fingerprints.",
                "Cryptographic Integrity" to "SENTINEL preserves original captured photos unmodified, stores case notes encrypted via Android Keystore, and computes SHA-256 digests on exported PDF/JSON/CSV packages."
            ),
            keyLimitation = "App reports serve as structured personal documentation and do not replace formal law-enforcement forensics."
        ),
        GuideArticle(
            id = "guide_android_built_in",
            category = "Platform Safety",
            title = "Using Android Built-In Tracker Alerts",
            summary = "How Google Play Services Unknown Tracker Alerts complement SENTINEL.",
            sections = listOf(
                "OS-Level Background Detection" to "Android 6.0+ with Google Play Services supports system-level Unknown Tracker Alerts for DULT-compatible trackers (AirTag, Pebblebee, Chipolo, Motorola Moto Tag).",
                "Why OS Alerts Have Privileged Access" to "Android system services can correlate background BLE separation timers without draining third-party app battery. SENTINEL provides direct shortcuts to this system tool.",
                "When to Use Both" to "Use Android Unknown Tracker Alerts for passive background coverage and SENTINEL for active sweeps, Wi-Fi/LAN audits, magnetometer checks, and forensic case documentation."
            ),
            keyLimitation = "Proprietary non-DULT tags may not trigger native OS Unknown Tracker Alerts."
        ),
        GuideArticle(
            id = "guide_nfc_rfid",
            category = "RF & Hardware",
            title = "NFC vs. Passive RFID Limitations",
            summary = "Frequency bands (125 kHz LF, 13.56 MHz HF, 900 MHz UHF) explained.",
            sections = listOf(
                "Smartphone NFC Scope" to "Android NFC operates strictly at 13.56 MHz (ISO 14443 / 15693 / FeliCa) at ~1–4 cm contact range.",
                "Unsupported RFID Bands" to "Low-frequency 125 kHz access cards and long-range 860–960 MHz UHF inventory/toll RFID tags cannot be read by phone NFC chips.",
                "External Hardware Path" to "Reading LF or UHF RFID requires dedicated external hardware (e.g., Proxmark3 or UHF reader over USB OTG)."
            ),
            keyLimitation = "Ordinary smartphones cannot detect passive RFID tags at a distance."
        ),
        GuideArticle(
            id = "guide_seeking_help",
            category = "Personal Safety",
            title = "Safety Protocol & Professional Assistance",
            summary = "Prioritizing physical safety and non-confrontation if tracking is suspected.",
            sections = listOf(
                "Avoid Confrontation" to "Never confront a suspected party alone. Move to a well-lit public place, trusted friend's home, or police station if you feel unsafe.",
                "Independent Verification" to "Consider having a trusted mechanic inspect a vehicle on a lift or consulting a certified TSCM (Technical Surveillance Countermeasures) specialist for sensitive environments.",
                "Emergency Support" to "If you face immediate danger, contact local emergency services immediately. Use SENTINEL's Safety Center quick-dial shortcuts (opens system dialer for your manual confirmation)."
            ),
            keyLimitation = "Software tools support investigation but cannot guarantee physical security."
        )
    )
}
