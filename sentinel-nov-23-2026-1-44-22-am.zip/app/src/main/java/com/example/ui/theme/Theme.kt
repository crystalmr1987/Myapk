package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import com.example.core.model.RiskLevel
import com.example.core.model.ThemePreference

@Immutable
data class SentinelRiskPalette(
    val low: Color,
    val moderate: Color,
    val high: Color,
    val critical: Color,
    val cyanAccent: Color,
    val gridLine: Color
)

val LocalSentinelPalette = staticCompositionLocalOf {
    SentinelRiskPalette(
        low = TacticalEmerald,
        moderate = AmberAlert,
        high = HighOrange,
        critical = CriticalCrimson,
        cyanAccent = ElectricCyan,
        gridLine = SlateOutline
    )
}

fun SentinelRiskPalette.colorFor(riskLevel: RiskLevel): Color = when (riskLevel) {
    RiskLevel.LOW -> low
    RiskLevel.MODERATE -> moderate
    RiskLevel.HIGH -> high
    RiskLevel.CRITICAL -> critical
}

fun SentinelRiskPalette.colorForName(name: String): Color =
    colorFor(runCatching { RiskLevel.valueOf(name) }.getOrDefault(RiskLevel.MODERATE))

private val DarkColorScheme = darkColorScheme(
    primary = ElectricCyan,
    onPrimary = ObsidianBg,
    primaryContainer = DeepCyanContainer,
    onPrimaryContainer = ElectricCyan,
    secondary = TacticalEmerald,
    onSecondary = ObsidianBg,
    secondaryContainer = DeepEmeraldContainer,
    onSecondaryContainer = TacticalEmerald,
    tertiary = AmberAlert,
    onTertiary = ObsidianBg,
    background = ObsidianBg,
    onBackground = IceText,
    surface = CarbonSurface,
    onSurface = IceText,
    surfaceVariant = SlateSurfaceVariant,
    onSurfaceVariant = MutedSteelText,
    outline = SlateOutline,
    error = CriticalCrimson,
    onError = Color.White,
    errorContainer = DeepCrimsonContainer,
    onErrorContainer = CriticalCrimson
)

private val LightColorScheme = lightColorScheme(
    primary = DaylightCyan,
    onPrimary = Color.White,
    primaryContainer = DaylightCyanContainer,
    onPrimaryContainer = DaylightCyan,
    secondary = DaylightEmerald,
    onSecondary = Color.White,
    tertiary = DaylightAmber,
    background = DaylightBg,
    onBackground = DaylightText,
    surface = DaylightSurface,
    onSurface = DaylightText,
    surfaceVariant = DaylightSurfaceVariant,
    onSurfaceVariant = DaylightMutedText,
    outline = DaylightOutline,
    error = DaylightCrimson,
    onError = Color.White
)

private val SentinelShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

@Composable
fun SentinelTheme(
    themePreference: ThemePreference = ThemePreference.DARK,
    textScaleMultiplier: Float = 1.0f,
    content: @Composable () -> Unit
) {
    val useDark = when (themePreference) {
        ThemePreference.DARK -> true
        ThemePreference.LIGHT -> false
        ThemePreference.SYSTEM -> isSystemInDarkTheme()
    }

    val colorScheme = if (useDark) DarkColorScheme else LightColorScheme
    val riskPalette = if (useDark) {
        SentinelRiskPalette(
            low = TacticalEmerald,
            moderate = AmberAlert,
            high = HighOrange,
            critical = CriticalCrimson,
            cyanAccent = ElectricCyan,
            gridLine = SlateOutline
        )
    } else {
        SentinelRiskPalette(
            low = DaylightEmerald,
            moderate = DaylightAmber,
            high = DaylightOrange,
            critical = DaylightCrimson,
            cyanAccent = DaylightCyan,
            gridLine = DaylightOutline
        )
    }

    val systemFontScale = LocalDensity.current.fontScale.coerceAtLeast(0.5f)
    val boundedTextMultiplier = if (textScaleMultiplier > 1.0f && systemFontScale > 1.0f) {
        (1.6f / systemFontScale).coerceIn(1.0f, textScaleMultiplier)
    } else {
        textScaleMultiplier.coerceIn(0.85f, 1.30f)
    }

    CompositionLocalProvider(LocalSentinelPalette provides riskPalette) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = buildSentinelTypography(boundedTextMultiplier),
            shapes = SentinelShapes,
            content = content
        )
    }
}
