package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Nfc
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.core.model.CapabilityStatus
import com.example.core.model.HardwareDiagnosticsReport
import com.example.sensors.AttachedUsbHardware
import com.example.sensors.ExternalRfHardwareProfile
import com.example.sensors.ExternalRfidHardwareSpec
import com.example.sensors.NfcTagInspection
import com.example.sensors.UwbDiagnosticState
import com.example.ui.components.EmptyStatePanel
import com.example.ui.components.LimitationBanner
import com.example.ui.components.PermissionPromptCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.TacticalCard
import com.example.ui.theme.LocalSentinelPalette

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NfcRfidScreen(
    nfcSupported: Boolean,
    nfcEnabled: Boolean,
    lastTag: NfcTagInspection?,
    tagHistory: List<NfcTagInspection>,
    externalRfidSpecs: List<ExternalRfidHardwareSpec>,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val palette = LocalSentinelPalette.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("NFC & RFID Investigation") },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                LimitationBanner(
                    title = "NFC vs. Passive RFID Frequency Limits",
                    message = "Android NFC hardware operates exclusively at 13.56 MHz within ~1–4 cm contact range. It cannot detect 125 kHz LF access cards or 860–960 MHz UHF RFID tags at a distance without an external RFID reader."
                )
            }

            item {
                TacticalCard(accentColor = if (nfcEnabled) palette.low else palette.moderate) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = when {
                                !nfcSupported -> "NFC Hardware Absent on This Device"
                                !nfcEnabled -> "NFC Radio Disabled — Enable NFC in Settings"
                                else -> "NFC Reader Mode Active — Hold Tag to Back of Phone"
                            },
                            style = MaterialTheme.typography.titleMedium
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "When NFC is enabled and this screen is open, SENTINEL automatically parses UID, ISO technology, manufacturer prefix, and NDEF records.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            if (lastTag != null) {
                item {
                    TacticalCard(accentColor = MaterialTheme.colorScheme.primary) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Latest Scanned Tag", style = MaterialTheme.typography.titleMedium)
                            Text("UID: ${lastTag.uidHex}", style = MaterialTheme.typography.labelMedium, color = palette.cyanAccent)
                            Text("Manufacturer: ${lastTag.manufacturer}", style = MaterialTheme.typography.bodySmall)
                            Text("Type: ${lastTag.tagTypeDescription}", style = MaterialTheme.typography.bodySmall)
                            Text("Technologies: ${lastTag.technologies.joinToString(", ")}", style = MaterialTheme.typography.labelSmall)
                            Text(lastTag.rawDetails, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            if (lastTag.ndefRecords.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("NDEF Records:", style = MaterialTheme.typography.labelLarge)
                                lastTag.ndefRecords.forEach { rec ->
                                    Text("• $rec", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
            } else {
                item {
                    EmptyStatePanel(
                        icon = Icons.Filled.Nfc,
                        title = "No NFC Tags Scanned Yet",
                        tip = "Tap an NFC tag, sticker, or card against the NFC antenna area of your device."
                    )
                }
            }

            if (tagHistory.size > 1) {
                item { SectionHeader(title = "Session Tag History (${tagHistory.size})") }
                items(tagHistory.drop(1)) { tag ->
                    TacticalCard {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("${tag.tagTypeDescription} • ${tag.uidHex}", style = MaterialTheme.typography.labelLarge)
                            Text(tag.manufacturer, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            item {
                SectionHeader(
                    title = "External RFID Expansion Architecture",
                    subtitle = "Supported external multi-band readers via USB OTG / BLE"
                )
            }
            items(externalRfidSpecs, key = { it.name }) { spec ->
                TacticalCard {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(spec.name, style = MaterialTheme.typography.titleMedium)
                        Text("${spec.frequencyBand} • ${spec.interfaceType}", style = MaterialTheme.typography.labelSmall, color = palette.cyanAccent)
                        Text("Protocols: ${spec.supportedProtocols}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UwbScreen(
    uwbState: UwbDiagnosticState?,
    onRefreshUwb: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val palette = LocalSentinelPalette.current

    LaunchedEffect(Unit) { onRefreshUwb() }

    val uwbPermLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) {
        onRefreshUwb()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Ultra-Wideband (UWB) Diagnostics") },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (uwbState != null && uwbState.hardwareFeaturePresent && !uwbState.permissionGranted && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                item {
                    PermissionPromptCard(
                        title = "UWB Ranging Permission Required",
                        rationale = "Grant UWB_RANGING to inspect local FiRa UWB session availability.",
                        buttonText = "Grant UWB Permission",
                        testTag = "uwb_grant_button",
                        onGrantClick = { uwbPermLauncher.launch(Manifest.permission.UWB_RANGING) }
                    )
                }
            }

            item {
                TacticalCard(accentColor = if (uwbState?.uwbServiceAvailable == true) palette.low else palette.moderate) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("UWB Hardware & FiRa Subsystem", style = MaterialTheme.typography.titleMedium)
                            IconButton(onClick = onRefreshUwb, modifier = Modifier.minimumInteractiveComponentSize()) {
                                Icon(Icons.Filled.Refresh, contentDescription = "Refresh UWB Diagnostics")
                            }
                        }
                        if (uwbState == null) {
                            Text("Checking UWB capability...", style = MaterialTheme.typography.bodySmall)
                        } else {
                            Text("Hardware Present: ${uwbState.hardwareFeaturePresent}", style = MaterialTheme.typography.bodySmall)
                            Text("Service Active: ${uwbState.uwbServiceAvailable}", style = MaterialTheme.typography.bodySmall)
                            Text("Local UWB Address: ${uwbState.localAddressSummary}", style = MaterialTheme.typography.labelMedium, color = palette.cyanAccent)
                            Text("Channel / Profile: ${uwbState.channelSummary}", style = MaterialTheme.typography.bodySmall)
                            Text(uwbState.statusDetail, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }

            item {
                LimitationBanner(
                    title = "FiRa OOB Exchange Requirement",
                    message = uwbState?.limitationExplanation
                        ?: "Android's UWB stack requires FiRa out-of-band key exchange over BLE and cannot passively intercept proprietary AirTag or SmartTag UWB transmissions."
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExternalRfScreen(
    usbHostSupported: Boolean,
    attachedDevices: List<AttachedUsbHardware>,
    compatibilityList: List<ExternalRfHardwareProfile>,
    onRefreshUsb: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val palette = LocalSentinelPalette.current

    LaunchedEffect(Unit) { onRefreshUsb() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("External RF & SDR Hardware") },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                LimitationBanner(
                    title = "No Fabricated RF Measurements",
                    message = "SENTINEL NEVER simulates RF spectrum graphs or represents Bluetooth scanning as broadband RF detection. Attach a compatible USB-C / OTG SDR, tinySA, or RF detector to enable live spectrum telemetry."
                )
            }

            item {
                val matched = attachedDevices.count { it.matchedProfile != null }
                TacticalCard(accentColor = if (matched > 0) palette.low else palette.moderate) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = if (matched > 0) "$matched Compatible RF Hardware Unit(s) Connected" else "NO COMPATIBLE RF HARDWARE CONNECTED",
                            style = MaterialTheme.typography.titleMedium,
                            color = if (matched > 0) palette.low else palette.moderate
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "USB Host OTG Support: ${if (usbHostSupported) "Available" else "Not reported"} • Attached USB peripherals: ${attachedDevices.size}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = onRefreshUsb,
                            modifier = Modifier.minimumInteractiveComponentSize().testTag("rf_refresh_usb_button")
                        ) {
                            Icon(Icons.Filled.Usb, contentDescription = null)
                            Spacer(modifier = Modifier.padding(horizontal = 4.dp))
                            Text("Scan USB-C / OTG Bus")
                        }
                    }
                }
            }

            if (attachedDevices.isNotEmpty()) {
                item { SectionHeader(title = "Attached USB Devices (${attachedDevices.size})") }
                items(attachedDevices) { dev ->
                    TacticalCard {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(dev.productName, style = MaterialTheme.typography.titleMedium)
                            Text(
                                text = "VID:PID ${dev.vendorIdHex}:${dev.productIdHex} • ${dev.manufacturerName}",
                                style = MaterialTheme.typography.labelSmall,
                                color = palette.cyanAccent
                            )
                            Text(
                                text = dev.matchedProfile?.let { "Matched: ${it.name} (${it.frequencyRange})" }
                                    ?: "Unrecognized USB peripheral (not in RF compatibility database)",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }

            item {
                SectionHeader(
                    title = "Hardware Compatibility Database (${compatibilityList.size})",
                    subtitle = "Supported SDR, Spectrum Analyzer, and RFID adapters"
                )
            }

            items(compatibilityList, key = { it.id }) { hw ->
                TacticalCard {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(hw.name, style = MaterialTheme.typography.titleMedium)
                            Text(hw.category, style = MaterialTheme.typography.labelSmall, color = palette.cyanAccent)
                        }
                        Text(
                            text = "${hw.manufacturer} • ${hw.frequencyRange} • ${hw.transport}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(hw.capabilities, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HardwareDiagnosticsScreen(
    report: HardwareDiagnosticsReport,
    missingPermissions: Array<String>,
    onRefresh: () -> Unit,
    onExportJsonReport: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val palette = LocalSentinelPalette.current
    val permLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        onRefresh()
    }

    LaunchedEffect(Unit) { onRefresh() }

    val capabilities: List<CapabilityStatus> = listOf(
        report.bluetooth,
        report.ble,
        report.wifi,
        report.locationServices,
        report.nfc,
        report.uwb,
        report.magnetometer,
        report.cameraOptical,
        report.infraredCamera,
        report.usbHostExternalRf
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Hardware & API Diagnostics") },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = onRefresh, modifier = Modifier.minimumInteractiveComponentSize()) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Refresh Diagnostics")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                TacticalCard(accentColor = MaterialTheme.colorScheme.primary) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("${report.manufacturer} ${report.model}", style = MaterialTheme.typography.titleLarge)
                        Text(
                            text = "Android ${report.androidVersion} (API ${report.sdkInt})",
                            style = MaterialTheme.typography.labelMedium,
                            color = palette.cyanAccent
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = onExportJsonReport,
                            modifier = Modifier.minimumInteractiveComponentSize().testTag("diagnostics_export_button")
                        ) {
                            Text("Export Capability & Security Report (JSON)")
                        }
                    }
                }
            }

            item { SectionHeader(title = "Sensor, Radio & Hardware Matrix") }

            items(capabilities, key = { it.name }) { cap ->
                val statusLabel = when {
                    !cap.supported -> "UNSUPPORTED HARDWARE"
                    !cap.permissionGranted -> "PERMISSION NEEDED"
                    !cap.enabled && cap.name == report.ble.name && report.bluetooth.enabled -> "SCANNER UNAVAILABLE"
                    !cap.enabled -> "DISABLED"
                    else -> "OPERATIONAL"
                }
                val statusColor = when {
                    !cap.supported -> palette.critical
                    !cap.permissionGranted || !cap.enabled -> palette.moderate
                    else -> palette.low
                }

                TacticalCard {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(cap.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                            Text(statusLabel, style = MaterialTheme.typography.labelSmall, color = statusColor)
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(cap.detail, style = MaterialTheme.typography.bodySmall)
                        cap.limitationNote?.let {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            item { SectionHeader(title = "Runtime Permission Status") }

            item {
                TacticalCard {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        report.permissionMatrix.forEach { (perm, granted) ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(perm, style = MaterialTheme.typography.labelMedium)
                                Text(
                                    text = if (granted) "GRANTED" else "NOT GRANTED",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (granted) palette.low else palette.moderate
                                )
                            }
                        }
                        if (missingPermissions.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = { permLauncher.launch(missingPermissions) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .minimumInteractiveComponentSize()
                                    .testTag("diagnostics_grant_permissions_button")
                            ) {
                                Text("Grant Missing Scan Permissions (${missingPermissions.size})")
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedButton(
                                onClick = {
                                    val intent = Intent(
                                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                        Uri.fromParts("package", context.packageName, null)
                                    )
                                    runCatching { context.startActivity(intent) }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .minimumInteractiveComponentSize()
                            ) {
                                Text("Open App Permissions Settings")
                            }
                        }
                    }
                }
            }
        }
    }
}
