package com.example.core.data

import android.content.Context
import com.example.core.database.DeviceAppearanceEntity
import com.example.core.database.DeviceIntelEntryEntity
import com.example.core.database.EvidenceRecordEntity
import com.example.core.database.InvestigationCaseEntity
import com.example.core.database.LocalIntelSeed
import com.example.core.database.MagnetometerLogEntity
import com.example.core.database.ObservedDeviceEntity
import com.example.core.database.ScanSessionEntity
import com.example.core.database.SentinelDao
import com.example.core.database.SentinelDatabase
import com.example.core.intelligence.DeviceIntelligenceEngine
import com.example.core.intelligence.RawDeviceObservation
import com.example.core.model.InvestigationMode
import com.example.core.model.RiskLevel
import com.example.core.model.UserDeviceStatus
import com.example.core.security.HashingUtils
import com.example.core.security.KeystoreCryptoManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

class SentinelRepository(
    private val context: Context,
    private val dao: SentinelDao = SentinelDatabase.getInstance(context).sentinelDao()
) {
    val scanSessions: Flow<List<ScanSessionEntity>> = dao.observeScanSessions()
    val latestScanSession: Flow<ScanSessionEntity?> = dao.observeLatestScanSession()
    val observedDevices: Flow<List<ObservedDeviceEntity>> = dao.observeAllDevices()
    val allAppearances: Flow<List<DeviceAppearanceEntity>> = dao.observeAllAppearances()
    val intelEntries: Flow<List<DeviceIntelEntryEntity>> = dao.observeIntelEntries()
    val investigationCases: Flow<List<InvestigationCaseEntity>> = dao.observeCases()
    val allEvidence: Flow<List<EvidenceRecordEntity>> = dao.observeAllEvidence()
    val magnetometerLogs: Flow<List<MagnetometerLogEntity>> = dao.observeRecentMagnetometerLogs()

    fun observeDevice(fingerprintId: String): Flow<ObservedDeviceEntity?> =
        dao.observeDevice(fingerprintId)

    fun observeAppearancesForDevice(fingerprintId: String): Flow<List<DeviceAppearanceEntity>> =
        dao.observeAppearancesForDevice(fingerprintId)

    fun observeCase(caseId: String): Flow<InvestigationCaseEntity?> = dao.observeCase(caseId)

    fun observeEvidenceForCase(caseId: String): Flow<List<EvidenceRecordEntity>> =
        dao.observeEvidenceForCase(caseId)

    suspend fun ensureIntelSeeded() {
        if (dao.countIntelEntries() == 0) {
            dao.insertIntelEntries(LocalIntelSeed.initialEntries())
        }
    }

    suspend fun recordObservation(
        sessionId: String,
        obs: RawDeviceObservation
    ): ObservedDeviceEntity = withContext(Dispatchers.Default) {
        val fpId = DeviceIntelligenceEngine.computeFingerprintId(obs)
        val existing = dao.getDeviceSync(fpId)
        val priorDistinctSessions = if (existing == null) 0 else dao.countPriorDistinctSessions(fpId, sessionId)
        val distinctSessions = priorDistinctSessions + 1
        val distinctLocs = if (obs.latitude != null && obs.longitude != null) {
            val existingCoords = if (existing == null) {
                emptyList()
            } else {
                dao.getDistinctCoordinatesForDevice(fpId).map { it.latitude to it.longitude }
            }
            DeviceIntelligenceEngine.countDistinctLocationsFromCoords(existingCoords, obs.latitude, obs.longitude)
        } else {
            existing?.distinctLocationsCount ?: 0
        }
        val category = DeviceIntelligenceEngine.inferCategory(obs)
        val assessment = DeviceIntelligenceEngine.assessRiskWithCounts(
            existing = existing,
            obs = obs,
            distinctSessions = distinctSessions,
            distinctLocations = distinctLocs,
            category = category
        )

        val newCount = (existing?.observationCount ?: 0) + 1
        val mergedHistoryJson = DeviceIntelligenceEngine.mergeRssiHistory(existing?.rssiHistoryJson, obs.rssi)
        val minRssi = if (existing != null) minOf(existing.minRssi, obs.rssi) else obs.rssi
        val maxRssi = if (existing != null) maxOf(existing.maxRssi, obs.rssi) else obs.rssi
        val avgRssi = if (existing != null) {
            ((existing.avgRssi * existing.observationCount) + obs.rssi) / newCount
        } else {
            obs.rssi
        }
        val macRotationIncrement = if (existing != null && existing.rawAddress != obs.rawAddress && obs.rawAddress.isNotBlank()) 1 else 0

        val updated = ObservedDeviceEntity(
            fingerprintId = fpId,
            displayName = if (obs.displayName.isNotBlank() && obs.displayName != "Unnamed BLE Device") {
                obs.displayName
            } else {
                existing?.displayName ?: obs.displayName
            },
            rawAddress = obs.rawAddress.ifBlank { existing?.rawAddress ?: "Unavailable" },
            addressType = obs.addressType,
            sourceType = obs.source.name,
            manufacturerName = if (!obs.manufacturerName.startsWith("Unknown")) {
                obs.manufacturerName
            } else {
                existing?.manufacturerName ?: obs.manufacturerName
            },
            companyIdOrOui = obs.companyIdOrOui.ifBlank { existing?.companyIdOrOui ?: "" },
            serviceUuidsJson = JSONArray(obs.serviceUuids.distinct()).toString(),
            deviceCategory = category.name,
            firstSeenAt = existing?.firstSeenAt ?: obs.timestamp,
            lastSeenAt = obs.timestamp,
            observationCount = newCount,
            lastRssi = obs.rssi,
            minRssi = minRssi,
            maxRssi = maxRssi,
            avgRssi = avgRssi,
            rssiHistoryJson = mergedHistoryJson,
            macRotationCount = (existing?.macRotationCount ?: 0) + macRotationIncrement,
            distinctLocationsCount = distinctLocs,
            riskLevel = assessment.riskLevel.name,
            confidenceScore = assessment.confidenceScore,
            riskReasoning = assessment.reasoning,
            supportingObservationsJson = JSONArray(assessment.supportingObservations).toString(),
            uncertaintiesJson = JSONArray(assessment.uncertainties).toString(),
            recommendedNextStepsJson = JSONArray(assessment.recommendedNextSteps).toString(),
            userStatus = existing?.userStatus ?: UserDeviceStatus.UNREVIEWED.name
        )

        dao.upsertDevice(updated)
        dao.insertAppearance(
            DeviceAppearanceEntity(
                fingerprintId = fpId,
                sessionId = sessionId,
                timestamp = obs.timestamp,
                rssi = obs.rssi,
                rawAddressSnapshot = obs.rawAddress,
                manufacturerDataHex = obs.manufacturerDataHex,
                frequencyMhz = obs.frequencyMhz,
                extraMetadata = obs.extraIndicators.joinToString("; "),
                latitude = obs.latitude,
                longitude = obs.longitude,
                locationLabel = obs.locationLabel
            )
        )
        updated
    }

    suspend fun saveScanSession(session: ScanSessionEntity) {
        dao.insertScanSession(session)
    }

    suspend fun updateDeviceUserStatus(fingerprintId: String, newStatus: UserDeviceStatus) {
        val current = dao.getDeviceSync(fingerprintId) ?: return
        val newRisk = when (newStatus) {
            UserDeviceStatus.TRUSTED -> RiskLevel.LOW.name
            UserDeviceStatus.DISMISSED -> RiskLevel.LOW.name
            UserDeviceStatus.INVESTIGATING -> if (current.riskLevel == RiskLevel.LOW.name) RiskLevel.MODERATE.name else current.riskLevel
            UserDeviceStatus.UNREVIEWED -> current.riskLevel
        }
        val reason = when (newStatus) {
            UserDeviceStatus.TRUSTED -> "Marked Trusted by user."
            UserDeviceStatus.DISMISSED -> "Alert dismissed by user."
            UserDeviceStatus.INVESTIGATING -> "Flagged for active investigation by user."
            UserDeviceStatus.UNREVIEWED -> current.riskReasoning
        }
        dao.updateDeviceClassification(fingerprintId, newStatus.name, newRisk, reason)
    }

    suspend fun createCase(
        title: String,
        investigationType: InvestigationMode,
        locationNote: String,
        plainNotes: String,
        initialChecklistJson: String = "{}"
    ): InvestigationCaseEntity = withContext(Dispatchers.Default) {
        val now = System.currentTimeMillis()
        val encrypted = KeystoreCryptoManager.encrypt(plainNotes)
        val newCase = InvestigationCaseEntity(
            id = "CASE-${UUID.randomUUID().toString().take(8).uppercase()}",
            title = title.trim().ifBlank { "${investigationType.title} Case" },
            investigationType = investigationType.name,
            createdAt = now,
            updatedAt = now,
            locationNote = locationNote.trim(),
            status = "ACTIVE",
            encryptedNotesCiphertext = encrypted.ciphertextBase64,
            notesIv = encrypted.ivBase64,
            checklistStateJson = initialChecklistJson.ifBlank { "{}" }
        )
        dao.upsertCase(newCase)
        newCase
    }

    suspend fun updateCaseNotesAndStatus(
        caseId: String,
        plainNotes: String? = null,
        status: String? = null,
        checklistStateJson: String? = null
    ) = withContext(Dispatchers.Default) {
        val existing = dao.getCaseSync(caseId) ?: return@withContext
        val encrypted = if (plainNotes != null) {
            KeystoreCryptoManager.encrypt(plainNotes)
        } else {
            null
        }
        dao.upsertCase(
            existing.copy(
                updatedAt = System.currentTimeMillis(),
                status = status ?: existing.status,
                encryptedNotesCiphertext = encrypted?.ciphertextBase64 ?: existing.encryptedNotesCiphertext,
                notesIv = encrypted?.ivBase64 ?: existing.notesIv,
                checklistStateJson = checklistStateJson ?: existing.checklistStateJson
            )
        )
    }

    fun decryptNotes(ciphertext: String, iv: String): String? {
        return KeystoreCryptoManager.decrypt(ciphertext, iv)
    }

    suspend fun deleteCaseAndEvidence(caseId: String) {
        dao.deleteEvidenceForCase(caseId)
        dao.deleteCase(caseId)
    }

    suspend fun addEvidenceRecord(
        caseId: String,
        detectionMethod: String,
        deviceFingerprintId: String?,
        deviceSummary: String,
        supportingObservations: String,
        plainNotes: String,
        photoUri: String?,
        latitude: Double?,
        longitude: Double?,
        riskLevelSnapshot: String
    ): EvidenceRecordEntity = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val encrypted = KeystoreCryptoManager.encrypt(plainNotes)
        val photoSha = photoUri?.let { uriStr ->
            runCatching {
                val parsed = android.net.Uri.parse(uriStr)
                context.contentResolver.openInputStream(parsed)?.use { stream ->
                    HashingUtils.sha256Hex(stream)
                }
            }.getOrNull()
        }
        val audit = JSONArray().apply {
            put(JSONObject().apply {
                put("event", "EVIDENCE_CREATED")
                put("timestamp", now)
                put("photoSha256", photoSha ?: "none")
            })
        }.toString()

        val record = EvidenceRecordEntity(
            id = "EVD-${UUID.randomUUID().toString().take(8).uppercase()}",
            caseId = caseId,
            createdAt = now,
            detectionMethod = detectionMethod,
            deviceFingerprintId = deviceFingerprintId,
            deviceSummary = deviceSummary,
            supportingObservations = supportingObservations,
            encryptedNotesCiphertext = encrypted.ciphertextBase64,
            notesIv = encrypted.ivBase64,
            photoUri = photoUri,
            photoSha256 = photoSha,
            editedAnnotationNote = null,
            latitude = latitude,
            longitude = longitude,
            riskLevelSnapshot = riskLevelSnapshot,
            auditTrailJson = audit
        )
        dao.upsertEvidence(record)
        record
    }

    suspend fun updateEvidenceAnnotation(record: EvidenceRecordEntity, newAnnotation: String) =
        withContext(Dispatchers.Default) {
            val now = System.currentTimeMillis()
            val auditArr = runCatching { JSONArray(record.auditTrailJson) }.getOrElse { JSONArray() }
            auditArr.put(JSONObject().apply {
                put("event", "ANNOTATION_ADDED_ORIGINAL_PRESERVED")
                put("timestamp", now)
            })
            dao.upsertEvidence(
                record.copy(
                    editedAnnotationNote = newAnnotation,
                    auditTrailJson = auditArr.toString()
                )
            )
        }

    suspend fun deleteEvidence(evidenceId: String) {
        dao.deleteEvidence(evidenceId)
    }

    suspend fun logMagnetometerSample(
        sessionId: String?,
        x: Float,
        y: Float,
        z: Float,
        magnitude: Float,
        baseline: Float,
        delta: Float,
        isAnomaly: Boolean
    ) {
        dao.insertMagnetometerLog(
            MagnetometerLogEntity(
                sessionId = sessionId,
                timestamp = System.currentTimeMillis(),
                xUt = x,
                yUt = y,
                zUt = z,
                magnitudeUt = magnitude,
                baselineUt = baseline,
                deltaUt = delta,
                isRelativeAnomaly = isAnomaly
            )
        )
    }

    suspend fun getAllDevicesSync(): List<ObservedDeviceEntity> = dao.getAllDevicesSync()
    suspend fun getAllAppearancesSync(): List<DeviceAppearanceEntity> = dao.getAllAppearancesSync()
    suspend fun getEvidenceForCaseSync(caseId: String): List<EvidenceRecordEntity> = dao.getEvidenceForCaseSync(caseId)

    suspend fun wipeAllUserData() = withContext(Dispatchers.IO) {
        dao.clearScanSessions()
        dao.clearObservedDevices()
        dao.clearDeviceAppearances()
        dao.clearEvidence()
        dao.clearCases()
        dao.clearMagnetometerLogs()
        // Delete local evidence photos and exported report files
        File(context.filesDir, "evidence_photos").deleteRecursively()
        File(context.filesDir, "reports").deleteRecursively()
        File(context.cacheDir, "share").deleteRecursively()
        Unit
    }
}
