package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.sensors.MagnetometerSample
import com.example.ui.components.LimitationBanner
import com.example.ui.components.TacticalCard
import com.example.ui.components.TelemetryLineChart
import com.example.ui.theme.LocalSentinelPalette
import kotlin.math.abs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MagnetometerScreen(
    isAvailable: Boolean,
    sensorMetadata: String,
    isRunning: Boolean,
    currentSample: MagnetometerSample?,
    baselineUt: Float?,
    history: List<Float>,
    sensitivityUt: Float,
    anomalyCount: Int,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onCalibrate: () -> Unit,
    onSensitivityChange: (Float) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val palette = LocalSentinelPalette.current
    var localSensitivity by remember(sensitivityUt) { mutableFloatStateOf(sensitivityUt) }

    DisposableEffect(Unit) {
        onDispose { onStop() }
    }

    val delta = if (currentSample != null && baselineUt != null) {
        abs(currentSample.magnitudeUt - baselineUt)
    } else {
        0f
    }
    val isSpike = currentSample != null && baselineUt != null && delta >= localSensitivity

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Magnetometer Field Analyzer") },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                LimitationBanner(
                    title = "Ordinary Magnetic Interference Notice",
                    message = "Magnetic anomalies commonly result from speakers, steel car frames, electrical wiring, door latches, laptops, and ordinary magnets. Magnetometer spikes NEVER automatically classify a device as a tracker."
                )
            }

            if (!isAvailable) {
                item {
                    LimitationBanner(
                        title = "Magnetometer Unavailable",
                        message = "This device does not report a hardware TYPE_MAGNETIC_FIELD sensor.",
                        tint = palette.high
                    )
                }
            } else {
                item {
                    TacticalCard(
                        accentColor = if (isSpike) palette.high else MaterialTheme.colorScheme.primary
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = currentSample?.let { "${"%.1f".format(it.magnitudeUt)} µT" } ?: "-- µT",
                                style = MaterialTheme.typography.displaySmall,
                                color = if (isSpike) palette.high else palette.cyanAccent
                            )
                            Text(
                                text = if (isSpike) {
                                    "RELATIVE ANOMALY: Δ ${"%.1f".format(delta)} µT above baseline"
                                } else {
                                    "Delta from baseline: ${"%.1f".format(delta)} µT • Anomalies logged: $anomalyCount"
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (isSpike) palette.high else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            currentSample?.let { s ->
                                Text(
                                    text = "X: ${"%.1f".format(s.xUt)} µT   Y: ${"%.1f".format(s.yUt)} µT   Z: ${"%.1f".format(s.zUt)} µT",
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = if (isRunning) onStop else onStart,
                                    modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("mag_toggle_button")
                                ) {
                                    Icon(if (isRunning) Icons.Filled.Stop else Icons.Filled.PlayArrow, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(if (isRunning) "Stop" else "Start Sweep")
                                }
                                OutlinedButton(
                                    onClick = onCalibrate,
                                    enabled = isRunning,
                                    modifier = Modifier.minimumInteractiveComponentSize().testTag("mag_calibrate_button")
                                ) {
                                    Icon(Icons.Filled.Refresh, contentDescription = null)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Calibrate")
                                }
                            }
                        }
                    }
                }

                item {
                    TacticalCard {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("Real-Time Magnetic Flux Waveform", style = MaterialTheme.typography.titleMedium)
                            Spacer(modifier = Modifier.height(6.dp))
                            TelemetryLineChart(
                                values = history,
                                baseline = baselineUt,
                                lineColor = if (isSpike) palette.high else palette.low,
                                unitLabel = "µT",
                                emptyMessage = "Tap Start Sweep to stream live 3-axis magnetometer readings."
                            )
                        }
                    }
                }

                item {
                    TacticalCard {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "Anomaly Threshold Sensitivity: ±${localSensitivity.toInt()} µT",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Slider(
                                value = localSensitivity,
                                onValueChange = { localSensitivity = it },
                                onValueChangeFinished = { onSensitivityChange(localSensitivity) },
                                valueRange = 10f..100f
                            )
                            Text(
                                text = "Guided Physical Sweep: Calibrate in open air 15cm away from the surface, then sweep slowly at 2–5cm over non-magnetic plastic bumpers, wheel-arch liners, furniture undersides, or bags.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = sensorMetadata,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}
