package com.example.services

import android.content.Context
import androidx.work.Configuration
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.core.database.SentinelDatabase
import java.util.concurrent.TimeUnit

/**
 * Performs offline local database maintenance (prunes raw high-frequency magnetometer logs
 * older than 14 days while preserving all devices, scan sessions, cases, and forensic evidence).
 */
class DatabaseMaintenanceWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        return try {
            val dao = SentinelDatabase.getInstance(applicationContext).sentinelDao()
            val fourteenDaysAgo = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(14)
            dao.pruneOldMagnetometerLogs(fourteenDaysAgo)
            Result.success()
        } catch (_: Throwable) {
            Result.retry()
        }
    }

    companion object {
        private const val WORK_NAME = "sentinel_db_maintenance"

        fun schedule(context: Context) {
            val appCtx = context.applicationContext
            runCatching {
                if (!WorkManager.isInitialized()) {
                    WorkManager.initialize(appCtx, Configuration.Builder().build())
                }
                val request = PeriodicWorkRequestBuilder<DatabaseMaintenanceWorker>(1, TimeUnit.DAYS)
                    .build()
                WorkManager.getInstance(appCtx).enqueueUniquePeriodicWork(
                    WORK_NAME,
                    ExistingPeriodicWorkPolicy.KEEP,
                    request
                )
            }
        }
    }
}
