package com.example.core.security

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

data class EncryptedPayload(
    val ciphertextBase64: String,
    val ivBase64: String
)

class DecryptionException(message: String, cause: Throwable? = null) : Exception(message, cause)

/**
 * Provides AES-256-GCM local encryption backed by AndroidKeyStore.
 * In local JVM unit test environments without AndroidKeyStore provider, falls back
 * transparently to an ephemeral AES-256 key so cryptographic pipelines remain testable.
 */
object KeystoreCryptoManager {
    private const val ANDROID_KEYSTORE = "AndroidKeyStore"
    private const val KEY_ALIAS = "sentinel_local_vault_aes256"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    private const val TAG_LENGTH_BITS = 128

    @Volatile
    private var testFallbackKey: SecretKey? = null

    fun isHardwareKeystoreAvailable(): Boolean {
        return try {
            KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
            true
        } catch (_: Throwable) {
            false
        }
    }

    private fun getOrCreateKey(): SecretKey {
        synchronized(this) {
            return try {
                val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE)
                keyStore.load(null)
                (keyStore.getKey(KEY_ALIAS, null) as? SecretKey)
                    ?: generateAndStoreKey()
            } catch (_: Throwable) {
                testFallbackKey ?: KeyGenerator.getInstance("AES").apply {
                    init(256)
                }.generateKey().also { testFallbackKey = it }
            }
        }
    }

    private fun generateAndStoreKey(): SecretKey {
        val keyGenerator = KeyGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_AES,
            ANDROID_KEYSTORE
        )
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        keyGenerator.init(spec)
        return keyGenerator.generateKey()
    }

    fun encrypt(plaintext: String): EncryptedPayload {
        if (plaintext.isEmpty()) return EncryptedPayload("", "")
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val iv = cipher.iv
        val encrypted = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))
        return EncryptedPayload(
            ciphertextBase64 = Base64.encodeToString(encrypted, Base64.NO_WRAP),
            ivBase64 = Base64.encodeToString(iv, Base64.NO_WRAP)
        )
    }

    fun decryptResult(ciphertextBase64: String, ivBase64: String): Result<String> {
        if (ciphertextBase64.isBlank() || ivBase64.isBlank()) return Result.success("")
        return try {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            val iv = Base64.decode(ivBase64, Base64.NO_WRAP)
            val spec = GCMParameterSpec(TAG_LENGTH_BITS, iv)
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), spec)
            val decoded = Base64.decode(ciphertextBase64, Base64.NO_WRAP)
            Result.success(String(cipher.doFinal(decoded), Charsets.UTF_8))
        } catch (t: Throwable) {
            Result.failure(DecryptionException("Encrypted payload could not be decrypted on this keystore state.", t))
        }
    }

    /**
     * Returns decrypted UTF-8 plaintext (or "" when blank), or null if decryption failed
     * so callers can handle keystore errors explicitly without confusing error text for notes.
     */
    fun decrypt(ciphertextBase64: String, ivBase64: String): String? =
        decryptResult(ciphertextBase64, ivBase64).getOrNull()

    /**
     * Used only for synthetic Robolectric tests if an explicit deterministic key is needed.
     */
    internal fun createSoftwareKeyFromBytes(bytes: ByteArray): SecretKey {
        return SecretKeySpec(bytes.copyOf(32), "AES")
    }
}
