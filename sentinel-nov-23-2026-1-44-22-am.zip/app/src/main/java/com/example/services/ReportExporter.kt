package com.example.services

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.example.core.database.EvidenceRecordEntity
import com.example.core.database.InvestigationCaseEntity
import com.example.core.database.ObservedDeviceEntity
import com.example.core.database.ScanSessionEntity
import com.example.core.model.HardwareDiagnosticsReport
import com.example.core.security.HashingUtils
import com.example.core.security.KeystoreCryptoManager
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ExportedArtifact(
    val file: File,
    val mimeType: String,
    val sha256: String
)

class ReportExporter(private val context: Context) {

    private val dateFmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss z", Locale.US)

    private fun reportsDir(): File {
        return File(context.filesDir, "reports").apply { mkdirs() }
    }

    fun exportJsonReport(
        reportId: String,
        title: String,
        diagnostics: HardwareDiagnosticsReport,
        sessions: List<ScanSessionEntity>,
        devices: List<ObservedDeviceEntity>,
        cases: List<InvestigationCaseEntity>,
        evidence: List<EvidenceRecordEntity>
    ): ExportedArtifact {
        val root = JSONObject().apply {
            put("reportId", reportId)
            put("title", title)
            put("generatedAt", dateFmt.format(Date()))
            put("platform", JSONObject().apply {
                put("device", "${diagnostics.manufacturer} ${diagnostics.model}")
                put("androidVersion", diagnostics.androidVersion)
                put("sdkInt", diagnostics.sdkInt)
                put("bleSupported", diagnostics.ble.supported)
                put("wifiSupported", diagnostics.wifi.supported)
                put("nfcSupported", diagnostics.nfc.supported)
                put("uwbSupported", diagnostics.uwb.supported)
                put("magnetometerSupported", diagnostics.magnetometer.supported)
                put("usbHostSupported", diagnostics.usbHostExternalRf.supported)
            })
            put("technicalLimitations", "Android devices cannot universally detect passive GPS receivers, cellular uplinks, offline SD-card hidden cameras, or non-NFC RFID bands without external hardware.")
            put("scanSessions", JSONArray().apply {
                sessions.forEach { s ->
                    put(JSONObject().apply {
                        put("id", s.id)
                        put("mode", s.modeId)
                        put("status", s.status)
                        put("startedAt", dateFmt.format(Date(s.startedAt)))
                        put("durationMs", s.durationMs)
                        put("totalObserved", s.totalObservedCount)
                        put("suspiciousCount", s.suspiciousCount)
                        put("locationLabel", s.locationLabel ?: "Not collected")
                    })
                }
            })
            put("observedDevices", JSONArray().apply {
                devices.forEach { d ->
                    put(JSONObject().apply {
                        put("fingerprintId", d.fingerprintId)
                        put("displayName", d.displayName)
                        put("source", d.sourceType)
                        put("manufacturer", d.manufacturerName)
                        put("category", d.deviceCategory)
                        put("riskLevel", d.riskLevel)
                        put("confidenceScore", d.confidenceScore)
                        put("userStatus", d.userStatus)
                        put("observationCount", d.observationCount)
                        put("lastRssi", d.lastRssi)
                        put("reasoning", d.riskReasoning)
                    })
                }
            })
            put("cases", JSONArray().apply {
                cases.forEach { c ->
                    put(JSONObject().apply {
                        put("id", c.id)
                        put("title", c.title)
                        put("type", c.investigationType)
                        put("status", c.status)
                        put("locationNote", c.locationNote)
                        put("decryptedNotes", KeystoreCryptoManager.decrypt(c.encryptedNotesCiphertext, c.notesIv) ?: "[Decryption failed on current keystore state]")
                    })
                }
            })
            put("evidenceRecords", JSONArray().apply {
                evidence.forEach { e ->
                    put(JSONObject().apply {
                        put("id", e.id)
                        put("caseId", e.caseId)
                        put("createdAt", dateFmt.format(Date(e.createdAt)))
                        put("method", e.detectionMethod)
                        put("deviceSummary", e.deviceSummary)
                        put("observations", e.supportingObservations)
                        put("decryptedNotes", KeystoreCryptoManager.decrypt(e.encryptedNotesCiphertext, e.notesIv) ?: "[Decryption failed on current keystore state]")
                        put("photoSha256", e.photoSha256 ?: "None")
                        put("annotationNote", e.editedAnnotationNote ?: "")
                        put("riskSnapshot", e.riskLevelSnapshot)
                    })
                }
            })
        }

        val payload = root.toString(2)
        val sha = HashingUtils.sha256Hex(payload)
        root.put("integritySha256BeforeManifest", sha)

        val file = File(reportsDir(), "${reportId}.json")
        val finalText = root.toString(2)
        file.writeText(finalText, Charsets.UTF_8)
        return ExportedArtifact(file, "application/json", HashingUtils.sha256Hex(file.readBytes()))
    }

    fun exportCsvReport(
        reportId: String,
        devices: List<ObservedDeviceEntity>
    ): ExportedArtifact {
        val sb = StringBuilder()
        sb.appendLine("fingerprint_id,display_name,source,manufacturer,category,risk_level,confidence,user_status,observations,last_rssi,first_seen,last_seen,reasoning")
        devices.forEach { d ->
            val cols = listOf(
                d.fingerprintId,
                d.displayName,
                d.sourceType,
                d.manufacturerName,
                d.deviceCategory,
                d.riskLevel,
                d.confidenceScore.toString(),
                d.userStatus,
                d.observationCount.toString(),
                d.lastRssi.toString(),
                dateFmt.format(Date(d.firstSeenAt)),
                dateFmt.format(Date(d.lastSeenAt)),
                d.riskReasoning
            ).joinToString(",") { escapeCsv(it) }
            sb.appendLine(cols)
        }
        val content = sb.toString()
        val file = File(reportsDir(), "${reportId}.csv")
        file.writeText(content, Charsets.UTF_8)
        return ExportedArtifact(file, "text/csv", HashingUtils.sha256Hex(content))
    }

    fun exportPdfReport(
        reportId: String,
        title: String,
        diagnostics: HardwareDiagnosticsReport,
        sessions: List<ScanSessionEntity>,
        devices: List<ObservedDeviceEntity>,
        cases: List<InvestigationCaseEntity>,
        evidence: List<EvidenceRecordEntity>
    ): ExportedArtifact {
        val file = File(reportsDir(), "${reportId}.pdf")
        val nativePdfSuccess = runCatching {
            val doc = PdfDocument()
            try {
                val pageWidth = 595
                val pageHeight = 842
                val margin = 40f

                val titlePaint = Paint().apply {
                    color = Color.rgb(10, 35, 66)
                    textSize = 18f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                }
                val headingPaint = Paint().apply {
                    color = Color.rgb(0, 102, 128)
                    textSize = 13f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                }
                val bodyPaint = Paint().apply {
                    color = Color.rgb(30, 35, 42)
                    textSize = 10f
                }
                val monoPaint = Paint().apply {
                    color = Color.rgb(60, 70, 80)
                    textSize = 8.5f
                    typeface = Typeface.MONOSPACE
                }

                var pageNumber = 1
                var page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
                var canvas = page.canvas
                var y = 48f

                fun newPageIfNeeded(requiredHeight: Float = 28f) {
                    if (y + requiredHeight > pageHeight - 44f) {
                        doc.finishPage(page)
                        pageNumber++
                        page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
                        canvas = page.canvas
                        y = 48f
                    }
                }

                fun drawWrapped(text: String, paint: Paint, indent: Float = 0f, lineHeight: Float = 14f) {
                    val maxWidth = pageWidth - (margin * 2) - indent
                    val words = text.split(" ")
                    var line = ""
                    for (w in words) {
                        val test = if (line.isEmpty()) w else "$line $w"
                        if (paint.measureText(test) > maxWidth) {
                            newPageIfNeeded(lineHeight)
                            canvas.drawText(line, margin + indent, y, paint)
                            y += lineHeight
                            line = w
                        } else {
                            line = test
                        }
                    }
                    if (line.isNotEmpty()) {
                        newPageIfNeeded(lineHeight)
                        canvas.drawText(line, margin + indent, y, paint)
                        y += lineHeight
                    }
                }

                canvas.drawText("SENTINEL SECURITY INVESTIGATION REPORT", margin, y, titlePaint)
                y += 20f
                drawWrapped("Report ID: $reportId   |   Title: $title", bodyPaint)
                drawWrapped("Generated: ${dateFmt.format(Date())}", bodyPaint)
                drawWrapped("Device: ${diagnostics.manufacturer} ${diagnostics.model} (Android ${diagnostics.androidVersion}, API ${diagnostics.sdkInt})", bodyPaint)
                y += 8f

                canvas.drawText("1. Hardware Compatibility & Technical Limitations", margin, y, headingPaint)
                y += 16f
                drawWrapped("BLE: ${diagnostics.ble.detail} | Wi-Fi: ${diagnostics.wifi.detail} | NFC: ${diagnostics.nfc.detail} | UWB: ${diagnostics.uwb.detail} | Magnetometer: ${diagnostics.magnetometer.detail} | USB Host: ${diagnostics.usbHostExternalRf.detail}", bodyPaint)
                drawWrapped("Notice: Ordinary Android phones cannot universally detect passive GPS receivers, cellular transmitters, offline SD-card hidden cameras, or non-NFC RFID bands without external hardware.", bodyPaint)
                y += 8f

                newPageIfNeeded(30f)
                canvas.drawText("2. Scan Sessions (${sessions.size})", margin, y, headingPaint)
                y += 16f
                if (sessions.isEmpty()) {
                    drawWrapped("No scan sessions recorded.", bodyPaint)
                } else {
                    sessions.take(15).forEach { s ->
                        drawWrapped("${s.id} • Mode: ${s.modeId.uppercase()} • Status: ${s.status} • Observed: ${s.totalObservedCount} • Flagged: ${s.suspiciousCount} • ${dateFmt.format(Date(s.startedAt))}", monoPaint)
                    }
                }
                y += 8f

                newPageIfNeeded(30f)
                canvas.drawText("3. Observed Devices & Risk Assessments (${devices.size})", margin, y, headingPaint)
                y += 16f
                if (devices.isEmpty()) {
                    drawWrapped("No devices recorded.", bodyPaint)
                } else {
                    devices.take(40).forEach { d ->
                        newPageIfNeeded(44f)
                        drawWrapped("[${d.riskLevel} | ${d.confidenceScore}%] ${d.displayName} (${d.sourceType}) — ${d.manufacturerName}", bodyPaint)
                        drawWrapped("FP: ${d.fingerprintId} | Status: ${d.userStatus} | Obs: ${d.observationCount} | RSSI: ${d.lastRssi} dBm", monoPaint, indent = 8f)
                        drawWrapped("Reasoning: ${d.riskReasoning}", bodyPaint, indent = 8f)
                        y += 4f
                    }
                }
                y += 8f

                newPageIfNeeded(30f)
                canvas.drawText("4. Investigation Cases (${cases.size}) & Evidence (${evidence.size})", margin, y, headingPaint)
                y += 16f
                cases.forEach { c ->
                    drawWrapped("Case ${c.id}: ${c.title} [${c.status}] (${c.investigationType}) — ${c.locationNote}", bodyPaint)
                    val notes = KeystoreCryptoManager.decrypt(c.encryptedNotesCiphertext, c.notesIv)
                        ?: "[Decryption failed on current keystore state]"
                    if (notes.isNotBlank()) drawWrapped("Notes: $notes", bodyPaint, indent = 8f)
                }
                evidence.forEach { e ->
                    newPageIfNeeded(40f)
                    drawWrapped("Evidence ${e.id} (Case ${e.caseId}): ${e.deviceSummary} [${e.riskLevelSnapshot}]", bodyPaint)
                    drawWrapped("Method: ${e.detectionMethod} | Photo SHA-256: ${e.photoSha256 ?: "None"}", monoPaint, indent = 8f)
                    val eNotes = KeystoreCryptoManager.decrypt(e.encryptedNotesCiphertext, e.notesIv)
                        ?: "[Decryption failed on current keystore state]"
                    if (eNotes.isNotBlank()) drawWrapped("Original Notes: $eNotes", bodyPaint, indent = 8f)
                    if (!e.editedAnnotationNote.isNullOrBlank()) drawWrapped("Annotation: ${e.editedAnnotationNote}", bodyPaint, indent = 8f)
                }

                doc.finishPage(page)
                FileOutputStream(file).use { doc.writeTo(it) }
            } finally {
                runCatching { doc.close() }
            }
        }.isSuccess

        if (!nativePdfSuccess) {
            writeMinimalValidPdf(
                file = file,
                lines = buildList {
                    add("SENTINEL SECURITY INVESTIGATION REPORT ($reportId)")
                    add("Title: $title | Generated: ${dateFmt.format(Date())}")
                    add("Device: ${diagnostics.manufacturer} ${diagnostics.model} Android ${diagnostics.androidVersion}")
                    add("Sessions: ${sessions.size} | Devices: ${devices.size} | Cases: ${cases.size} | Evidence: ${evidence.size}")
                    devices.take(20).forEach { add("[${it.riskLevel}] ${it.displayName} (${it.sourceType}) - ${it.riskReasoning}") }
                    cases.forEach { add("Case ${it.id}: ${it.title} (${it.status})") }
                }
            )
        }

        val sha = HashingUtils.sha256Hex(file.readBytes())
        return ExportedArtifact(file, "application/pdf", sha)
    }

    internal fun writeMinimalValidPdf(file: File, lines: List<String>) {
        val escapedStream = buildString {
            append("BT\n/F1 10 Tf\n40 780 Td\n14 TL\n")
            lines.take(45).forEachIndexed { idx, raw ->
                val clean = raw.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
                    .filter { it.code in 32..126 }
                if (idx == 0) append("($clean) Tj\n") else append("T* ($clean) Tj\n")
            }
            append("ET\n")
        }
        val streamBytes = escapedStream.toByteArray(Charsets.US_ASCII)
        val objects = listOf(
            "1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n",
            "2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n",
            "3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>\nendobj\n",
            "4 0 obj\n<< /Length ${streamBytes.size} >>\nstream\n$escapedStream\nendstream\nendobj\n",
            "5 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n"
        )
        val header = "%PDF-1.4\n"
        val bodyBuilder = StringBuilder(header)
        var currentOffset = header.toByteArray(Charsets.US_ASCII).size
        val offsets = mutableListOf<Int>()
        for (obj in objects) {
            offsets.add(currentOffset)
            bodyBuilder.append(obj)
            currentOffset += obj.toByteArray(Charsets.US_ASCII).size
        }
        val xrefOffset = currentOffset
        val xrefBuilder = StringBuilder().apply {
            append("xref\n")
            append("0 ${objects.size + 1}\n")
            append("0000000000 65535 f \n")
            offsets.forEach { offset ->
                append("%010d 00000 n \n".format(java.util.Locale.US, offset))
            }
            append("trailer\n")
            append("<< /Size ${objects.size + 1} /Root 1 0 R >>\n")
            append("startxref\n")
            append("$xrefOffset\n")
            append("%%EOF\n")
        }
        file.writeBytes((bodyBuilder.toString() + xrefBuilder.toString()).toByteArray(Charsets.US_ASCII))
    }

    fun buildShareIntent(artifact: ExportedArtifact): Intent {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            artifact.file
        )
        return Intent(Intent.ACTION_SEND).apply {
            type = artifact.mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "SENTINEL Report (${artifact.file.name})")
            putExtra(Intent.EXTRA_TEXT, "SENTINEL Security Report\nSHA-256: ${artifact.sha256}")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    private fun escapeCsv(value: String): String {
        val escaped = value.replace("\"", "\"\"")
        return "\"$escaped\""
    }
}
