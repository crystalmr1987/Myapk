package com.example.sensors

import android.content.Context
import android.content.pm.PackageManager
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import kotlinx.coroutines.flow.Flow

data class ExternalRfHardwareProfile(
    val id: String,
    val vendorId: Int,
    val productId: Int,
    val name: String,
    val manufacturer: String,
    val category: String, // SDR, SPECTRUM_ANALYZER, RFID_READER, RF_DETECTOR, SERIAL_BRIDGE
    val frequencyRange: String,
    val transport: String,
    val capabilities: String
)

data class AttachedUsbHardware(
    val deviceName: String,
    val vendorIdHex: String,
    val productIdHex: String,
    val productName: String,
    val manufacturerName: String,
    val hasUsbPermission: Boolean,
    val matchedProfile: ExternalRfHardwareProfile?
)

data class RfSpectrumFrame(
    val timestamp: Long,
    val startFreqMhz: Double,
    val endFreqMhz: Double,
    val binsDbm: List<Float>,
    val peakFreqMhz: Double,
    val peakDbm: Float
)

/**
 * Modular hardware abstraction layer allowing future USB-C/OTG, SDR, and BLE RF detectors
 * to stream calibrated frequency measurements without modifying UI or intelligence layers.
 */
interface ExternalRfDriver {
    val profile: ExternalRfHardwareProfile
    fun streamSpectrum(startFreqMhz: Double, endFreqMhz: Double): Flow<RfSpectrumFrame>
    fun disconnect()
}

class ExternalRfHardwareManager(private val context: Context) {

    val compatibilityDatabase: List<ExternalRfHardwareProfile> = listOf(
        ExternalRfHardwareProfile(
            id = "hw_rtlsdr",
            vendorId = 0x0BDA,
            productId = 0x2838,
            name = "RTL-SDR (RTL2832U)",
            manufacturer = "Realtek / RTL-SDR",
            category = "SDR",
            frequencyRange = "24 MHz – 1,766 MHz",
            transport = "USB-C / USB OTG",
            capabilities = "Wideband RF spectrum sweep (sub-GHz ISM 315/433/868/915 MHz & VHF/UHF)"
        ),
        ExternalRfHardwareProfile(
            id = "hw_rtlsdr_v3",
            vendorId = 0x0BDA,
            productId = 0x2832,
            name = "RTL2832U Generic SDR",
            manufacturer = "Realtek",
            category = "SDR",
            frequencyRange = "24 MHz – 1,766 MHz",
            transport = "USB-C / USB OTG",
            capabilities = "Wideband RF spectrum monitoring"
        ),
        ExternalRfHardwareProfile(
            id = "hw_hackrf",
            vendorId = 0x1D50,
            productId = 0x6089,
            name = "HackRF One",
            manufacturer = "Great Scott Gadgets",
            category = "SDR",
            frequencyRange = "1 MHz – 6,000 MHz",
            transport = "USB-C / USB OTG",
            capabilities = "Full-band RF spectrum sweep covering cellular bands, 2.4 GHz, and 5.8 GHz video"
        ),
        ExternalRfHardwareProfile(
            id = "hw_airspy",
            vendorId = 0x1D50,
            productId = 0x60A1,
            name = "Airspy R2 / Mini",
            manufacturer = "Airspy",
            category = "SDR",
            frequencyRange = "24 MHz – 1,800 MHz",
            transport = "USB-C / USB OTG",
            capabilities = "High-dynamic-range spectrum analysis"
        ),
        ExternalRfHardwareProfile(
            id = "hw_tinysa",
            vendorId = 0x0483,
            productId = 0x5740,
            name = "tinySA / tinySA Ultra",
            manufacturer = "STMicro / tinySA",
            category = "SPECTRUM_ANALYZER",
            frequencyRange = "100 kHz – 5.3 GHz (Ultra)",
            transport = "USB-C CDC Serial",
            capabilities = "Calibrated dBm power & frequency marker sweeps for RF bug/cellular bursts"
        ),
        ExternalRfHardwareProfile(
            id = "hw_proxmark3",
            vendorId = 0x9AC4,
            productId = 0x4B8F,
            name = "Proxmark3 RDV4",
            manufacturer = "Proxmark",
            category = "RFID_READER",
            frequencyRange = "125 kHz LF & 13.56 MHz HF",
            transport = "USB OTG / Bluetooth",
            capabilities = "Low-frequency & high-frequency passive RFID detection"
        ),
        ExternalRfHardwareProfile(
            id = "hw_proxmark3_iceman",
            vendorId = 0x2D2D,
            productId = 0x504D,
            name = "Proxmark3 (Iceman)",
            manufacturer = "Proxmark",
            category = "RFID_READER",
            frequencyRange = "125 kHz LF & 13.56 MHz HF",
            transport = "USB OTG",
            capabilities = "Multi-band LF/HF RFID audit"
        ),
        ExternalRfHardwareProfile(
            id = "hw_ubertooth",
            vendorId = 0x1D50,
            productId = 0x6002,
            name = "Ubertooth One",
            manufacturer = "Great Scott Gadgets",
            category = "RF_DETECTOR",
            frequencyRange = "2,400 – 2,483.5 MHz",
            transport = "USB OTG",
            capabilities = "2.4 GHz ISM spectrum & raw BLE physical layer monitoring"
        ),
        ExternalRfHardwareProfile(
            id = "hw_ftdi_rf",
            vendorId = 0x0403,
            productId = 0x6001,
            name = "USB-Serial Broadband RF Probe (FTDI)",
            manufacturer = "FTDI / Generic RF Probe",
            category = "SERIAL_BRIDGE",
            frequencyRange = "Hardware Dependent",
            transport = "USB-C OTG Serial",
            capabilities = "Telemetry bridge for external handheld RF power meters"
        )
    )

    fun isUsbHostSupported(): Boolean =
        context.packageManager.hasSystemFeature(PackageManager.FEATURE_USB_HOST)

    fun scanAttachedUsbDevices(): List<AttachedUsbHardware> {
        val usbManager = context.getSystemService(Context.USB_SERVICE) as? UsbManager ?: return emptyList()
        val deviceMap: HashMap<String, UsbDevice> = runCatching { usbManager.deviceList }.getOrElse { hashMapOf() }
        return deviceMap.values.map { dev ->
            val profile = compatibilityDatabase.firstOrNull {
                it.vendorId == dev.vendorId && it.productId == dev.productId
            }
            AttachedUsbHardware(
                deviceName = dev.deviceName,
                vendorIdHex = "0x%04X".format(dev.vendorId),
                productIdHex = "0x%04X".format(dev.productId),
                productName = dev.productName ?: "USB Peripheral",
                manufacturerName = dev.manufacturerName ?: "Unknown USB Vendor",
                hasUsbPermission = usbManager.hasPermission(dev),
                matchedProfile = profile
            )
        }
    }
}
