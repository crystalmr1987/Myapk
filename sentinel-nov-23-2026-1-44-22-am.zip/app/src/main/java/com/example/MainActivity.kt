package com.example

import android.bluetooth.BluetoothAdapter
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.location.LocationManager
import android.net.wifi.WifiManager
import android.nfc.NfcAdapter
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import com.example.ui.SensorToolsViewModel
import com.example.ui.SentinelApp
import com.example.ui.SentinelViewModel

class MainActivity : ComponentActivity() {

    private val mainViewModel: SentinelViewModel by viewModels {
        SentinelViewModel.Factory((application as SentinelApplication).container)
    }
    private val toolsViewModel: SensorToolsViewModel by viewModels {
        SensorToolsViewModel.Factory((application as SentinelApplication).container)
    }

    private var nfcAdapter: NfcAdapter? = null
    private var isNfcScreenVisible = false
    private var receiverRegistered = false

    private val radioStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            toolsViewModel.refreshDiagnostics()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        nfcAdapter = runCatching { NfcAdapter.getDefaultAdapter(this) }.getOrNull()

        setContent {
            SentinelApp(
                mainViewModel = mainViewModel,
                toolsViewModel = toolsViewModel,
                onNfcScreenVisibilityChanged = { visible ->
                    isNfcScreenVisible = visible
                    updateNfcReaderMode()
                }
            )
        }
    }

    override fun onResume() {
        super.onResume()
        toolsViewModel.refreshDiagnosticsAsync()
        updateNfcReaderMode()
        if (!receiverRegistered) {
            val filter = IntentFilter().apply {
                addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
                addAction(WifiManager.WIFI_STATE_CHANGED_ACTION)
                addAction(LocationManager.PROVIDERS_CHANGED_ACTION)
            }
            receiverRegistered = runCatching {
                ContextCompat.registerReceiver(this, radioStateReceiver, filter, ContextCompat.RECEIVER_EXPORTED)
                true
            }.getOrDefault(false)
        }
    }

    override fun onPause() {
        super.onPause()
        runCatching { nfcAdapter?.disableReaderMode(this) }
        if (receiverRegistered) {
            runCatching { unregisterReceiver(radioStateReceiver) }
            receiverRegistered = false
        }
    }

    private fun updateNfcReaderMode() {
        val adapter = nfcAdapter ?: return
        if (runCatching { !adapter.isEnabled }.getOrDefault(true)) return
        if (isNfcScreenVisible) {
            val flags = NfcAdapter.FLAG_READER_NFC_A or
                NfcAdapter.FLAG_READER_NFC_B or
                NfcAdapter.FLAG_READER_NFC_F or
                NfcAdapter.FLAG_READER_NFC_V
            runCatching {
                adapter.enableReaderMode(
                    this,
                    { tag ->
                        (application as SentinelApplication).container.nfcRfidManager.parseDiscoveredTag(tag)
                    },
                    flags,
                    null
                )
            }
        } else {
            runCatching { adapter.disableReaderMode(this) }
        }
    }
}
