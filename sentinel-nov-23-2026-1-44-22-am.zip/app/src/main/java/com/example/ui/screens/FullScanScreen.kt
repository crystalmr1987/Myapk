package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.core.model.ModuleExecutionState
import com.example.services.FullScanUiState
import com.example.ui.components.LimitationBanner
import com.example.ui.components.PermissionPromptCard
import com.example.ui.components.RiskBadge
import com.example.ui.components.SectionHeader
import com.example.ui.components.TacticalCard
import com.example.ui.theme.LocalSentinelPalette

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FullScanScreen(
    state: FullScanUiState,
    missingPermissions: Array<String>,
    bluetoothSupported: Boolean,
    bluetoothEnabled: Boolean,
    wifiEnabled: Boolean,
    locationServicesEnabled: Boolean,
    onRefreshPermissions: () -> Unit,
    onStartScan: () -> Unit,
    onCancelScan: () -> Unit,
    onOpenDeviceDetail: (String) -> Unit,
    onExportPdf: () -> Unit,
    onExportJson: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val palette = LocalSentinelPalette.current
    var permHint by remember { mutableStateOf<String?>(null) }

    val permLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        onRefreshPermissions()
        if (results.values.any { it }) {
            permHint = null
            if (!state.isRunning) onStartScan()
        } else {
            permHint = "Android suppressed or denied one or more permissions. Tap 'App Settings' > Permissions to enable Nearby devices & Precise Location."
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Comprehensive Full Scan") },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                TacticalCard(accentColor = MaterialTheme.colorScheme.primary) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = state.currentStepLabel,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        LinearProgressIndicator(
                            progress = { state.progressFraction },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            if (state.isRunning) {
                                OutlinedButton(
                                    onClick = onCancelScan,
                                    modifier = Modifier.minimumInteractiveComponentSize().testTag("full_scan_cancel_button")
                                ) {
                                    Icon(Icons.Filled.Stop, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Stop Scan")
                                }
                            } else {
                                Button(
                                    onClick = onStartScan,
                                    modifier = Modifier.minimumInteractiveComponentSize().testTag("full_scan_run_button")
                                ) {
                                    Icon(Icons.Filled.PlayArrow, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(if (state.completedSession == null) "Start Full Scan" else "Re-Run Full Scan")
                                }
                            }
                        }
                    }
                }
            }

            if (missingPermissions.isNotEmpty() && !state.isRunning) {
                item {
                    PermissionPromptCard(
                        title = "${missingPermissions.size} Scan Permission(s) Missing",
                        rationale = permHint ?: "Grant missing Nearby devices and Precise Location permissions so BLE and Wi-Fi audit modules can run.",
                        buttonText = "Grant & Re-Run",
                        testTag = "full_scan_grant_missing_button",
                        onGrantClick = { permLauncher.launch(missingPermissions) },
                        secondaryButtonText = "App Settings",
                        onSecondaryClick = {
                            val intent = Intent(
                                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.fromParts("package", context.packageName, null)
                            )
                            runCatching { context.startActivity(intent) }
                        }
                    )
                }
            }

            if ((!bluetoothEnabled && bluetoothSupported) || !wifiEnabled || !locationServicesEnabled) {
                item {
                    TacticalCard(accentColor = palette.moderate) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = "System Radios / Location Needed",
                                style = MaterialTheme.typography.titleMedium,
                                color = palette.moderate
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (!bluetoothEnabled && bluetoothSupported) {
                                    OutlinedButton(
                                        onClick = { runCatching { context.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) } },
                                        modifier = Modifier.minimumInteractiveComponentSize()
                                    ) { Text("Bluetooth") }
                                }
                                if (!wifiEnabled) {
                                    OutlinedButton(
                                        onClick = { runCatching { context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) } },
                                        modifier = Modifier.minimumInteractiveComponentSize()
                                    ) { Text("Wi-Fi") }
                                }
                                if (!locationServicesEnabled) {
                                    OutlinedButton(
                                        onClick = { runCatching { context.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) } },
                                        modifier = Modifier.minimumInteractiveComponentSize()
                                    ) { Text("Location") }
                                }
                            }
                        }
                    }
                }
            }

            if (state.modules.isNotEmpty()) {
                item {
                    SectionHeader(title = "Module Execution Status")
                }
                items(state.modules, key = { it.moduleName }) { mod ->
                    TacticalCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            when (mod.state) {
                                ModuleExecutionState.RUNNING -> CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.5.dp
                                )
                                ModuleExecutionState.COMPLETED -> Icon(
                                    Icons.Filled.CheckCircle,
                                    contentDescription = "Completed",
                                    tint = palette.low,
                                    modifier = Modifier.size(22.dp)
                                )
                                ModuleExecutionState.LIMITED,
                                ModuleExecutionState.UNAVAILABLE,
                                ModuleExecutionState.PERMISSION_DENIED -> Icon(
                                    Icons.Filled.WarningAmber,
                                    contentDescription = mod.state.name,
                                    tint = palette.moderate,
                                    modifier = Modifier.size(22.dp)
                                )
                                ModuleExecutionState.FAILED -> Icon(
                                    Icons.Filled.ErrorOutline,
                                    contentDescription = "Failed",
                                    tint = palette.critical,
                                    modifier = Modifier.size(22.dp)
                                )
                                ModuleExecutionState.PENDING -> Icon(
                                    Icons.Filled.WarningAmber,
                                    contentDescription = "Pending",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(mod.moduleName, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    text = "${mod.state.name} • ${mod.detail}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            if (state.warnings.isNotEmpty()) {
                item {
                    LimitationBanner(
                        title = "Permission & Hardware Warnings (${state.warnings.size})",
                        message = state.warnings.joinToString("\n• ", prefix = "• ")
                    )
                }
            }

            state.completedSession?.let { session ->
                item {
                    TacticalCard(accentColor = palette.low) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("Completion Summary (${session.id})", style = MaterialTheme.typography.titleMedium)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Duration: ${"%.1f".format(session.durationMs / 1000.0)}s • Observed: ${session.totalObservedCount} • Flagged: ${session.suspiciousCount}",
                                style = MaterialTheme.typography.bodySmall
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = onExportPdf, modifier = Modifier.minimumInteractiveComponentSize()) {
                                    Text("Export PDF")
                                }
                                OutlinedButton(onClick = onExportJson, modifier = Modifier.minimumInteractiveComponentSize()) {
                                    Text("Export JSON")
                                }
                            }
                        }
                    }
                }
            }

            if (state.detectedDevices.isNotEmpty()) {
                item {
                    SectionHeader(
                        title = "Detected Devices (${state.detectedDevices.size})",
                        subtitle = "Tap any device for transparent risk reasoning & history"
                    )
                }
                items(state.detectedDevices, key = { it.fingerprintId }) { dev ->
                    TacticalCard(
                        onClick = { onOpenDeviceDetail(dev.fingerprintId) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(dev.displayName, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    text = "${dev.sourceType} • ${dev.manufacturerName} • ${dev.lastRssi} dBm",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            RiskBadge(riskLevel = dev.riskLevel)
                        }
                    }
                }
            }
        }
    }
}
