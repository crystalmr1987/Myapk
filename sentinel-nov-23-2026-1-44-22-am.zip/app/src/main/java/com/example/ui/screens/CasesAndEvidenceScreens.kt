package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FolderSpecial
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.core.database.EvidenceRecordEntity
import com.example.core.database.InvestigationCaseEntity
import com.example.core.model.InvestigationMode
import com.example.services.ExportedArtifact
import com.example.ui.components.EmptyStatePanel
import com.example.ui.components.LimitationBanner
import com.example.ui.components.RiskBadge
import com.example.ui.components.SectionHeader
import com.example.ui.components.TacticalCard
import com.example.ui.theme.LocalSentinelPalette
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun CasesListScreen(
    cases: List<InvestigationCaseEntity>,
    lastExportedArtifact: ExportedArtifact?,
    onCreateCase: (String, InvestigationMode, String, String) -> Unit,
    onOpenCaseDetail: (String) -> Unit,
    onExportAll: (String) -> Unit,
    onShareArtifact: (ExportedArtifact) -> Unit,
    modifier: Modifier = Modifier
) {
    var search by remember { mutableStateOf("") }
    var showCreateDialog by remember { mutableStateOf(false) }
    val timeFmt = SimpleDateFormat("MMM d, yyyy", Locale.US)

    val filtered = remember(cases, search) {
        if (search.isBlank()) cases else {
            val q = search.lowercase()
            cases.filter {
                it.title.lowercase().contains(q) ||
                    it.locationNote.lowercase().contains(q) ||
                    it.id.lowercase().contains(q)
            }
        }
    }

    Scaffold(
        modifier = modifier,
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showCreateDialog = true },
                modifier = Modifier.testTag("cases_create_fab")
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Create Investigation Case")
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                TacticalCard(accentColor = MaterialTheme.colorScheme.primary) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Encrypted Case & Evidence Vault", style = MaterialTheme.typography.titleMedium)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Case notes and evidence narratives are encrypted locally using Android Keystore AES-256-GCM. Export complete histories as PDF, CSV, or JSON with SHA-256 checksums.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { onExportAll("PDF") }, modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("export_all_pdf")) {
                                Text("PDF")
                            }
                            OutlinedButton(onClick = { onExportAll("CSV") }, modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("export_all_csv")) {
                                Text("CSV")
                            }
                            OutlinedButton(onClick = { onExportAll("JSON") }, modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("export_all_json")) {
                                Text("JSON")
                            }
                        }
                        lastExportedArtifact?.let { art ->
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = { onShareArtifact(art) },
                                modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize().testTag("share_last_export_button")
                            ) {
                                Icon(Icons.Filled.Share, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Share ${art.file.name} (SHA-256: ${art.sha256.take(10)}...)")
                            }
                        }
                    }
                }
            }

            item {
                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    label = { Text("Search investigation cases...") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth().testTag("cases_search_input"),
                    singleLine = true
                )
            }

            if (filtered.isEmpty()) {
                item {
                    EmptyStatePanel(
                        icon = Icons.Filled.FolderSpecial,
                        title = "No Investigation Cases Yet",
                        tip = "Tap + to open an encrypted investigation case for a vehicle, residence, trip, or personal sweep."
                    )
                }
            } else {
                items(filtered, key = { it.id }) { c ->
                    TacticalCard(onClick = { onOpenCaseDetail(c.id) }) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(c.title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                                Text(c.status, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            }
                            Text(
                                text = "${c.id} • ${c.investigationType} • ${timeFmt.format(Date(c.createdAt))}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (c.locationNote.isNotBlank()) {
                                Text("Location note: ${c.locationNote}", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        CreateCaseDialog(
            onDismiss = { showCreateDialog = false },
            onConfirm = { title, mode, loc, notes ->
                onCreateCase(title, mode, loc, notes)
                showCreateDialog = false
            }
        )
    }
}

@Composable
private fun CreateCaseDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, InvestigationMode, String, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf(InvestigationMode.PERSONAL) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New Investigation Case") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Case Title") },
                    modifier = Modifier.fillMaxWidth().testTag("new_case_title_input"),
                    singleLine = true
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(InvestigationMode.PERSONAL, InvestigationMode.VEHICLE, InvestigationMode.HOTEL).forEach { m ->
                        OutlinedButton(
                            onClick = { mode = m },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(m.shortTitle, maxLines = 1)
                        }
                    }
                }
                Text("Selected type: ${mode.title}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it },
                    label = { Text("Optional Location / Vehicle Note") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Initial Encrypted Notes") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(title, mode, location, notes) },
                modifier = Modifier.testTag("confirm_create_case_button")
            ) {
                Text("Create")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CaseDetailScreen(
    caseEntity: InvestigationCaseEntity?,
    evidenceList: List<EvidenceRecordEntity>,
    decryptNotes: (String, String) -> String?,
    lastExportedArtifact: ExportedArtifact?,
    onUpdateCase: (notes: String?, status: String?) -> Unit,
    onDeleteCase: () -> Unit,
    onAddEvidence: (method: String, summary: String, observations: String, notes: String, photoUri: String?) -> Unit,
    onAnnotateEvidence: (EvidenceRecordEntity, String) -> Unit,
    onDeleteEvidence: (String) -> Unit,
    onExportCase: (String) -> Unit,
    onShareArtifact: (ExportedArtifact) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val palette = LocalSentinelPalette.current
    val timeFmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)

    var showAddEvidenceDialog by remember { mutableStateOf(false) }
    var annotatingRecord by remember { mutableStateOf<EvidenceRecordEntity?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(caseEntity?.title ?: "Case Detail") },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (caseEntity != null) {
                        IconButton(
                            onClick = {
                                onDeleteCase()
                                onBack()
                            },
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Icon(Icons.Filled.Delete, contentDescription = "Delete Case")
                        }
                    }
                }
            )
        }
    ) { innerPadding ->
        if (caseEntity == null) {
            Column(modifier = Modifier.fillMaxSize().padding(innerPadding).padding(16.dp)) {
                Text("Case not found.")
            }
            return@Scaffold
        }

        val initialPlainNotes = remember(caseEntity.id, caseEntity.encryptedNotesCiphertext) {
            decryptNotes(caseEntity.encryptedNotesCiphertext, caseEntity.notesIv)
        }
        val notesDecryptionFailed = initialPlainNotes == null && caseEntity.encryptedNotesCiphertext.isNotBlank()
        var editableNotes by remember(caseEntity.id) { mutableStateOf(initialPlainNotes.orEmpty()) }

        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                TacticalCard(accentColor = MaterialTheme.colorScheme.primary) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("${caseEntity.id} • ${caseEntity.investigationType} • ${caseEntity.status}", style = MaterialTheme.typography.labelMedium, color = palette.cyanAccent)
                        if (caseEntity.locationNote.isNotBlank()) {
                            Text("Context: ${caseEntity.locationNote}", style = MaterialTheme.typography.bodySmall)
                        }
                        if (notesDecryptionFailed) {
                            LimitationBanner(
                                title = "Keystore Decryption Error",
                                message = "Saved notes could not be decrypted on this Android Keystore state. Saving is disabled to protect the original ciphertext."
                            )
                        } else {
                            OutlinedTextField(
                                value = editableNotes,
                                onValueChange = { editableNotes = it },
                                label = { Text("Encrypted Case Notes (AES-256-GCM)") },
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 3
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { onUpdateCase(editableNotes, null) },
                                enabled = !notesDecryptionFailed,
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Text("Save Notes")
                            }
                            OutlinedButton(
                                onClick = {
                                    val nextStatus = if (caseEntity.status == "ACTIVE") "ARCHIVED" else "ACTIVE"
                                    onUpdateCase(null, nextStatus)
                                },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Text(if (caseEntity.status == "ACTIVE") "Archive" else "Reopen")
                            }
                        }
                    }
                }
            }

            item {
                TacticalCard {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("Case Report Export", style = MaterialTheme.typography.titleMedium)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { onExportCase("PDF") }, modifier = Modifier.weight(1f).minimumInteractiveComponentSize()) {
                                Text("Case PDF")
                            }
                            OutlinedButton(onClick = { onExportCase("JSON") }, modifier = Modifier.weight(1f).minimumInteractiveComponentSize()) {
                                Text("Case JSON")
                            }
                        }
                        lastExportedArtifact?.let { art ->
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(onClick = { onShareArtifact(art) }, modifier = Modifier.fillMaxWidth().minimumInteractiveComponentSize()) {
                                Icon(Icons.Filled.Share, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Share ${art.file.name}")
                            }
                        }
                    }
                }
            }

            item {
                SectionHeader(
                    title = "Forensic Evidence Vault (${evidenceList.size})",
                    subtitle = "Original photos & timestamps are preserved unmodified; annotations are stored separately",
                    trailing = {
                        Button(
                            onClick = { showAddEvidenceDialog = true },
                            modifier = Modifier.minimumInteractiveComponentSize().testTag("case_add_evidence_button")
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Add")
                        }
                    }
                )
            }

            items(evidenceList, key = { it.id }) { ev ->
                val decryptedEvNotes = remember(ev.id, ev.encryptedNotesCiphertext) {
                    decryptNotes(ev.encryptedNotesCiphertext, ev.notesIv)
                }
                TacticalCard {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${ev.id} • ${ev.detectionMethod}", style = MaterialTheme.typography.labelMedium, color = palette.cyanAccent)
                            RiskBadge(riskLevel = ev.riskLevelSnapshot)
                        }
                        Text(ev.deviceSummary, style = MaterialTheme.typography.titleMedium)
                        Text("Captured: ${timeFmt.format(Date(ev.createdAt))}", style = MaterialTheme.typography.labelSmall)
                        if (ev.supportingObservations.isNotBlank()) {
                            Text("Observations: ${ev.supportingObservations}", style = MaterialTheme.typography.bodySmall)
                        }
                        if (decryptedEvNotes == null && ev.encryptedNotesCiphertext.isNotBlank()) {
                            LimitationBanner(
                                title = "Decryption Unavailable",
                                message = "Encrypted evidence note could not be decrypted on the current keystore state."
                            )
                        } else if (!decryptedEvNotes.isNullOrBlank()) {
                            Text("Original Notes: $decryptedEvNotes", style = MaterialTheme.typography.bodySmall)
                        }
                        if (ev.photoUri != null) {
                            val photoModel = remember(ev.photoUri) {
                                val parsed = Uri.parse(ev.photoUri)
                                if (parsed.scheme == "file" && !parsed.path.isNullOrBlank()) {
                                    File(parsed.path!!)
                                } else {
                                    parsed
                                }
                            }
                            AsyncImage(
                                model = photoModel,
                                contentDescription = "Preserved evidence photograph",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(160.dp)
                            )
                            Text("Original Photo SHA-256: ${ev.photoSha256 ?: "Unavailable"}", style = MaterialTheme.typography.labelSmall, color = palette.low)
                        }
                        if (!ev.editedAnnotationNote.isNullOrBlank()) {
                            LimitationBanner(
                                title = "Derived Annotation (Original Untouched)",
                                message = ev.editedAnnotationNote,
                                tint = palette.cyanAccent
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { annotatingRecord = ev },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Text("Add Annotation")
                            }
                            OutlinedButton(
                                onClick = { onDeleteEvidence(ev.id) },
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Text("Delete")
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddEvidenceDialog) {
        AddEvidenceDialog(
            onDismiss = { showAddEvidenceDialog = false },
            onConfirm = { method, summary, obs, notes, uri ->
                onAddEvidence(method, summary, obs, notes, uri)
                showAddEvidenceDialog = false
            }
        )
    }

    annotatingRecord?.let { rec ->
        var annText by remember(rec.id) { mutableStateOf(rec.editedAnnotationNote ?: "") }
        AlertDialog(
            onDismissRequest = { annotatingRecord = null },
            title = { Text("Add Derived Annotation") },
            text = {
                OutlinedTextField(
                    value = annText,
                    onValueChange = { annText = it },
                    label = { Text("Annotation (original evidence remains untouched)") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )
            },
            confirmButton = {
                Button(onClick = {
                    onAnnotateEvidence(rec, annText)
                    annotatingRecord = null
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { annotatingRecord = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun AddEvidenceDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, String, String, String, String?) -> Unit
) {
    var summary by remember { mutableStateOf("") }
    var observations by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var selectedPhotoUri by remember { mutableStateOf<String?>(null) }

    // Zero-permission Android Photo Picker (Play Policy compliant!)
    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) selectedPhotoUri = uri.toString()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Preserve Evidence Record") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = summary,
                    onValueChange = { summary = it },
                    label = { Text("Item / Device Summary") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = observations,
                    onValueChange = { observations = it },
                    label = { Text("Supporting Observations") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Encrypted Field Notes") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )
                OutlinedButton(
                    onClick = {
                        photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Filled.PhotoLibrary, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (selectedPhotoUri != null) "Photo Selected (SHA-256 on save)" else "Attach Photo (Android Photo Picker)")
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                onConfirm(
                    "MANUAL_EVIDENCE",
                    summary.ifBlank { "Physical Inspection Item" },
                    observations,
                    notes,
                    selectedPhotoUri
                )
            }) { Text("Preserve") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
