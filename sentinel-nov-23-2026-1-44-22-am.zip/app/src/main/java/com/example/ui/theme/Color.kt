package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Tactical Obsidian Dark Palette
val ObsidianBg = Color(0xFF070B12)
val CarbonSurface = Color(0xFF0E1520)
val SlateSurfaceVariant = Color(0xFF162030)
val SlateOutline = Color(0xFF28374E)
val ElectricCyan = Color(0xFF00E5FF)
val DeepCyanContainer = Color(0xFF003640)
val TacticalEmerald = Color(0xFF00E676)
val DeepEmeraldContainer = Color(0xFF063922)
val AmberAlert = Color(0xFFFFB300)
val HighOrange = Color(0xFFFF6D00)
val CriticalCrimson = Color(0xFFFF3B5C)
val DeepCrimsonContainer = Color(0xFF44101C)
val IceText = Color(0xFFEAF2FA)
val MutedSteelText = Color(0xFF91A4BE)

// Daylight High-Contrast Light Palette
val DaylightBg = Color(0xFFF3F6FA)
val DaylightSurface = Color(0xFFFFFFFF)
val DaylightSurfaceVariant = Color(0xFFE3EBF4)
val DaylightOutline = Color(0xFFB8C7D9)
val DaylightCyan = Color(0xFF006D7D)
val DaylightCyanContainer = Color(0xFFCFF4FA)
val DaylightEmerald = Color(0xFF007B43)
val DaylightAmber = Color(0xFFB26A00)
val DaylightOrange = Color(0xFFC64B00)
val DaylightCrimson = Color(0xFFC61D3A)
val DaylightText = Color(0xFF0D1726)
val DaylightMutedText = Color(0xFF475B75)
