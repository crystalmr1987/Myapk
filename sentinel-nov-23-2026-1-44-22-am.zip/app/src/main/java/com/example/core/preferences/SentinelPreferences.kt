package com.example.core.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.core.model.BleScanProfile
import com.example.core.model.ThemePreference
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import org.json.JSONObject
import java.io.IOException

private val Context.sentinelDataStore: DataStore<Preferences> by preferencesDataStore(name = "sentinel_settings")

data class SentinelSettings(
    val themePreference: ThemePreference = ThemePreference.DARK,
    val textScaleMultiplier: Float = 1.0f,
    val optInLocationCorrelation: Boolean = false, // Strictly opt-in
    val bleScanProfile: BleScanProfile = BleScanProfile.BALANCED,
    val magnetometerSensitivityUt: Float = 25f,
    val magnetometerHapticEnabled: Boolean = true,
    val persistentTrackerAlertsEnabled: Boolean = true,
    val onboardingCompleted: Boolean = false,
    val firstScanPermissionsRequested: Boolean = false,
    val checklistStatesJson: String = "{}"
)

object ChecklistJsonCodec {
    fun parseFlatMap(json: String?): Map<String, Boolean> {
        if (json.isNullOrBlank()) return emptyMap()
        return runCatching {
            val obj = JSONObject(json)
            buildMap {
                val keys = obj.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    put(k, obj.optBoolean(k, false))
                }
            }
        }.getOrDefault(emptyMap())
    }

    fun encodeFlatMap(map: Map<String, Boolean>): String {
        val obj = JSONObject()
        map.forEach { (k, v) -> if (v) obj.put(k, true) }
        return obj.toString()
    }

    fun parseScopedMap(scopedJson: String?, scope: String): Map<String, Boolean> {
        if (scopedJson.isNullOrBlank()) return emptyMap()
        return runCatching {
            val root = JSONObject(scopedJson)
            val sub = root.optJSONObject(scope) ?: return@runCatching emptyMap()
            buildMap {
                val keys = sub.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    put(k, sub.optBoolean(k, false))
                }
            }
        }.getOrDefault(emptyMap())
    }

    fun updateScopedMap(existingScopedJson: String?, scope: String, updated: Map<String, Boolean>): String {
        val root = runCatching {
            if (existingScopedJson.isNullOrBlank()) JSONObject() else JSONObject(existingScopedJson)
        }.getOrElse { JSONObject() }
        val sub = JSONObject()
        updated.forEach { (k, v) -> if (v) sub.put(k, true) }
        root.put(scope, sub)
        return root.toString()
    }
}

class SentinelPreferences(private val context: Context) {

    private object Keys {
        val THEME = stringPreferencesKey("theme_preference")
        val TEXT_SCALE = floatPreferencesKey("text_scale_multiplier")
        val OPT_IN_LOCATION = booleanPreferencesKey("opt_in_location_correlation")
        val BLE_PROFILE = stringPreferencesKey("ble_scan_profile")
        val MAG_SENSITIVITY = floatPreferencesKey("mag_sensitivity_ut")
        val MAG_HAPTIC = booleanPreferencesKey("mag_haptic")
        val TRACKER_ALERTS = booleanPreferencesKey("persistent_tracker_alerts")
        val ONBOARDING_DONE = booleanPreferencesKey("onboarding_completed")
        val FIRST_SCAN_PERMS_REQUESTED = booleanPreferencesKey("first_scan_permissions_requested")
        val CHECKLIST_STATES = stringPreferencesKey("checklist_states_json")
    }

    val settingsFlow: Flow<SentinelSettings> = context.sentinelDataStore.data
        .catch { exception ->
            if (exception is IOException) {
                emit(emptyPreferences())
            } else {
                throw exception
            }
        }
        .map { prefs ->
        SentinelSettings(
            themePreference = prefs[Keys.THEME]?.let {
                runCatching { ThemePreference.valueOf(it) }.getOrNull()
            } ?: ThemePreference.DARK,
            textScaleMultiplier = (prefs[Keys.TEXT_SCALE] ?: 1.0f).coerceIn(0.85f, 1.35f),
            optInLocationCorrelation = prefs[Keys.OPT_IN_LOCATION] ?: false,
            bleScanProfile = prefs[Keys.BLE_PROFILE]?.let {
                runCatching { BleScanProfile.valueOf(it) }.getOrNull()
            } ?: BleScanProfile.BALANCED,
            magnetometerSensitivityUt = (prefs[Keys.MAG_SENSITIVITY] ?: 25f).coerceIn(5f, 100f),
            magnetometerHapticEnabled = prefs[Keys.MAG_HAPTIC] ?: true,
            persistentTrackerAlertsEnabled = prefs[Keys.TRACKER_ALERTS] ?: true,
            onboardingCompleted = prefs[Keys.ONBOARDING_DONE] ?: false,
            firstScanPermissionsRequested = prefs[Keys.FIRST_SCAN_PERMS_REQUESTED] ?: false,
            checklistStatesJson = prefs[Keys.CHECKLIST_STATES] ?: "{}"
        )
    }

    suspend fun setThemePreference(theme: ThemePreference) {
        context.sentinelDataStore.edit { it[Keys.THEME] = theme.name }
    }

    suspend fun setTextScaleMultiplier(scale: Float) {
        context.sentinelDataStore.edit { it[Keys.TEXT_SCALE] = scale.coerceIn(0.85f, 1.35f) }
    }

    suspend fun setOptInLocationCorrelation(enabled: Boolean) {
        context.sentinelDataStore.edit { it[Keys.OPT_IN_LOCATION] = enabled }
    }

    suspend fun setBleScanProfile(profile: BleScanProfile) {
        context.sentinelDataStore.edit { it[Keys.BLE_PROFILE] = profile.name }
    }

    suspend fun setMagnetometerSensitivityUt(ut: Float) {
        context.sentinelDataStore.edit { it[Keys.MAG_SENSITIVITY] = ut.coerceIn(5f, 100f) }
    }

    suspend fun setMagnetometerHapticEnabled(enabled: Boolean) {
        context.sentinelDataStore.edit { it[Keys.MAG_HAPTIC] = enabled }
    }

    suspend fun setPersistentTrackerAlertsEnabled(enabled: Boolean) {
        context.sentinelDataStore.edit { it[Keys.TRACKER_ALERTS] = enabled }
    }

    suspend fun setOnboardingCompleted(completed: Boolean) {
        context.sentinelDataStore.edit { it[Keys.ONBOARDING_DONE] = completed }
    }

    suspend fun setFirstScanPermissionsRequested(requested: Boolean) {
        context.sentinelDataStore.edit { it[Keys.FIRST_SCAN_PERMS_REQUESTED] = requested }
    }

    suspend fun setChecklistStatesJson(json: String) {
        context.sentinelDataStore.edit { it[Keys.CHECKLIST_STATES] = json }
    }
}
