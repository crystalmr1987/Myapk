# SENTINEL — Architecture, Manual, Privacy & Limitations Reference

## 1. Application Architecture
- **Package / Namespace**: `com.example` (Application ID: `com.aistudio.sentinel.kx7m2p`)
- **UI**: Jetpack Compose + Material 3 (`SentinelTheme`, Tactical Dark & Daylight High-Contrast Light themes, adjustable text scale, adaptive `NavigationBar` / `NavigationRail` via `BoxWithConstraints`).
- **Core Modules**:
  - `core/model`: Domain models (`InvestigationMode`, `RiskLevel`, `DetectionSource`, `HardwareDiagnosticsReport`, etc.)
  - `core/security`: `KeystoreCryptoManager` (Android Keystore AES-256-GCM), `HashingUtils` (SHA-256), `ManufacturerLookup` (offline BLE SIG Company IDs, tracker Service UUIDs, IEEE OUI MAC prefixes, NFC silicon prefixes).
  - `core/database`: Room database (`SentinelDatabase`, `SentinelDao`, 7 entities, prepopulated `LocalIntelSeed`).
  - `core/intelligence`: `DeviceIntelligenceEngine` (MAC-rotation structural fingerprinting, multi-factor risk scoring, false-positive guardrails, co-occurrence relationship clustering).
  - `core/preferences`: `SentinelPreferences` (Jetpack DataStore, opt-in location OFF by default).
  - `sensors`: `BluetoothScannerManager`, `WifiNetworkInspector` (Wi-Fi AP + NsdManager mDNS + authorized LAN), `MagnetometerManager`, `NfcRfidManager`, `UwbManagerHelper`, `ExternalRfHardwareManager` (`UsbManager` OTG), `DiagnosticsManager`, `LocationProviderHelper`.
  - `services`: `FullScanCoordinator`, `ExtendedScanService` (`foregroundServiceType="connectedDevice"`), `DatabaseMaintenanceWorker` (WorkManager), `ReportExporter` (PDF, CSV, JSON + SHA-256 + `FileProvider`).

## 2. Privacy & Security Design
- **Local-First & Zero-Cost**: No cloud backend, no user accounts, no ads, no third-party analytics, `android:allowBackup="false"`.
- **Encrypted Sensitive Data**: Investigation case notes and evidence field narratives are encrypted via Android Keystore AES-256-GCM.
- **Forensic Integrity**: Captured evidence photos remain unmodified on disk; SHA-256 digests are calculated at capture and export time. Annotations are stored separately from original records.
- **Location Privacy**: Location correlation is strictly opt-in (`false` by default) and foreground-only.
- **User Erasure**: Settings includes full data erasure deleting all Room user tables, evidence photos, and exported report files.

## 3. Known Technical Limitations (Android Platform & Physics)
1. **Passive GPS Receivers**: GPS satellites broadcast one-way signals; passive GPS loggers emit zero RF energy and cannot be detected remotely by any smartphone.
2. **Cellular Uplinks**: Android restricts apps from sniffing third-party LTE/5G/2G cellular transmissions. External calibrated RF hardware (e.g., tinySA, HackRF) is required.
3. **Offline Recording Cameras**: Hidden cameras recording solely to internal microSD cards without Wi-Fi/BLE cannot be discovered over radio; physical/optical inspection is required.
4. **NFC vs. Passive RFID**: Smartphone NFC operates at 13.56 MHz (~1–4 cm). 125 kHz LF and 860–960 MHz UHF RFID require external USB/BLE readers (e.g., Proxmark3).
5. **UWB Ranging**: Android's Jetpack UWB API requires FiRa out-of-band key exchange and cannot passively intercept proprietary AirTag or SmartTag UWB frames.
6. **Wi-Fi & LAN**: Android throttles foreground Wi-Fi scans (4 per 2 min), requires `ACCESS_FINE_LOCATION` for scan results, and restricts `/proc/net/arp` MAC access on Android 10+.
7. **Magnetometer**: Measures static magnetic flux in µT; speakers, vehicle chassis steel, wiring, and latches also trigger spikes. Never auto-classifies spikes as trackers.
