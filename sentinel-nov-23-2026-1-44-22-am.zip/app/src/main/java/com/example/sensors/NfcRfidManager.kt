package com.example.sensors

import android.content.Context
import android.nfc.NdefMessage
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.MifareClassic
import android.nfc.tech.MifareUltralight
import android.nfc.tech.Ndef
import android.nfc.tech.NfcA
import com.example.core.security.ManufacturerLookup
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class NfcTagInspection(
    val uidHex: String,
    val manufacturer: String,
    val technologies: List<String>,
    val tagTypeDescription: String,
    val ndefRecords: List<String>,
    val rawDetails: String,
    val timestamp: Long
)

data class ExternalRfidHardwareSpec(
    val name: String,
    val frequencyBand: String,
    val interfaceType: String,
    val supportedProtocols: String
)

/**
 * Modular interface for future external LF (125 kHz) and UHF (860-960 MHz) RFID readers
 * connected over USB OTG or Bluetooth SPP/GATT.
 */
interface ExternalRfidReaderAdapter {
    val spec: ExternalRfidHardwareSpec
    fun isConnected(): Boolean
    suspend fun readTagOnce(): String?
}

class NfcRfidManager(private val context: Context) {

    private val nfcAdapter: NfcAdapter? = runCatching { NfcAdapter.getDefaultAdapter(context) }.getOrNull()

    private val _lastTag = MutableStateFlow<NfcTagInspection?>(null)
    val lastTag: StateFlow<NfcTagInspection?> = _lastTag.asStateFlow()

    private val _tagHistory = MutableStateFlow<List<NfcTagInspection>>(emptyList())
    val tagHistory: StateFlow<List<NfcTagInspection>> = _tagHistory.asStateFlow()

    fun isNfcSupported(): Boolean = nfcAdapter != null
    fun isNfcEnabled(): Boolean = runCatching { nfcAdapter?.isEnabled == true }.getOrDefault(false)

    val supportedExternalRfidSpecs: List<ExternalRfidHardwareSpec> = listOf(
        ExternalRfidHardwareSpec(
            name = "Proxmark3 (Easy / RDV4)",
            frequencyBand = "LF 125–134 kHz & HF 13.56 MHz",
            interfaceType = "USB-C OTG / CDC Serial",
            supportedProtocols = "EM4100, HID Prox, Indala, MIFARE, iCLASS"
        ),
        ExternalRfidHardwareSpec(
            name = "External UHF EPC Gen2 Reader",
            frequencyBand = "UHF 860–960 MHz",
            interfaceType = "USB OTG / Bluetooth LE",
            supportedProtocols = "ISO 18000-6C / EPCglobal Gen2 (long-range asset & vehicle tags)"
        )
    )

    fun parseDiscoveredTag(tag: Tag): NfcTagInspection {
        val uidBytes = tag.id ?: ByteArray(0)
        val uidHex = if (uidBytes.isEmpty()) "Unavailable" else uidBytes.joinToString(":") { "%02X".format(it) }
        val manufacturer = ManufacturerLookup.lookupNfcManufacturerByUid(uidBytes)
        val techs = tag.techList.map { it.substringAfterLast('.') }

        val details = mutableListOf<String>()
        var tagType = "ISO 14443 / NFC Tag (13.56 MHz)"

        NfcA.get(tag)?.let { nfcA ->
            val atqa = nfcA.atqa.joinToString("") { "%02X".format(it) }
            val sak = "%02X".format(nfcA.sak.toInt() and 0xFF)
            details.add("NfcA ATQA: 0x$atqa • SAK: 0x$sak")
        }

        MifareClassic.get(tag)?.let { mc ->
            tagType = when (mc.type) {
                MifareClassic.TYPE_CLASSIC -> "MIFARE Classic (${mc.size} bytes)"
                MifareClassic.TYPE_PLUS -> "MIFARE Plus"
                MifareClassic.TYPE_PRO -> "MIFARE Pro"
                else -> "MIFARE Compatible"
            }
        }

        MifareUltralight.get(tag)?.let { mu ->
            tagType = when (mu.type) {
                MifareUltralight.TYPE_ULTRALIGHT -> "MIFARE Ultralight / NTAG"
                MifareUltralight.TYPE_ULTRALIGHT_C -> "MIFARE Ultralight C"
                else -> "MIFARE Ultralight Family"
            }
        }

        val ndefRecords = mutableListOf<String>()
        Ndef.get(tag)?.let { ndef ->
            runCatching {
                ndef.connect()
                val msg: NdefMessage? = ndef.ndefMessage ?: ndef.cachedNdefMessage
                details.add("NDEF Max Size: ${ndef.maxSize} bytes • Writable: ${ndef.isWritable}")
                msg?.records?.forEachIndexed { idx, rec ->
                    val payloadText = decodeNdefPayload(rec.tnf, rec.type, rec.payload)
                    ndefRecords.add("Record ${idx + 1} (${String(rec.type, Charsets.UTF_8)}): $payloadText")
                }
            }.also {
                runCatching { ndef.close() }
            }
        }

        val inspection = NfcTagInspection(
            uidHex = uidHex,
            manufacturer = manufacturer,
            technologies = techs,
            tagTypeDescription = tagType,
            ndefRecords = ndefRecords,
            rawDetails = details.joinToString(" | ").ifBlank { "Standard 13.56 MHz NFC tag" },
            timestamp = System.currentTimeMillis()
        )
        _lastTag.value = inspection
        _tagHistory.value = (listOf(inspection) + _tagHistory.value).take(25)
        return inspection
    }

    private fun decodeNdefPayload(tnf: Short, type: ByteArray, payload: ByteArray): String {
        if (payload.isEmpty()) return "<empty>"
        // URI record
        if (tnf.toInt() == 1 && type.contentEquals("U".toByteArray())) {
            val prefixCode = payload[0].toInt() and 0xFF
            val prefix = when (prefixCode) {
                0x01 -> "http://www."
                0x02 -> "https://www."
                0x03 -> "http://"
                0x04 -> "https://"
                else -> ""
            }
            return prefix + String(payload, 1, payload.size - 1, Charsets.UTF_8)
        }
        // Text record
        if (tnf.toInt() == 1 && type.contentEquals("T".toByteArray())) {
            val status = payload[0].toInt() and 0xFF
            val langLen = status and 0x3F
            val start = 1 + langLen
            if (start <= payload.size) {
                return String(payload, start, payload.size - start, Charsets.UTF_8)
            }
        }
        val printable = payload.all { it in 32..126 }
        return if (printable) String(payload, Charsets.UTF_8) else payload.joinToString(" ") { "%02X".format(it) }
    }
}
