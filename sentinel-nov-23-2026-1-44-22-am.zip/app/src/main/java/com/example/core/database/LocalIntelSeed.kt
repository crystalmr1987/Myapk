package com.example.core.database

object LocalIntelSeed {
    private const val SEED_TS = 1763700000000L

    fun initialEntries(): List<DeviceIntelEntryEntity> = listOf(
        // Commercial Bluetooth Trackers
        DeviceIntelEntryEntity(
            id = "intel_apple_airtag",
            manufacturer = "Apple, Inc.",
            productName = "AirTag / Find My Accessory",
            category = "BLE_TRACKER",
            identifyingCharacteristics = "Company ID 0x004C, Continuity Offline Finding payload (0x12), Service UUID 0xFD6F / 0xFD44, rotating RPA MAC every ~15 min",
            serviceUuidOrOuiPattern = "0x004C / FD6F / FD44",
            sourceAttribution = "Bluetooth SIG & DULT (Detecting Unwanted Location Trackers) Specification",
            verificationStatus = "VERIFIED",
            confidenceLevel = "HIGH",
            notes = "Authorized Apple devices also emit 0x004C Continuity frames; separation state and persistence across scans matter more than a single frame.",
            lastUpdatedAt = SEED_TS
        ),
        DeviceIntelEntryEntity(
            id = "intel_samsung_smarttag",
            manufacturer = "Samsung Electronics",
            productName = "Galaxy SmartTag / SmartTag2",
            category = "BLE_TRACKER",
            identifyingCharacteristics = "Company ID 0x0075, Service UUID 0xFD5A / 0xFD59, SmartThings Find offline beacon",
            serviceUuidOrOuiPattern = "0x0075 / FD5A / FD59",
            sourceAttribution = "Bluetooth SIG & Samsung SmartThings Find public documentation",
            verificationStatus = "VERIFIED",
            confidenceLevel = "HIGH",
            notes = "UWB-equipped SmartTag+ / SmartTag2 require FiRa/Samsung OOB exchange; UWB cannot be passively sniffed by standard Android APIs.",
            lastUpdatedAt = SEED_TS
        ),
        DeviceIntelEntryEntity(
            id = "intel_tile_tracker",
            manufacturer = "Tile, Inc. (Life360)",
            productName = "Tile Mate / Pro / Slim / Sticker",
            category = "BLE_TRACKER",
            identifyingCharacteristics = "Service UUID 0xFEED / 0xFEEC, Company ID 0x0642",
            serviceUuidOrOuiPattern = "FEED / FEEC / 0x0642",
            sourceAttribution = "Bluetooth SIG Assigned Numbers",
            verificationStatus = "VERIFIED",
            confidenceLevel = "HIGH",
            notes = "Commercial item finder; supports Tile Scan and Secure mode.",
            lastUpdatedAt = SEED_TS
        ),
        DeviceIntelEntryEntity(
            id = "intel_google_fmdn",
            manufacturer = "Google / Chipolo / Pebblebee",
            productName = "Find My Device Network (FMDN) Tag",
            category = "BLE_TRACKER",
            identifyingCharacteristics = "Service UUID 0xFE2C / 0xFE65 / 0xFDEE / DULT 0xFD6F",
            serviceUuidOrOuiPattern = "FE2C / FE65 / FDEE / FD6F",
            sourceAttribution = "Google Find My Device Network & DULT Draft Spec",
            verificationStatus = "VERIFIED",
            confidenceLevel = "HIGH",
            notes = "Android OS has built-in Unknown Tracker Alerts for DULT-compliant tags.",
            lastUpdatedAt = SEED_TS
        ),
        // Wireless Cameras & Surveillance Equipment
        DeviceIntelEntryEntity(
            id = "intel_hikvision_cam",
            manufacturer = "Hikvision Digital Technology",
            productName = "IP Camera / NVR Series",
            category = "WIRELESS_CAMERA",
            identifyingCharacteristics = "OUI B4:A3:82, C0:56:E3, 44:19:B6; RTSP port 554, HTTP 80/8000, ONVIF discovery",
            serviceUuidOrOuiPattern = "B4:A3:82 / C0:56:E3 / 44:19:B6",
            sourceAttribution = "IEEE Registration Authority OUI Registry",
            verificationStatus = "VERIFIED",
            confidenceLevel = "HIGH",
            notes = "Commonly deployed legitimately in buildings; unexpected presence on a personal/hotel LAN warrants verification.",
            lastUpdatedAt = SEED_TS
        ),
        DeviceIntelEntryEntity(
            id = "intel_dahua_cam",
            manufacturer = "Dahua Technology",
            productName = "Network Camera / DVR",
            category = "WIRELESS_CAMERA",
            identifyingCharacteristics = "OUI 3C:EF:8C, A0:BD:1D; RTSP 554, port 37777",
            serviceUuidOrOuiPattern = "3C:EF:8C / A0:BD:1D",
            sourceAttribution = "IEEE Registration Authority OUI Registry",
            verificationStatus = "VERIFIED",
            confidenceLevel = "HIGH",
            notes = "Verify physical location and authorization before assuming unauthorized monitoring.",
            lastUpdatedAt = SEED_TS
        ),
        DeviceIntelEntryEntity(
            id = "intel_axis_cam",
            manufacturer = "Axis Communications",
            productName = "Axis IP Camera",
            category = "WIRELESS_CAMERA",
            identifyingCharacteristics = "OUI 00:40:8C, AC:CC:8E; mDNS _axis-video._tcp",
            serviceUuidOrOuiPattern = "00:40:8C / AC:CC:8E",
            sourceAttribution = "IEEE OUI Registry & IANA mDNS Service Registry",
            verificationStatus = "VERIFIED",
            confidenceLevel = "HIGH",
            notes = "Enterprise network video equipment.",
            lastUpdatedAt = SEED_TS
        ),
        DeviceIntelEntryEntity(
            id = "intel_espressif_cam",
            manufacturer = "Espressif Inc.",
            productName = "ESP32-CAM / Embedded Wi-Fi Module",
            category = "WIRELESS_CAMERA",
            identifyingCharacteristics = "OUI 24:0A:C4, 30:AE:A4, A4:CF:12; AP SSIDs like ESP32_CAM, AI-THINKER, IPC-xxxx",
            serviceUuidOrOuiPattern = "24:0A:C4 / 30:AE:A4 / A4:CF:12",
            sourceAttribution = "IEEE OUI Registry",
            verificationStatus = "REFERENCE_ONLY",
            confidenceLevel = "MEDIUM",
            notes = "Espressif chips are also widely used in smart plugs, thermostats, and appliances—OUI alone is NOT proof of a camera.",
            lastUpdatedAt = SEED_TS
        ),
        // GPS, Cellular & OBD-II Trackers (Reference Database)
        DeviceIntelEntryEntity(
            id = "intel_teltonika_obd",
            manufacturer = "Teltonika Telematics",
            productName = "FMB001 / FMB003 OBD-II & Fleet Trackers",
            category = "OBD2_TRACKER",
            identifyingCharacteristics = "Plugs into 16-pin OBD-II port; some models broadcast BLE config beacon (Company ID 0x089A, OUI 00:1E:42)",
            serviceUuidOrOuiPattern = "0x089A / 00:1E:42",
            sourceAttribution = "Teltonika Public Product Specifications",
            verificationStatus = "VERIFIED",
            confidenceLevel = "MEDIUM",
            notes = "Cellular/GNSS unit; if BLE beacon is disabled, physical OBD-II port & splitter inspection is required.",
            lastUpdatedAt = SEED_TS
        ),
        DeviceIntelEntryEntity(
            id = "intel_queclink_gps",
            manufacturer = "Queclink Wireless Solutions",
            productName = "GL300 / GV500 Series Cellular GPS Tracker",
            category = "GPS_TRACKER",
            identifyingCharacteristics = "Battery or hardwired LTE-M/2G/4G cellular GPS tracker; often housed in magnetic waterproof pelicans under vehicle",
            serviceUuidOrOuiPattern = "No default BLE/Wi-Fi broadcast",
            sourceAttribution = "FCC Public Filings & Manufacturer Datasheets",
            verificationStatus = "REFERENCE_ONLY",
            confidenceLevel = "LOW",
            notes = "Passive GPS reception cannot be detected by phones. Detection requires physical/magnetic inspection or an external RF cellular uplink detector.",
            lastUpdatedAt = SEED_TS
        ),
        DeviceIntelEntryEntity(
            id = "intel_calamp_gps",
            manufacturer = "CalAmp",
            productName = "LMU / TTU Vehicle Telematics",
            category = "CELLULAR_TRACKER",
            identifyingCharacteristics = "Hardwired 12V/24V under-dash or trunk cellular telematics unit",
            serviceUuidOrOuiPattern = "Cellular LTE uplink only",
            sourceAttribution = "FCC Public Filings",
            verificationStatus = "REFERENCE_ONLY",
            confidenceLevel = "LOW",
            notes = "Requires physical wiring harness inspection under dashboard, kick panels, and battery compartment.",
            lastUpdatedAt = SEED_TS
        ),
        DeviceIntelEntryEntity(
            id = "intel_generic_obd",
            manufacturer = "ELM327 / Generic OBD-II",
            productName = "Bluetooth / Wi-Fi OBD-II Dongle",
            category = "OBD2_TRACKER",
            identifyingCharacteristics = "SSIDs like WiFi_OBDII, V-LINK; BLE UUID 0xFFF0, name OBDII / Vgate",
            serviceUuidOrOuiPattern = "FFF0 / OUI 00:04:3E",
            sourceAttribution = "Standard OBD-II Adapter Profiles",
            verificationStatus = "REFERENCE_ONLY",
            confidenceLevel = "MEDIUM",
            notes = "Often used legitimately by vehicle owners for diagnostics; check OBD-II port under steering column.",
            lastUpdatedAt = SEED_TS
        ),
        // External RF & RFID Hardware Compatibility Reference
        DeviceIntelEntryEntity(
            id = "intel_rtlsdr",
            manufacturer = "Realtek / RTL-SDR",
            productName = "RTL2832U USB SDR Receiver",
            category = "EXTERNAL_RF_HARDWARE",
            identifyingCharacteristics = "USB VID:PID 0x0BDA:0x2838 via USB OTG; covers ~24 MHz – 1766 MHz",
            serviceUuidOrOuiPattern = "USB 0BDA:2838",
            sourceAttribution = "USB-IF Hardware Identifier",
            verificationStatus = "VERIFIED",
            confidenceLevel = "HIGH",
            notes = "Connect via USB-C OTG adapter for wideband spectrum inspection.",
            lastUpdatedAt = SEED_TS
        ),
        DeviceIntelEntryEntity(
            id = "intel_hackrf",
            manufacturer = "Great Scott Gadgets",
            productName = "HackRF One SDR",
            category = "EXTERNAL_RF_HARDWARE",
            identifyingCharacteristics = "USB VID:PID 0x1D50:0x6089; covers 1 MHz – 6 GHz",
            serviceUuidOrOuiPattern = "USB 1D50:6089",
            sourceAttribution = "OpenMoko USB PID Registry",
            verificationStatus = "VERIFIED",
            confidenceLevel = "HIGH",
            notes = "Wideband SDR covering sub-GHz, cellular uplinks, Wi-Fi, and 2.4/5.8 GHz video links.",
            lastUpdatedAt = SEED_TS
        ),
        DeviceIntelEntryEntity(
            id = "intel_tinysa",
            manufacturer = "tinySA",
            productName = "tinySA / tinySA Ultra Spectrum Analyzer",
            category = "EXTERNAL_RF_HARDWARE",
            identifyingCharacteristics = "USB CDC Serial VID:PID 0x0483:0x5740",
            serviceUuidOrOuiPattern = "USB 0483:5740",
            sourceAttribution = "STMicroelectronics USB CDC VID/PID",
            verificationStatus = "VERIFIED",
            confidenceLevel = "HIGH",
            notes = "Compact calibrated handheld spectrum analyzer connectable over USB-C OTG.",
            lastUpdatedAt = SEED_TS
        ),
        DeviceIntelEntryEntity(
            id = "intel_proxmark3",
            manufacturer = "Proxmark / Iceman",
            productName = "Proxmark3 External RFID Reader",
            category = "RFID_NFC",
            identifyingCharacteristics = "USB VID:PID 0x9AC4:0x4B8F or 0x2D2D:0x504D; supports LF 125kHz & HF 13.56MHz",
            serviceUuidOrOuiPattern = "USB 9AC4:4B8F / 2D2D:504D",
            sourceAttribution = "Proxmark3 Hardware Specification",
            verificationStatus = "VERIFIED",
            confidenceLevel = "HIGH",
            notes = "Required for 125 kHz LF RFID tags (HID Prox, EM4100) which Android NFC hardware cannot read.",
            lastUpdatedAt = SEED_TS
        )
    )
}
