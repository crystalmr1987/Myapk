package com.example.services

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.SentinelApplication
import com.example.core.database.ScanSessionEntity
import com.example.core.model.BleScanProfile
import com.example.core.model.RiskLevel
import com.example.sensors.BleScanEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.util.UUID

/**
 * User-initiated Foreground Service for extended BLE observation sessions.
 * Strictly adheres to Android 14+ foregroundServiceType="connectedDevice" and
 * displays a transparent ongoing notification with a Stop control.
 */
class ExtendedScanService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var observationJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopObservation()
            return START_NOT_STICKY
        }

        createNotificationChannel()
        val notification = buildNotification("Initializing extended BLE observation...")
        val startedFg = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        }.isSuccess
        if (!startedFg) {
            _lastCycleSummary.value = "Unable to start foreground connected-device service without Bluetooth permissions."
            _isServiceRunning.value = false
            runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }
            stopSelf()
            return START_NOT_STICKY
        }

        val container = (application as SentinelApplication).container
        if (!container.diagnosticsManager.hasBleScanPermission()) {
            _lastCycleSummary.value = "Bluetooth scan permission required before starting Extended Observation."
            _isServiceRunning.value = false
            runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }
            stopSelf()
            return START_NOT_STICKY
        }

        startObservationLoop()
        return START_NOT_STICKY
    }

    private fun startObservationLoop() {
        if (observationJob?.isActive == true) return
        _isServiceRunning.value = true

        val container = (application as SentinelApplication).container
        observationJob = serviceScope.launch {
            var cycle = 0
            while (cycle < MAX_CYCLES) {
                cycle++
                val sessionId = "EXT-${UUID.randomUUID().toString().take(8).uppercase()}"
                val cycleStart = System.currentTimeMillis()
                var count = 0
                val seenIds = mutableSetOf<String>()
                val suspiciousIds = mutableSetOf<String>()
                var cycleError: String? = null
                container.bluetoothScanner.scanBle(BleScanProfile.BALANCED).collect { ev ->
                    when (ev) {
                        is BleScanEvent.DeviceSeen -> {
                            runCatching {
                                container.repository.recordObservation(sessionId, ev.frame.toRawObservation(null))
                            }.onSuccess { saved ->
                                count++
                                seenIds.add(saved.fingerprintId)
                                if (saved.riskLevel == RiskLevel.HIGH.name || saved.riskLevel == RiskLevel.CRITICAL.name) {
                                    suspiciousIds.add(saved.fingerprintId)
                                }
                            }.onFailure { err ->
                                cycleError = "Storage error: ${err.localizedMessage ?: "database unavailable"}"
                            }
                        }
                        is BleScanEvent.Error -> {
                            cycleError = ev.message
                        }
                        BleScanEvent.Completed -> Unit
                    }
                }
                val cycleEnd = System.currentTimeMillis()
                runCatching {
                    container.repository.saveScanSession(
                        ScanSessionEntity(
                            id = sessionId,
                            modeId = "EXTENDED_BLE",
                            caseId = null,
                            startedAt = cycleStart,
                            endedAt = cycleEnd,
                            durationMs = (cycleEnd - cycleStart).coerceAtLeast(1L),
                            status = if (cycleError == null) "COMPLETED" else "PARTIAL",
                            modulesExecutedJson = JSONArray(listOf("BLE")).toString(),
                            warningsJson = JSONArray(listOfNotNull(cycleError)).toString(),
                            totalObservedCount = seenIds.size,
                            suspiciousCount = suspiciousIds.size
                        )
                    )
                }
                if (cycleError != null) {
                    _lastCycleSummary.value = "Stopped: $cycleError"
                    break
                }
                _lastCycleSummary.value = "Cycle $cycle complete • $count BLE frames recorded"
                val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.notify(NOTIFICATION_ID, buildNotification("Cycle $cycle/6 • $count BLE frames logged"))
                delay(15_000L)
            }
            stopObservation()
        }
    }

    private fun stopObservation() {
        observationJob?.cancel()
        _isServiceRunning.value = false
        runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }
        stopSelf()
    }

    override fun onDestroy() {
        _isServiceRunning.value = false
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "SENTINEL Extended Observation",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Displays status while user-initiated extended BLE observation is active."
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, ExtendedScanService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("SENTINEL Observation Active")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(0, "Stop", stopIntent)
            .build()
    }

    companion object {
        const val CHANNEL_ID = "sentinel_extended_scan"
        const val NOTIFICATION_ID = 1042
        const val ACTION_STOP = "com.example.sentinel.ACTION_STOP_EXTENDED_SCAN"
        private const val MAX_CYCLES = 6

        private val _isServiceRunning = MutableStateFlow(false)
        val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()

        private val _lastCycleSummary = MutableStateFlow("Idle")
        val lastCycleSummary: StateFlow<String> = _lastCycleSummary.asStateFlow()
    }
}
