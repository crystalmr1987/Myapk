package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BluetoothSearching
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.FolderSpecial
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Nfc
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WifiFind
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.database.ObservedDeviceEntity
import com.example.core.database.ScanSessionEntity
import com.example.core.model.InvestigationMode
import com.example.core.model.RiskLevel
import com.example.core.model.UserDeviceStatus
import com.example.ui.DashboardSummary
import com.example.ui.components.EmptyStatePanel
import com.example.ui.components.LimitationBanner
import com.example.ui.components.RiskBadge
import com.example.ui.components.RiskDistributionBar
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatTile
import com.example.ui.components.TacticalCard
import com.example.ui.theme.LocalSentinelPalette
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DashboardScreen(
    summary: DashboardSummary,
    recentDevices: List<ObservedDeviceEntity>,
    recentSessions: List<ScanSessionEntity>,
    isFullScanRunning: Boolean,
    onStartFullScan: () -> Unit,
    onOpenQuickBle: () -> Unit,
    onOpenWifi: () -> Unit,
    onOpenHiddenCamera: () -> Unit,
    onOpenGpsInvestigation: () -> Unit,
    onOpenVehicleMode: () -> Unit,
    onOpenMagnetometer: () -> Unit,
    onOpenNfc: () -> Unit,
    onOpenRfHardware: () -> Unit,
    onOpenCases: () -> Unit,
    onOpenDeviceDetail: (String) -> Unit,
    onOpenDiagnostics: () -> Unit,
    onOpenAntiStalking: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalSentinelPalette.current
    val timeFmt = SimpleDateFormat("MMM d, HH:mm", Locale.US)

    val lowCount = recentDevices.count { it.riskLevel == RiskLevel.LOW.name }
    val modCount = recentDevices.count { it.riskLevel == RiskLevel.MODERATE.name }
    val highCount = recentDevices.count { it.riskLevel == RiskLevel.HIGH.name }
    val critCount = recentDevices.count { it.riskLevel == RiskLevel.CRITICAL.name }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Hero Security Overview Card
        item {
            TacticalCard(
                accentColor = if (summary.highOrCriticalCount > 0) palette.high else MaterialTheme.colorScheme.primary
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "SENTINEL COMMAND",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (summary.highOrCriticalCount > 0) {
                                    "${summary.highOrCriticalCount} Flagged Observation(s)"
                                } else if (summary.totalScansCount == 0) {
                                    "Ready for First Sweep"
                                } else {
                                    "Environment Baseline Active"
                                },
                                style = MaterialTheme.typography.headlineMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Icon(
                            imageVector = Icons.Filled.Shield,
                            contentDescription = "SENTINEL Security Status",
                            tint = if (summary.highOrCriticalCount > 0) palette.high else palette.low,
                            modifier = Modifier.size(38.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Local-first analysis • Zero cloud dependencies • ${summary.totalScansCount} scan(s) & ${summary.totalObserved} stored device fingerprint(s)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    RiskDistributionBar(
                        low = lowCount,
                        moderate = modCount,
                        high = highCount,
                        critical = critCount
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = onStartFullScan,
                            modifier = Modifier
                                .weight(1.25f)
                                .minimumInteractiveComponentSize()
                                .testTag("dashboard_start_full_scan_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary
                            )
                        ) {
                            Icon(Icons.Filled.Radar, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (isFullScanRunning) "View Live Scan" else "Start Full Scan")
                        }
                        FilledTonalButton(
                            onClick = onOpenQuickBle,
                            modifier = Modifier
                                .weight(1f)
                                .minimumInteractiveComponentSize()
                                .testTag("dashboard_quick_ble_button")
                        ) {
                            Icon(Icons.Filled.BluetoothSearching, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Quick BLE")
                        }
                    }
                }
            }
        }

        // Stored Statistics Grid (100% real stored records)
        item {
            SectionHeader(
                title = "Stored Telemetry Overview",
                subtitle = "Counts derived exclusively from local Room database records"
            )
            Spacer(modifier = Modifier.height(6.dp))
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    StatTile(
                        label = "Trusted / Known",
                        value = summary.trustedCount.toString(),
                        icon = Icons.Filled.VerifiedUser,
                        accent = palette.low,
                        modifier = Modifier.weight(1f)
                    )
                    StatTile(
                        label = "Unknown Devices",
                        value = summary.unknownCount.toString(),
                        icon = Icons.Filled.Sensors,
                        accent = palette.moderate,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    StatTile(
                        label = "Potential Trackers",
                        value = summary.potentialTrackersCount.toString(),
                        icon = Icons.Filled.Warning,
                        accent = palette.high,
                        modifier = Modifier.weight(1f)
                    )
                    StatTile(
                        label = "Potential Cameras",
                        value = summary.potentialCamerasCount.toString(),
                        icon = Icons.Filled.CameraAlt,
                        accent = palette.critical,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    StatTile(
                        label = "Suspicious Network",
                        value = summary.suspiciousNetworkCount.toString(),
                        icon = Icons.Filled.Router,
                        accent = palette.moderate,
                        modifier = Modifier.weight(1f)
                    )
                    StatTile(
                        label = "Active Cases",
                        value = summary.activeCasesCount.toString(),
                        icon = Icons.Filled.FolderSpecial,
                        accent = palette.cyanAccent,
                        onClick = onOpenCases,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Quick Module Launchpad
        item {
            SectionHeader(
                title = "Investigation Modules",
                subtitle = "Direct access to active radio, sensor, and physical inspection tools"
            )
            Spacer(modifier = Modifier.height(6.dp))
            val quickTools = listOf(
                Triple("Wi-Fi & LAN", Icons.Filled.WifiFind, onOpenWifi),
                Triple("Hidden Camera", Icons.Filled.CameraAlt, onOpenHiddenCamera),
                Triple("GPS / Cellular", Icons.Filled.GpsFixed, onOpenGpsInvestigation),
                Triple("Vehicle Sweep", Icons.Filled.DirectionsCar, onOpenVehicleMode),
                Triple("Magnetometer", Icons.Filled.Explore, onOpenMagnetometer),
                Triple("NFC / RFID", Icons.Filled.Nfc, onOpenNfc),
                Triple("RF Hardware", Icons.Filled.Sensors, onOpenRfHardware),
                Triple("Anti-Stalking", Icons.Filled.Security, onOpenAntiStalking)
            )
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                quickTools.chunked(2).forEach { pair ->
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        pair.forEach { (title, icon, action) ->
                            QuickToolButton(
                                title = title,
                                icon = icon,
                                onClick = action,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        if (pair.size == 1) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }

        // Security Recommendations & Diagnostics Shortcut
        item {
            TacticalCard {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Security Recommendations",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    val recText = when {
                        summary.highOrCriticalCount > 0 ->
                            "Review ${summary.highOrCriticalCount} elevated observation(s) in Intel, verify whether they belong to nearby associates, or document them inside an Investigation Case."
                        summary.totalScansCount == 0 ->
                            "Run Hardware Diagnostics first to see which radios your phone supports, then run a Full Scan in a quiet baseline location."
                        else ->
                            "Re-scan after moving to a second location (200m+ away) to compare persistent devices across sessions."
                    }
                    Text(
                        text = recText,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = onOpenDiagnostics,
                            modifier = Modifier.minimumInteractiveComponentSize().testTag("dashboard_diagnostics_button")
                        ) {
                            Text("Hardware Diagnostics")
                        }
                        OutlinedButton(
                            onClick = onOpenAntiStalking,
                            modifier = Modifier.minimumInteractiveComponentSize().testTag("dashboard_antistalking_button")
                        ) {
                            Text("Safety Center")
                        }
                    }
                }
            }
        }

        // Recent Detections
        item {
            SectionHeader(
                title = "Recent Detections",
                subtitle = "Latest observed signatures stored locally"
            )
        }

        if (recentDevices.isEmpty()) {
            item {
                EmptyStatePanel(
                    icon = Icons.Filled.Radar,
                    title = "No Devices Observed Yet",
                    tip = "Tap Start Full Scan or Quick BLE to begin real hardware scanning. SENTINEL never populates fake detections."
                )
            }
        } else {
            items(recentDevices.take(6), key = { it.fingerprintId }) { dev ->
                TacticalCard(
                    onClick = { onOpenDeviceDetail(dev.fingerprintId) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = dev.displayName,
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${dev.sourceType} • ${dev.manufacturerName} • ${dev.lastRssi} dBm",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "Seen ${dev.observationCount}x • Last ${timeFmt.format(Date(dev.lastSeenAt))}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        RiskBadge(riskLevel = dev.riskLevel)
                    }
                }
            }
        }

        // Recent Scan Sessions
        if (recentSessions.isNotEmpty()) {
            item {
                SectionHeader(
                    title = "Recent Investigation Activity",
                    subtitle = "Latest completed or partial scan sessions"
                )
            }
            items(recentSessions.take(4), key = { it.id }) { session ->
                TacticalCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${session.modeId.uppercase()} (${session.status})",
                                style = MaterialTheme.typography.labelLarge
                            )
                            Text(
                                text = "${session.totalObservedCount} observed • ${session.suspiciousCount} flagged • ${timeFmt.format(Date(session.startedAt))}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        item {
            LimitationBanner(
                title = "Platform Capabilities & Honesty Notice",
                message = "SENTINEL uses real Android BLE, Wi-Fi, CameraX, Magnetometer, NFC, UWB, and USB OTG APIs. Smartphones cannot universally detect passive GPS receivers, cellular uplinks, or offline cameras without external RF hardware."
            )
            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

@Composable
private fun QuickToolButton(
    title: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    TacticalCard(
        onClick = onClick,
        modifier = modifier
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
